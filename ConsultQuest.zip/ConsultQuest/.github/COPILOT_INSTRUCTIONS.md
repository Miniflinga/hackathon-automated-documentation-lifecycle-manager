# Project overview

## Purpose ✅
An educational exercise project that demonstrates a feedback tool for collecting, viewing and acting on consultant performance feedback. This repository is intended for learning and demonstration only — it is NOT intended for production use.

> Scope & assumptions ⚠️
- Educational/demo focus: readability, clarity and examples matter more than robustness.
- No production-level concerns: security, build pipelines, deployments or comprehensive tests are out-of-scope.
- Lightweight data and sample seed data suffices for demonstration.

---

## High-level description 🔧
The project contains two main parts:

1. **Backend (Java / Spring Boot)**
   - Purpose: simple REST API for storing and querying feedback, forms, questions and reports.
   - Key technologies: Spring Boot, Spring Data JPA, H2 (or file-based DB via configuration), Gradle.
   - Important files/folders: `backend/src/main/java/...` (application code), `backend/src/main/resources/application.properties`, `backend/src/main/resources/data.sql` (sample data), `backend/build.gradle.kts`.

2. **Frontend (Next.js / React / TypeScript)**
   - Purpose: UI for submitting feedback, viewing consultant reports, charts and admin views.
   - Key technologies: Next.js, React, MUI (Material UI), Axios.
   - Important files/folders: `frontend/pages/`, `frontend/components/`, `frontend/styles/`, `frontend/package.json`.

---

## How to run locally ▶️
- Backend (Gradle / Spring Boot):
  - From the `backend/` folder: `./gradlew bootRun` (use `gradlew.bat` on Windows) to start the API server.
  - The app is a simple Spring Boot app; sample data is preloaded from `data.sql`.

- Frontend (Next.js):
  - From the `frontend/` folder: `npm install` (or `pnpm`/`yarn`) then `npm run dev` to start the dev server at `http://localhost:3000`.
  - The frontend is configured to call the backend API endpoints; adjust `api.ts` or environment values if needed.

---

## Intended usage & contribution 💡
- Use the repo for demos, training, or experimenting with UI/UX and API design for feedback systems.
- Keep pull requests small and focused; prioritize improving examples, documentation, or component clarity.
- Do not invest time in production hardening (security, infra, CI/CD) unless explicitly requested.

---

## Notes for maintainers 📝
- This repository is educational: prefer clear code, comments and small example data sets over advanced optimizations.
- If adding features, document them in this file and keep the running instructions up-to-date.

---

(Generated instructions for Copilot use and future prompts.)