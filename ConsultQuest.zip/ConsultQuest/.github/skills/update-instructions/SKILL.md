---
name: update-instructions
description: Create or update the copilot instructions file containing the description and overview of the project.
---

# Skill Instructions
Follow these six steps applying the user input where fitting:
1. If there are existing instructions use them as a base for creating updates to them and focus on the latest changes of the project. If no changes have been maed recently ask the user if the instructions should be updated and if so do not use the instructions as a basis for this prompt.
2. Check if the current oroject (workspace) contains distinct seperated parts. Example of such project parts could be a frontend or a backend. Most of the time there will only be one project part. Usually project parts will get deployed seperately on different infrastructure.
3. For each project part do the following (this can be done in parallel using subagents) and add its results to the instructions:
- use the [structure](./structure.md) prompt to create an summery of what files and directories are for
- use the [architecture](./architecture.md) prompt to analyze the high level components and their interaction
- use the information from the structure and architecture in the [description](./description.md) prompt to formulate an overall summary and purpose or vision
4. Review the outcome of step 3 and formulate an overaching description which can be used for all future prompts regarding this project.
5. Compress the information without loosing facts. Avvoid repeating of information. Do not include prompt suggestions or similar. Keep only necessary information about the project so that future tasks will be most efficient.
6. If there are existing instructions, merge them with the results of step 5. If there are no existing instructions, create them using the results of step 5.

# Ouput
A new or updated instructions file for the project to be used by future prompts. 
