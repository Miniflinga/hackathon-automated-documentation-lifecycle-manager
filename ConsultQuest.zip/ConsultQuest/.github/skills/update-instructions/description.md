The aim is to create a brief description of the {project part} which supports continued work on the {project part} which can be implement new tasks or update existing functionallity.

Use the architecture and structure description of the {project part} to analyze the purpose of the project and summarize apparent high-level concepts. Including iportant, unusal implementation detalis in a special "pay particular attention to" section.
 
 Try to guess an outline and the goals and the {project part}'s importance. If necessary verify with the user or ask questions for clarification.
 