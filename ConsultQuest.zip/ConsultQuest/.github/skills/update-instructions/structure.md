Generate a high level overview of the directories and files from a perspective relevant to the {project part}.

For example, for a backend project list what parts (files or directories) take care of:
  - business logic
  - data handling 
  - database operations 
  - request processing 
  - middelware logic

For example, for a frontend project list what pars (files or directories) take care of:
  - communication with the backend
  - navigation
  - handling of history
  - landing sites
  - templates
  - common code or utilities
  - CSS handling and assets

The above examples are not complete and all items are optional.

The aim of the overview is to provide context for continuos work on the {project part}. It should be simple to find relevant files for a specific task.

The output should be a list of directories and files describing:
- what files serve which purpose
- what directories fulfill what purpose
