From a developers perspective analyze the structure (code) of the {project part}:
- how does the data or request or other main entities flow thorugh the code of the {project part}?
- what are the high level components of the {project part} and how do they interact?

The output should be a high leve description both of the components and of the functionality. Keep the language simple and concise. The information should help for solving future tasks:
- guide system construction
- support and simplify system maintenance
- aid system planning and evolution
- serve as a medium for analysis, evaluation or comparison of architectures
