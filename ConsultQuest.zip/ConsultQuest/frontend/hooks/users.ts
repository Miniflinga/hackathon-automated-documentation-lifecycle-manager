// src/hooks/users.ts
import { useMutation, useQuery, useQueryClient } from "react-query";
import { api } from "../api";

export type Role = "MANAGER" | "SALES" | "CONSULTANT" | "ADMIN";
export type UserFormValues = {
  firstName: string;
  lastName: string;
  email: string;
  roles: Role[];
  teamIds: number[];
};
export type UserSummary = UserFormValues & { id: number };


export type Me = {
  id: number;
  roles: Role[];
  firstName: string;
  lastName: string;
  email: string;
}

export function useTeams() {
  return useQuery(["teams"], async () => {
    const { data } = await api.get("/api/teams/all");
    return data as Array<{ id: number; name: string }>;
  });
}

export function useUser(id: number | undefined, enabled = true) {
  return useQuery(
    ["user", id],
    async () => {
      const { data } = await api.get(`/api/users/${id}`);
      return data as UserSummary;
    },
    { enabled: enabled && !!id }
  );
}

export function useCreateUser(options?: { onSuccess?: () => void }) {
  return useMutation(
    async (values: UserFormValues) => api.post("/api/invites", values),
    { onSuccess: options?.onSuccess }
  );
}

export function useUpdateUser(
  id: number,
  options?: { onSuccess?: (user: UserSummary) => void }
) {
  return useMutation(
    async (values: UserFormValues) =>
      api.put(`/api/users/edit/${id}`, {
        email: values.email,
        firstName: values.firstName,
        lastName: values.lastName,
        roles: values.roles,
        teamIds: values.teamIds,
      }),
    {
      onSuccess: () =>
        options?.onSuccess?.({ id, ...(undefined as any as UserFormValues) }),
    }
  );
}

// Hook to fetch the current authenticated user's details
const isBrowser = typeof window !== "undefined";

export function useMe() {
  return useQuery(
    ["me"],
    async () => {
      const { data } = await api.get("/api/auth/me");
      return data as Me;
    },
    {
      //how long to cache the data
      staleTime: 10 * 60 * 1000, // 10 min
      retry: 1,
      enabled: isBrowser // Only run on client-side
    }
  );
}
