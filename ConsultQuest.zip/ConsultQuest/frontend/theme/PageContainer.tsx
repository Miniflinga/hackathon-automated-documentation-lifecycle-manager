import { styled } from "@mui/material/styles";
import Box from "@mui/material/Box";

const PageContainer = styled(Box, {
  shouldForwardProp: (prop) => prop !== "disableBackground",
})<{ disableBackground?: boolean }>(({ theme, disableBackground }) => ({
  display: "flex",
  flexDirection: "column",
  minHeight: "100dvh",
  padding: theme.spacing(2),
  [theme.breakpoints.up("sm")]: {
    padding: theme.spacing(4),
  },
  ...(!disableBackground && {
    position: "relative",
    "&::before": {
      content: '""',
      display: "block",
      position: "fixed",
      zIndex: -1,
      inset: 0,
      backgroundImage:
        "radial-gradient(ellipse at 50% 50%, hsl(240, 1%, 30%), hsl(240, 1%, 10%))",
      backgroundRepeat: "no-repeat",

      ...(theme.palette.mode === "dark" && {
        backgroundImage:
          "radial-gradient(at 50% 50%, hsl(240, 1%, 25%), hsl(240, 1%, 5%))",
      }),
    },
  }),
}));

export default PageContainer;
