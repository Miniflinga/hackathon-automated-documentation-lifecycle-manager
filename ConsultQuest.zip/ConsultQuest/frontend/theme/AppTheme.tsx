import * as React from "react";
import { ThemeProvider, createTheme } from "@mui/material/styles";
import type { ThemeOptions } from "@mui/material/styles";
import { inputsCustomizations } from "./customizations/inputs";
import { dataDisplayCustomizations } from "./customizations/dataDisplay";
import { feedbackCustomizations } from "./customizations/feedback";
import { navigationCustomizations } from "./customizations/navigation";
import { surfacesCustomizations } from "./customizations/surfaces";
import { typography, shadows, shape } from "./themePrimitives";

interface AppThemeProps {
  children: React.ReactNode;
  /**
   * This is for the docs site. You can ignore it or remove it.
   */
  disableCustomTheme?: boolean;
  themeComponents?: ThemeOptions["components"];
}

// Extend MUI Button color palette with custom colors
declare module "@mui/material/Button" {
  interface ButtonPropsColorOverrides {
    pink: true;
    blue: true;
    salmon: true;
    hiqgray: true;
    brown: true;
    orange: true;
  }
}

// Define custom color schemes
const colorSchemes = {
  light: {
    palette: {
      primary: { main: "#bf0070" },
      secondary: { main: "#01a69a" },
      pink: { main: "#fe0096", contrastText: "#fff" },
      blue: { main: "#01dece", contrastText: "#000" },
      salmon: { main: "#ffcada", contrastText: "#000" },
      hiqgray: { main: "#7f7f7e", contrastText: "#fff" },
      brown: { main: "#aa3c35", contrastText: "#fff" },
      orange: { main: "#ff9c68", contrastText: "#000" },
    },
  },
  dark: {
    palette: {
      primary: { main: "#ff0096" },
      secondary: { main: "#01dece" },
      pink: { main: "#fe0096", contrastText: "#fff" },
      blue: { main: "#01dece", contrastText: "#000" },
      salmon: { main: "#ffcada", contrastText: "#000" },
      hiqgray: { main: "#7f7f7e", contrastText: "#fff" },
      brown: { main: "#aa3c35", contrastText: "#fff" },
      orange: { main: "#ff9c68", contrastText: "#000" },
    },
  },
};

export default function AppTheme(props: AppThemeProps) {
  const { children, disableCustomTheme, themeComponents } = props;

  const theme = React.useMemo(() => {
    return disableCustomTheme
      ? {}
      : createTheme({
          // For CSS variables configuration
          cssVariables: {
            colorSchemeSelector: "data-mui-color-scheme",
            cssVarPrefix: "template",
          },
          colorSchemes,
          typography,
          shadows,
          shape,
          components: {
            ...inputsCustomizations,
            ...dataDisplayCustomizations,
            ...feedbackCustomizations,
            ...navigationCustomizations,
            ...surfacesCustomizations,
            ...themeComponents,
            MuiAlert: {
              defaultProps: {
                variant: "outlined",
              },
            },
            MuiCssBaseline: {
              styleOverrides: {
                outlinedSuccess: ({ theme }) => ({
                  backgroundColor: "rgba(102, 187, 106, 0.1)",
                  [theme.getColorSchemeSelector("dark")]: {
                    color: theme.vars.palette.common.white,
                  },
                  [theme.getColorSchemeSelector("light")]: {
                    color: theme.vars.palette.grey[900],
                  },
                }),
                outlinedError: ({ theme }) => ({
                  backgroundColor: "rgba(239, 83, 80, 0.1)",
                  [theme.getColorSchemeSelector("dark")]: {
                    color: theme.vars.palette.common.white,
                  },
                  [theme.getColorSchemeSelector("light")]: {
                    color: theme.vars.palette.grey[900],
                  },
                }),
              },
            },
            MuiCssBaseline: {
              styleOverrides: (theme) => `
                html, body {
                  margin: 0;
                  padding: 0;
                  min-height: 100vh;
                  width: 100%;
                }
                body {
                  background-image: radial-gradient(ellipse at 50% 50%, hsl(240, 1%, 30%), hsl(240, 1%, 10%));
                  background-attachment: fixed;
                  ${theme.getColorSchemeSelector("dark")} {
                    background-image: radial-gradient(at 50% 50%, hsl(240, 1%, 25%), hsl(240, 1%, 5%));
                  }
                }
              `,
            },
          },
        });
  }, [disableCustomTheme, themeComponents]);

  if (disableCustomTheme) {
    return <React.Fragment>{children}</React.Fragment>;
  }

  return (
    <ThemeProvider theme={theme} disableTransitionOnChange>
      {children}
    </ThemeProvider>
  );
}
