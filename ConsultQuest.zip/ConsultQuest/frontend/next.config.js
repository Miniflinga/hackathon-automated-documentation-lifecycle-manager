/** @type {import('next').NextConfig} */
module.exports = {
  output: "standalone",
  transpilePackages: [
    '@mui/x-data-grid',
  ]
};
