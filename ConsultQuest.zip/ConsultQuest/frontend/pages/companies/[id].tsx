import React, { useState } from "react";
import { useRouter } from "next/router";
import AppTheme from "../../theme/AppTheme";
import CssBaseline from "@mui/material/CssBaseline";
import PageContainer from "../../components/PageContainer";
import Navbar from "../../components/Navbar";
import { Grid, Stack, Typography } from "@mui/material";
import { useQuery } from "react-query";
import OutlinedCard from "../../components/Cards/OutlinedCard";
import ReportTable from "../../components/ReportTable";
import ReportsChart, { DailyAverage } from "../../components/ReportsChart";
import { api } from "../../api";
import RadarChartCard from "../../components/Cards/RadarChartCard";
import ViewReportModal from "../../components/ViewReportModal";

// --- DTOs from Backend ---
interface FormSubmissionScoreDTO {
  id: number;
  consultantName: string;
  submittedOn: string; // ISO 8601 date string
  seen: boolean;
  overallScore: number;
}

interface RadarChartDataDTO {
  questionText: string;
  averageScore: number;
}

interface ClientPageDTO {
  id: number;
  name: string;
  averageScore: number;
  submissions: FormSubmissionScoreDTO[];
  radarChartData: RadarChartDataDTO[];
  dailyAverages: DailyAverage[];
}

// --- React Query Fetcher ---
const retrieveClientData = async (clientId: string): Promise<ClientPageDTO> => {
  const { data } = await api.get(`/api/client/${clientId}`);
  return data;
};

export default function CompanyProfile() {
  const router = useRouter();
  const { id: clientId } = router.query;
  const [open, setOpen] = useState(false);
  const [currentReportId, setCurrentReportId] = useState<number | null>(null);

  const {
    data: clientData,
    isLoading,
    error,
  } = useQuery<ClientPageDTO, Error>(
    ["client", clientId], // Query key is now dependent on clientId
    () => retrieveClientData(clientId as string),
    {
      // Only run the query if clientId is available
      enabled: !!clientId,
    }
  );

  // --- Data Transformation for Components ---
  const reports = React.useMemo(() => {
    if (!clientData?.submissions) return [];
    // Transform backend DTO to the format ReportTable expects
    return clientData.submissions.map((report) => ({
      id: report.id,
      company: clientData.name,
      consultant: report.consultantName,
      overallScore: parseFloat(report.overallScore.toFixed(1)),
      createdDate: new Date(report.submittedOn),
      status: report.seen,
    }));
  }, [clientData]);

  const radarChartReport = React.useMemo(() => {
    if (!clientData?.radarChartData) return { answers: [] };
    const coreCategories = ["Glädje", "Enkelhet", "Resultat", "Ansvar"];
    // Transform backend DTO to the format RadarChartCard expects
    const averagedAnswers = clientData.radarChartData
      .filter((item) => coreCategories.includes(item.questionText))
      .map((item) => ({
        question: {
          category: "NUMERIC" as const,
          questionText: item.questionText,
        },
        numericalContent: item.averageScore,
      }));
    return { answers: averagedAnswers };
  }, [clientData]);

  // --- Event Handlers ---
  const handleClose = () => {
    setOpen(false);
  };

  const handleOpen = (id: number) => {
    setCurrentReportId(id);
    setOpen(true);
  };

  return (
    <AppTheme>
      <CssBaseline enableColorScheme />
      <Navbar />
      <ViewReportModal
        open={open}
        currentReportId={currentReportId}
        handleClose={handleClose}
      ></ViewReportModal>
      <PageContainer sx={{ minHeight: "100dvh", height: "auto" }}>
        <Grid container spacing={2} sx={{ mt: "50px" }}>
          <Grid size={8}>
            {isLoading ? (
              <OutlinedCard label="Loading..." content="" />
            ) : (
              <OutlinedCard label="Företag" content={clientData?.name} />
            )}
          </Grid>
          <Grid size={4}>
            <OutlinedCard
              label="Genomsnittligt betyg"
              content={
                clientData?.averageScore
                  ? clientData.averageScore.toFixed(1)
                  : "N/A"
              }
              description="Av alla rapporter"
            ></OutlinedCard>
          </Grid>
        </Grid>
        {error ? (
          <Typography
            sx={{
              textAlign: "left",
              color: "error.main",
              fontSize: 12,
              fontFamily: "Helvetica",
              pt: 2,
              minHeight: 10,
            }}
          >
            {" "}
            Något gick fel vid inläsning av data, försök igen senare.
          </Typography>
        ) : null}
        <Grid container spacing={2} sx={{ mt: "10px" }}>
          <Grid size={4}>
            <Stack spacing={2}>
              <ReportsChart
                dailyAverageData={clientData?.dailyAverages ?? []}
                loading={isLoading}
              />
              <RadarChartCard
                label="Genomsnittliga betyg per kategori"
                report={radarChartReport}
              />
            </Stack>
          </Grid>
          <Grid size={8}>
            <ReportTable
              reports={reports || []}
              loading={isLoading}
              handleOpen={handleOpen}
            />
          </Grid>
        </Grid>
      </PageContainer>
    </AppTheme>
  );
}
