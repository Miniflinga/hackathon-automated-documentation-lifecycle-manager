// pages/index.tsx

import React from 'react';
import type { NextPage } from 'next';
import { StyledEngineProvider } from '@mui/material/styles';
import SignInPage from './login'; 

const HomePage: NextPage = () => {
  return (
    <StyledEngineProvider injectFirst>
      <SignInPage />
    </StyledEngineProvider>
  );
}

export default HomePage;