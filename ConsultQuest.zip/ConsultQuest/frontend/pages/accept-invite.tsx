import { useState, useEffect } from 'react';
import { useRouter } from 'next/router';
import { useQuery, useMutation } from 'react-query';
import Box from '@mui/material/Box';
import Button from '@mui/material/Button';
import CssBaseline from '@mui/material/CssBaseline';
import FormControl from '@mui/material/FormControl';
import TextField from '@mui/material/TextField';
import Typography from '@mui/material/Typography';
import MuiCard from '@mui/material/Card';
import { styled } from '@mui/material/styles';
import Image from 'next/image';

import AppTheme from '../theme/AppTheme';
import ColorModeSelect from '../theme/ColorModeSelect';
import PageContainer from '../components/PageContainer';
import HiqLogo from '/public/assets/logoPink.png';
import { api } from '../api';


const Card = styled(MuiCard)(({ theme }) => ({
  display: 'flex',
  flexDirection: 'column',
  alignSelf: 'center',
  width: '100%',
  padding: theme.spacing(4),
  gap: theme.spacing(2),
  margin: 'auto',
  boxShadow:
    'hsla(220, 30%, 5%, 0.05) 0px 5px 15px 0px, hsla(220, 25%, 10%, 0.05) 0px 15px 35px -5px',
  [theme.breakpoints.up('sm')]: {
    width: '450px',
  },
  ...theme.applyStyles('dark', {
    boxShadow:
      'hsla(220, 30%, 5%, 0.5) 0px 5px 15px 0px, hsla(220, 25%, 10%, 0.08) 0px 15px 35px -5px',
  }),
}));

export default function AcceptInvitePage(props: { disableCustomTheme?: boolean }) {
  const router = useRouter();
  const { token } = router.query;

  // State for the password form
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');

  // Step 1: Validate the token with useQuery
  const { 
    data: validation, 
    isLoading: isValidating, 
    error: validationError 
  } = useQuery(
    ['validateInviteToken', token],
    async () => {
      const { data } = await api.get(`/api/invites/validate?token=${token}`);
      if (!data.valid) {
        throw new Error('Denna länk är inte giltig eller har gått ut.');
      }
      return data;
    },
    {
      enabled: router.isReady && !!token,
      retry: false,
    }
  );

  const acceptMutation = useMutation(
    (payload: any) => api.post('/api/invites/accept', payload),
    {
      onSuccess: () => {
        router.push('/login?invite_success=true');
      },
    }
  );

  // Step 2: Handle form submission to accept the invite
  const handleSubmit = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (password !== confirmPassword) {
      acceptMutation.reset();
      acceptMutation.mutate(undefined, { onError: () => {} }); // Hack to set error state
      acceptMutation.variables = undefined; // Hack to clear variables
      acceptMutation.error = new Error('Lösenorden matchar inte');
      return;
    }
    acceptMutation.mutate({ token, password });
  };

  const renderContent = () => {
    if (isValidating) {
      return <Typography>Validerar inbjudan...</Typography>;
    }

    if (validationError || validation?.valid === false) {
      return (
        <>
          <Typography
            component="h1"
            variant="h4"
            sx={{ width: '100%', fontSize: 'clamp(2rem, 10vw, 2.15rem)', fontFamily: 'AlmarenaNeue' }}
          >
            Invitation Invalid
          </Typography>
          <Typography color="error">{(validationError as Error)?.message || 'Länken är ogiltig eller har gått ut.'}</Typography>
        </>
      );
    }

    return (
      <>
        <Typography
          component="h1"
          variant="h4"
          sx={{ width: '100%', fontSize: 'clamp(2rem, 10vw, 2.15rem)', fontFamily: 'AlmarenaNeue' }}
        >
          Welcome!
        </Typography>
        <Typography component="h2" variant="h6" sx={{ color: 'text.secondary' }}>
          Create your password
        </Typography>
          <Box
            component="form"
            onSubmit={handleSubmit}
            sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}
          >
            <FormControl>
              <TextField
                type="password"
                autoComplete="password"
                name="password"
                required
                fullWidth
                id="password"
                placeholder="New Password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                error={acceptMutation.isError}
              />
            </FormControl>
            <FormControl>
              <TextField
                type="password"
                autoComplete="new-password"
                name="confirmPassword"
                required
                fullWidth
                id="confirmPassword"
                placeholder="Re-type Password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                error={acceptMutation.isError}
                helperText={acceptMutation.isError ? (acceptMutation.error as any)?.response?.data?.message || (acceptMutation.error as Error).message || 'Misslyckades att aktivera kontot' : ''}
              />
            </FormControl>
            <Button
              type="submit"
              fullWidth
              variant="contained"
              disabled={acceptMutation.isLoading}
              sx={{ mt: 2, mb: 2 }}
            >
              {acceptMutation.isLoading ? 'Aktiverar...' : 'Sätt lösenord och aktivera'}
            </Button>
          </Box>
      </>
    );
  };

  return (
    <AppTheme {...props}>
      <CssBaseline enableColorScheme />
      <PageContainer>
        <ColorModeSelect sx={{ position: 'fixed', top: '1rem', right: '1rem' }} />
        <Card variant="outlined">
          <Box sx={{ display: 'flex', justifyContent: 'center', mb: 1 }}>
            <Image src={HiqLogo} alt="HiQ Logo" style={{ width: '180px', height: 'auto' }} />
          </Box>
          {renderContent()}
        </Card>
      </PageContainer>
    </AppTheme>
  );
}
