// pages/form.tsx
import React, { useRef, useEffect, useState } from "react";
import { useQuery, useMutation } from "react-query";
import { useRouter } from "next/router";
import type { NextPage } from "next";
import AppTheme from "../theme/AppTheme";
import Box from "@mui/material/Box";
import CssBaseline from "@mui/material/CssBaseline";
import { Typography } from "@mui/material";
import Button from "@mui/material/Button";
import SendIcon from "@mui/icons-material/Send";
import ReportSlider from "../components/ReportSlider";
import FeedbackField from "../components/FeedbackField";
import PageContainer from "../components/PageContainer";
import styles from "./login.module.css";
import { Skeleton } from "@mui/material";
import {
  Dialog,
  DialogActions,
  DialogContent,
  DialogContentText,
  DialogTitle,
} from "@mui/material";
import { api } from "../api";

const isDeveloperMode = false; // Set to true to enable developer mode, false to disable

interface Question {
  id: number; // Assuming question IDs are numbers
  questionText: string;
  description?: string;
  category: "NUMERIC" | "TEXT"; // Enforce specific string literal types
}
interface Answers {
  [key: number]: string | number;
}

const mockQuestions = [
  { id: 1, questionText: "Glädje (Mock)", category: "NUMERIC" as const },
  { id: 2, questionText: "Enkelhet (Mock)", category: "NUMERIC" as const },
  {
    id: 3,
    questionText: "Vad kan vi göra bättre? (Mock)",
    category: "TEXT" as const,
  },
];

const FormPage: NextPage = () => {
  const router = useRouter();
  const { token } = router.query;

  // 2) Form questions/data state
  const [answers, setAnswers] = useState<Answers>({});
  const [openDialog, setOpenDialog] = useState(false);

  // Step A: Validate the token with useQuery
  const {
    data: validation,
    isLoading: isValidating,
    error: validationError,
  } = useQuery(
    ["validateFormToken", token],
    async () => {
      if (isDeveloperMode) {
        console.warn(
          "--- UTVECKLARLÄGE AKTIVT: Token-validering hoppas över. ---"
        );
        return { valid: true };
      }
      const { data } = await api.get(
        `/api/invites/validate/form?token=${token}`
      );
      if (!data.valid) {
        throw new Error("Denna länk är inte giltig eller har gått ut.");
      }
      return data;
    },
    {
      enabled: router.isReady && !!token,
      retry: false,
    }
  );

  const formTemplateName = validation?.formTemplateName;

  // Step B: Fetch questions with useQuery, enabled only after token is valid
  const { data: questions, isLoading: isLoadingQuestions } = useQuery(
    ["formQuestions", formTemplateName],
    async () => {
      if (isDeveloperMode || !formTemplateName) {
        return mockQuestions;
      }
      const { data } = await api.get(
        `/api/form/${encodeURIComponent(formTemplateName)}`
      );
      return data.questions || [];
    },
    {
      enabled: !!validation?.valid,
      onSuccess: (data) => {
        const init: Answers = {};
        (data || []).forEach((q) => {
          // data since data returns data.questions
          init[q.id] = q.category === "NUMERIC" ? 5 : "";
        });
        setAnswers(init);
      },
    }
  );

  const handleAnswerChange = (id: number, value: string | number) => {
    setAnswers((prev) => ({ ...prev, [id]: value }));
  };

  const renderQuestion = (q: Question) => {
    switch (q.category) {
      case "NUMERIC":
        return (
          <ReportSlider
            key={q.id}
            title={q.questionText}
            value={answers[q.id] as number}
            onChange={(value: number) => handleAnswerChange(q.id, value)}
          />
        );
      case "TEXT":
        return (
          <FeedbackField
            key={q.id}
            title={q.questionText}
            label={q.description ?? "Skriv ytterligare återkoppling här"}
            value={(answers[q.id] as string) || ""}
            onChange={(value: string) => handleAnswerChange(q.id, value)}
          />
        );
      default:
        return null;
    }
  };

  const submitMutation = useMutation(
    (reportData: any) => api.post("/api/form/submit", reportData),
    {
      onSuccess: () => {
        setOpenDialog(false);
      },
      onError: (error: any) => {
        setOpenDialog(false);
      },
    }
  );

  const handleConfirmSubmit = async () => {
    const reportData = {
      formTemplateName: formTemplateName,
      token,
      answers: Object.entries(answers).map(([questionId, value]) => ({
        questionId: Number(questionId),
        value,
      })),
    };

    if (isDeveloperMode) {
      console.log("--- UTVECKLARLÄGE: Simulerar formulär-submission ---", {
        token,
        answers,
      });
      setOpenDialog(false);
      return;
    }
    submitMutation.mutate(reportData);
  };

  // This function now opens the dialog
  const handleSubmit = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setOpenDialog(true);
  };

  // ---------- Render ----------
  if (isValidating) {
    return (
      <AppTheme>
        <CssBaseline enableColorScheme />
        <PageContainer sx={{ maxHeight: "100dvh" }}>
          <Typography>Validerar länk...</Typography>
        </PageContainer>
      </AppTheme>
    );
  }

  if (validationError || validation?.valid === false) {
    return (
      <AppTheme>
        <CssBaseline enableColorScheme />
        <PageContainer sx={{ maxHeight: "100dvh" }}>
          <Typography variant="h4" sx={{ mb: 1 }}>
            Ogiltig inbjudan
          </Typography>
          <Typography color="error">
            {(validationError as Error)?.message ||
              "Länken är ogiltig eller har gått ut."}
          </Typography>
        </PageContainer>
      </AppTheme>
    );
  }

  return (
    <AppTheme>
      <CssBaseline enableColorScheme />
      <PageContainer
        sx={{
          //maxHeight: '100dvh',
          flexDirection: "column",
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        <Box sx={{ width: "50%", height: "100%" }}>
          <Typography
            variant="h4"
            className={styles.signInText}
            sx={{ mb: 2, textAlign: "left" }}
          >
            {validation?.consultantName
              ? `Skriv Rapport för ${validation?.consultantName}`
              : "Skriv Rapport"}
          </Typography>

          {submitMutation.isSuccess && (
            <Typography sx={{ mb: 2 }}>
              Tack! Din rapport har skickats.
            </Typography>
          )}

          {submitMutation.isError && (
            <Typography color="error" sx={{ mb: 2, textAlign: "left" }}>
              {(submitMutation.error as any)?.response?.data?.message ||
                "Misslyckades att skicka rapporten."}
            </Typography>
          )}

          <Box
            component="form"
            onSubmit={handleSubmit}
            sx={{ display: submitMutation.isSuccess ? "none" : "block" }}
          >
            {isLoadingQuestions ? (
              <>
                <Skeleton variant="text" width="80%" sx={{ mb: 2 }} />
                <Skeleton variant="rectangular" height={60} sx={{ mb: 2 }} />
                <Skeleton variant="rectangular" height={90} sx={{ mb: 2 }} />
                <Skeleton
                  variant="rectangular"
                  height={40}
                  sx={{ float: "right", width: "150px" }}
                />
              </>
            ) : (
              <>
                {(questions || []).map((q) => renderQuestion(q))}

                <Button
                  type="submit"
                  sx={{ backgroundColor: "#be0170", float: "right" }}
                  color="pink"
                  variant="contained"
                  endIcon={<SendIcon />}
                  disabled={submitMutation.isLoading || !questions?.length}
                >
                  {submitMutation.isLoading ? "Skickar..." : "Skicka rapport"}
                </Button>
              </>
            )}
          </Box>
        </Box>
      </PageContainer>
      {/* Confirmation Dialog */}
      <Dialog
        open={openDialog}
        onClose={() => setOpenDialog(false)}
        aria-labelledby="confirmation-dialog-title"
        aria-describedby="confirmation-dialog-description"
      >
        <DialogTitle id="confirmation-dialog-title">Skicka rapport</DialogTitle>
        <DialogContent>
          <DialogContentText id="confirmation-dialog-description">
            Är du säker på att du vill skicka in din rapport?
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setOpenDialog(false)}>Avbryt</Button>
          <Button onClick={handleConfirmSubmit} autoFocus>
            Skicka
          </Button>
        </DialogActions>
      </Dialog>
    </AppTheme>
  );
};

export default FormPage;
