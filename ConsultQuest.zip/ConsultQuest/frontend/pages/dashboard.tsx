import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/router';
import AppTheme from '../theme/AppTheme';
import CssBaseline from '@mui/material/CssBaseline';

import PageContainer from '../components/PageContainer';
import Navbar from '../components/Navbar';
import { Grid, Stack, Typography, Box, Modal, Paper } from '@mui/material';
import OutlinedCard from '../components/Cards/OutlinedCard';
import ReportTable from '../components/ReportTable';
import ReportsChart from '../components/ReportsChart';
import CompanyScoresChart from '../components/CompanyScoresChart';
import axios from 'axios';
import { useQuery } from 'react-query';
import { api } from '../api';
import ViewReportModal from '../components/ViewReportModal';

interface TrendDTO {
  text: string;
  direction: 'increase' | 'decrease' | 'stable';
  changeValue: number;
}

interface Report {
  id: number;
  company: string;
  consultant: string;
  overallScore: number;
  createdDate: string;
  status: boolean;
}

const mockReports = [
  { id: 1, company: 'SAAB', consultant: 'Malin', overallScore: 8.2, createdDate: '2024-05-20', status: true },
  { id: 2, company: 'Bankgirot', consultant: 'David', overallScore: 7.5, createdDate: '2024-05-19', status: false },
  { id: 3, company: 'Scania', consultant: 'Tomi', overallScore: 9.0, createdDate: '2024-05-18', status: true },
  { id: 4, company: 'Taxi Stockholm', consultant: 'Malin', overallScore: 6.8, createdDate: '2024-05-17', status: false },
  { id: 5, company: 'SAAB', consultant: 'David', overallScore: 8.8, createdDate: '2024-05-16', status: true },
];

const retrieveReports = async () => { 
  const { data } = await api.get('/api/form/allResponses');
  return data; };

const retrieveDashboardData = async () => {
  const { data } = await api.get('/api/form/dashboardData');
  return data; 
 };

const retrieveDailyAverage = async () => {
  const { data } = await api.get('/api/form/daily-averages');
  return data; 
 };


export default function Dashboard() {
  const router = useRouter();
  //const [reports, setReports] = useState([]);
  //const [loading, setLoading] = useState(true);
  //const [error, setError] = useState(null);
  const [open, setOpen] = useState(false);
  const [currentReportId, setCurrentReportId] = useState<number | null>(null);

  const {
      data: reports,
      error: error,
      isLoading: loading,
    } = useQuery("dashboardDataResponses", retrieveReports, {
    select: (reports: any[]) =>
      reports.map((report) => ({
        id: report.submissionId,
        company: report.clientName,
        consultant: report.consultantName,
        overallScore: report.overallScore,
        createdDate: new Date(report.submissionDate),
        status: report.status,
      })),
  }
    );


  const {
      data: dashboardData,
      error: dashboardDataError,
      isLoading: dashboardDataLoading,
    } = useQuery("dashboardData", retrieveDashboardData);


  const { data: dailyAverageData,
          error: dailyAverageError,
          isLoading: dailyAverageLoading,
   } = useQuery(["dailyAverageData", dashboardData], retrieveDailyAverage); // if new dashboardData reload this might be computational expensive?

    //Auto-open on initial load if ?report= exists
    //so if someone sends a link to a specific report it opens directly
  useEffect(() => {
    if (!router.isReady) return;
    const raw = router.query.report ?? router.query.reportId;
    const val = Array.isArray(raw) ? raw[0] : raw;
    const idNum = val ? Number(val) : NaN;
    if (!Number.isNaN(idNum)) {
      setCurrentReportId(idNum);
      setOpen(true);
    }
  }, [router.isReady, router.query]);


  /*useEffect(() => {
    // Simulera en API-hämtning
    setLoading(true);
    setError(null);
    try {

      setTimeout(() => {
        setReports(mockReports);
        setLoading(false);
      }, 1000); 
    } catch (err: any) {
      setError('Kunde inte ladda rapporter.');
      setLoading(false); 
    }
  }, []);*/
  const handleClose = () => {
    setOpen(false);
    //setCurrentReportId(null);
    router.replace(
    { pathname: router.pathname, query: {} },
    undefined,
    { shallow: true });
  }

  const handleOpen = (id: number) => {
    setCurrentReportId(id);
    setOpen(true);
      router.replace(
    { pathname: router.pathname, query: { ...router.query, report: id } },
    undefined,
    { shallow: true });
    console.log("Klickar på rad:" + id);
  }

  const averageScore = dashboardData?.totalResponses > 0
    ? dashboardData?.averageScore.toFixed(1)
    : 'N/A';

  const totalReports = dashboardData?.totalResponses || 0; 

  const monthlyReports = dashboardData?.monthlyResponses;

  return (
    <AppTheme>
      <CssBaseline enableColorScheme />
      <Navbar/> 
      <ViewReportModal open={open} currentReportId={currentReportId} handleClose={handleClose}></ViewReportModal>
      <PageContainer sx={{ minHeight: '100dvh', height: 'auto' }}>
        <Grid container spacing={2} sx={{ mt: '50px', maxHeight: '80dvh' }}>
          <Grid size={4}>
            <OutlinedCard 
              label='Rapporter denna månad' 
              content={monthlyReports} 
              tooltip={`Antal nya rapporter som inkommit under den pågående månaden.`} 
              trend={dashboardData?.monthlyResponsesTrend}
              loading={dashboardDataLoading}>
            </OutlinedCard> 
          </Grid>
          <Grid size={4}>
            <OutlinedCard 
              label='Total mängd rapporter' 
              content={totalReports.toString()} 
              tooltip='Det totala antalet rapporter som har skickats in i systemet sedan start.' 
              trend={dashboardData?.totalResponsesTrend}
              loading={dashboardDataLoading}>
            </OutlinedCard>
          </Grid>
          <Grid size={4}>
            <OutlinedCard 
              label='Genomsnittligt betyg' 
              content={averageScore} 
              tooltip='Det genomsnittliga betyget från alla inskickade rapporter. Skalan är 1-10.' 
              trend={dashboardData?.averageScoreTrend}
              loading={dashboardDataLoading}>
            </OutlinedCard>
          </Grid>
        </Grid>
        {error || dashboardDataError || dailyAverageError? <Typography sx={{
              textAlign: 'left',
              color: 'error.main',
              fontSize: 12,
              fontFamily: 'Helvetica',
              pt: 2,
              minHeight: 10
            }}
          > Något gick fel vid inläsning av data, försök igen senare.
          </Typography> : null}
        <Grid container spacing={2} sx={{ mt: '10px', maxHeight: '80dvh' }}>
            <Grid size={4}>
              <Stack spacing={2}>
              <ReportsChart dailyAverageData={dailyAverageData || []} loading={loading || dailyAverageLoading} description="Denna graf visar utvecklingen av det genomsnittliga totalbetyget över tid, baserat på alla inskickade rapporter." />
              <CompanyScoresChart reports={reports || []} loading={loading} description="Denna graf visar en översikt av det genomsnittliga betyget för varje enskild kund. Det ger en inblick i hur varje kund värderar samarbetet." />
              </Stack>
            </Grid>
          <Grid size={8}>
            <ReportTable reports={reports || []} loading={loading} handleOpen={handleOpen} />
          </Grid>
        </Grid>
      </PageContainer>
      
    
    </AppTheme>
  );
}