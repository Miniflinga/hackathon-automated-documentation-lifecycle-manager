import { Box, Card, Typography, Button } from "@mui/material";
import AppTheme from '../theme/AppTheme';
import PageContainer from '../components/PageContainer';
import DoNotDisturbIcon from '@mui/icons-material/DoNotDisturb';

export default function ForbiddenPage() {
  return (
    <AppTheme>
      <PageContainer>
        <Card
          variant="outlined"
          sx={{
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            justifyContent: "center",
            p: 4,
            gap: 2,
          }}
        >
            <DoNotDisturbIcon/>
          <Typography
            component="h1"
            variant="h4"
            sx={{
              fontSize: "clamp(2rem, 6vw, 2.5rem)",
              fontFamily: "AlmarenaNeue",
              textAlign: "center",
            }}
          >
            Access Denied
          </Typography>

          <Typography variant="body1" sx={{ textAlign: "center", maxWidth: 400 }}>
            You don’t have permission to view this page.
          </Typography>

          <Button
            href="/"
            variant="contained"
            sx={{ mt: 2 }}
          >
            Go back home
          </Button>
        </Card>
      </PageContainer>
    </AppTheme>
  );
}
