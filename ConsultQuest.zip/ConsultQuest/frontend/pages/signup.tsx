// pages/signup.tsx
import React, { useMemo, useState } from "react";
import { useRouter } from "next/router";
import UserForm, { UserFormValues } from "../components/UserForm";
import { useCreateUser, useTeams } from "../hooks/users";

export default function SignupPage() {
  const router = useRouter();
  const { data: teams = [], isLoading: teamsLoading, isError: teamsError } = useTeams();
  const create = useCreateUser({ onSuccess: () => router.push("/admin") });

  const [values, setValues] = useState<UserFormValues>({
    firstName: "", lastName: "", email: "", roles: [], teamIds: [],
  });

  const errorMsg = useMemo(() => {
    if (teamsError) return "Kunde inte ladda team.";
    const mErr = (create.error as any)?.response?.data?.message;
    return mErr ?? null;
  }, [teamsError, create.error]);

  return (
    <UserForm
      title="Skapa en ny användare"
      submitLabel="Skicka inbjudan"
      values={values}
      teams={teams}
      loading={teamsLoading || create.isLoading}
      errorMsg={errorMsg}
      successMsg={create.isSuccess ? "Inbjudan skickades!" : null}
      onChange={setValues}
      onSubmit={(v) => create.mutate(v)}
    />
  );
}
