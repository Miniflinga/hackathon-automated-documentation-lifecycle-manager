import React, { useEffect, useState } from "react";
import AppTheme from "../theme/AppTheme";
import CssBaseline from "@mui/material/CssBaseline";

import PageContainer from "../components/PageContainer";
import Navbar from "../components/Navbar";
import { useMe } from "../hooks/users";
import {
  Grid,
  Button,
  Stack,
  Dialog,
  DialogActions,
  DialogContent,
  DialogContentText,
  DialogTitle,
  Typography,
} from "@mui/material";
import SendIcon from "@mui/icons-material/Send";

import CardDropDown from "../components/Cards/CardDropDown";
import CardTextField from "../components/Cards/CardTextField";
import CardReportPreview from "../components/Cards/CardReportPreview";
import { DropDownOption } from "../components/Cards/types";

import { useQuery, useMutation } from "react-query";
import { api } from "../api";

const retrieveClients = async () => {
  const { data } = await api.get("/api/users/clients");
  return data;
};

const retrieveConsultants = async () => {
  const { data } = await api.get("/api/users/consultants");
  return data;
};

const retrieveFormTemplateNames = async () => {
  const { data } = await api.get("/api/form/formTemplateNames");
  return data;
};

export default function CreateFormInvite() {
  const [formTemplateName, setFormTemplateName] =
    useState<DropDownOption | null>(null);
  const [consultantEmail, setConsultantEmail] = useState("");

  const { data: me, isLoading: isLoadingMe, error: meError } = useMe();
  // Store full objects instead of IDs
  const [client, setClient] = useState<DropDownOption | null>(null);
  const [consultant, setConsultant] = useState<DropDownOption | null>(null);
  const [clientEmail, setClientEmail] = useState("");

  const [error, setError] = useState("");
  const [successMessage, setSuccessMessage] = useState("");
  const [openDialog, setOpenDialog] = useState(false); // State for the dialog

  const {
    data: clients,
    error: clientsError,
    isLoading: isLoadingClients,
  } = useQuery("clients", retrieveClients);

  const {
    data: consultants,
    error: consultantsError,
    isLoading: isLoadingConsultants,
  } = useQuery("consultants", retrieveConsultants, {
    select: (consultants) =>
      consultants.map(
        (user: {
          id: number;
          firstName: string;
          lastName: string;
          email: string;
        }) => ({
          id: user.id,
          name: `${user.firstName} ${user.lastName}`,
          email: user.email,
        })
      ),
  });

  const {
    data: formTemplateNames,
    error: formTemplateNamesError,
    isLoading: isLoadingFormTemplateNames,
  } = useQuery("formTemplateNames", retrieveFormTemplateNames, {
    select: (formTemplateNames) =>
      formTemplateNames.map((formName: string, index: number) => ({
        id: index,
        name: formName,
      })),
  });

  // Set default form template name when data is loaded
  useEffect(() => {
    if (formTemplateNames && formTemplateNames.length > 0) {
      setFormTemplateName(formTemplateNames[0]);
      console.log("Default form template set to:", formTemplateNames[0].name);
    }
  }, [formTemplateNames]);

  // Fetch questions for the preview when formTemplateName changes
  const { data: questions, isLoading: loadingQuestions } = useQuery(
    ["formPreview", formTemplateName?.name],
    async () => {
      const { data } = await api.get(`/api/form/${formTemplateName?.name}`);
      return data.questions || [];
    },
    {
      enabled: !!formTemplateName, // Only run query if formTemplateName is selected
    }
  );

  const isValidEmail = (email: string) => /\S+@\S+\.\S+/.test(email);

  // Handles opening the confirmation dialog
  const handleOpenDialog = (event: React.FormEvent) => {
    event.preventDefault();
    setError("");
    setSuccessMessage("");

    if (isLoadingMe) {
      setError("Hämtar inloggad användare...");
      return;
    }
    if (!me) {
      setError("Kunde inte hämta inloggad användare. Försök igen.");
      return;
    }

    if (!client || !consultant) {
      setError("Välj kund och konsult");
      return;
    }

    if (!clientEmail) {
      setError("Ange kundens email");
      return;
    }

    if (!isValidEmail(clientEmail)) {
      setError("Ange en giltig emailadress");
      return;
    }
    // If validation passes, open the dialog
    setOpenDialog(true);
  };

  const sendInviteMutation = useMutation(
    (formInviteDTO: any) => api.post("/api/invites/form", formInviteDTO),
    {
      onSuccess: () => {
        setSuccessMessage(`Inbjudan skickades till ${clientEmail}!`);
        setClient(null);
        setConsultant(null);
        setClientEmail("");
        // Keep the form template name selected
      },
      onError: (err: any) => {
        const message =
          err.response?.data?.message || "Misslyckades att skicka inbjudan";
        setError(message);
      },
    }
  );

  // Handles the actual form submission after confirmation
  const handleConfirmSend = async () => {
    setOpenDialog(false); // Close dialog

    const formInviteDTO = {
      formTemplateName: formTemplateName?.name,
      consultantEmail: consultant?.email,
      userId: me!.id,
      consultantId: consultant?.id,
      clientId: client?.id,
      clientEmail,
    };

    sendInviteMutation.mutate(formInviteDTO);
  };

  return (
    <AppTheme>
      <CssBaseline enableColorScheme />
      <Navbar isAdmin={true} />
      <PageContainer sx={{ minHeight: "100dvh" }}>
        <Grid container spacing={2} sx={{ mt: "50px" }}>
          <Grid size={4}>
            <Stack spacing={2} component="form" onSubmit={handleOpenDialog}>
              {/* Customers dropdown */}
              <CardDropDown
                title="Vilken kund ska ta emot formuläret?"
                label="Välj kund"
                tooltipDescription="Mottagande kund"
                menuItems={clients || []}
                value={client}
                getOptionLabel={(option) => option.name}
                isOptionEqualToValue={(option, val) => option.id === val.id}
                onChange={setClient}
                isLoading={isLoadingClients}
                errorText="Något gick fel, kunder kunde inte hämtas"
                isError={!!clientsError}
              />

              <CardTextField
                label="Vad är kundens email?"
                description="Denna mail tar emot formuläret."
                value={clientEmail}
                onChange={setClientEmail}
              />

              {/* Consultants dropdown */}
              <CardDropDown
                title="För vilken konsult gäller formuläret?"
                tooltipDescription="Formulärets resultat kommer appliceras på den angivna konsult."
                label="Välj konsult"
                menuItems={consultants || []}
                value={consultant}
                getOptionLabel={(option) => option.name}
                isOptionEqualToValue={(option, val) => option.id === val.id}
                onChange={(selected) => {
                  setConsultant(selected);
                  setConsultantEmail(selected?.email || "");
                }}
                isLoading={isLoadingConsultants}
                errorText="Något gick fel, konsulter kunde inte hämtas"
                isError={!!consultantsError}
              />

              {/* Form template dropdown */}
              <CardDropDown
                title="Välj formulärsmall"
                tooltipDescription="Formulärsmallar som är tillgängliga i systemet. Välj den mall som passar bäst för ditt ändamål."
                menuItems={formTemplateNames || []}
                value={formTemplateName}
                getOptionLabel={(option) => option.name}
                isOptionEqualToValue={(option, val) => option.id === val.id}
                onChange={setFormTemplateName}
                isLoading={isLoadingFormTemplateNames}
                errorText="Något gick fel, formulärmallar kunde inte hämtas"
                isError={!!formTemplateNamesError}
              />

              <Button
                type="submit"
                color="pink"
                variant="contained"
                endIcon={<SendIcon />}
                fullWidth
                disabled={sendInviteMutation.isLoading}
                sx={{
                  "&:hover": {
                    backgroundColor: "#bf0170",
                  },
                  mt: "-2px",
                }}
              >
                {sendInviteMutation.isLoading
                  ? "Skickar..."
                  : isLoadingMe
                  ? "Laddar användare..."
                  : "Skicka formulär"}
              </Button>
              {meError && (
                <Typography color="error">
                  Kunde inte hämta inloggad användare.
                </Typography>
              )}
              {error && <Typography color="error">{error}</Typography>}
              {successMessage && (
                <Typography color="success.main">{successMessage}</Typography>
              )}
            </Stack>
          </Grid>

          <Grid size={8} sx={{ overflow: "auto", maxHeight: "91dvh" }}>
            <CardReportPreview
              label="Förhandsgranskning av formulär"
              questions={questions || []}
              loading={loadingQuestions}
              minHeight={100}
            />
          </Grid>
        </Grid>
      </PageContainer>

      {/* Confirmation Dialog */}
      <Dialog
        open={openDialog}
        onClose={() => setOpenDialog(false)}
        aria-labelledby="confirmation-dialog-title"
        aria-describedby="confirmation-dialog-description"
      >
        <DialogTitle id="confirmation-dialog-title">
          Bekräfta utskick
        </DialogTitle>
        <DialogContent>
          <DialogContentText id="confirmation-dialog-description">
            Är du säker på att du vill skicka denna formulärinbjudan till{" "}
            {client?.name || "den valda kunden"} ({clientEmail})?
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setOpenDialog(false)}>Avbryt</Button>
          <Button onClick={handleConfirmSend} autoFocus>
            Skicka
          </Button>
        </DialogActions>
      </Dialog>
    </AppTheme>
  );
}
