import React, { useState } from "react";
import { useRouter } from "next/router";
import AppTheme from "../../theme/AppTheme";
import CssBaseline from "@mui/material/CssBaseline";

import PageContainer from "../../components/PageContainer";
import Navbar from "../../components/Navbar";
import { Grid, Stack, Typography } from "@mui/material";
import { useQuery } from "react-query";
import ProfileCard from "../../components/Cards/ProfileCard";
import OutlinedCard from "../../components/Cards/OutlinedCard";
import ReportTable from "../../components/ReportTable";
import ReportsChart from "../../components/ReportsChart";
import { api } from "../../api";
import { RadarChart } from "@mui/x-charts";
import RadarChartCard from "../../components/Cards/RadarChartCard";
import ViewReportModal from "../../components/ViewReportModal";

interface Answer {
  question: {
    category: "NUMERIC" | "TEXT";
    questionText: string;
  };
  numericalContent: number | null;
}

const retrieveProfile = async (userId: string) => {
  const { data } = await api.get(`/api/users/profile/${userId}`);
  return data;
};

export default function Profile() {
  const router = useRouter();
  const { id: userId } = router.query;
  const [open, setOpen] = useState(false);
  const [currentReportId, setCurrentReportId] = useState<number | null>(null);

  const { data: userProfile, isLoading: isProfileLoading } = useQuery(
    ["userProfile", userId],
    () => retrieveProfile(userId as string),
    {
      enabled: !!userId, // Only run query if userId is available
    }
  );

  const reports = React.useMemo(() => {
    if (!userProfile?.reports) return [];
    return userProfile.reports.map((report: any) => ({
      id: report.submissionId,
      company: report.clientName,
      consultant: report.consultantName,
      overallScore: report.overallScore,
      createdDate: new Date(report.submissionDate),
      status: report.status,
    }));
  }, [userProfile]);

  const handleClose = () => {
    setOpen(false);
    //setCurrentReportId(null);
  };

  const handleOpen = (id: number) => {
    setCurrentReportId(id);
    setOpen(true);
    console.log("Klickar på rad:" + id);
  };

  const areReportsLoading = isProfileLoading;
  const error = null; // Or handle error from userProfile query

  const averageScore =
    reports && reports.length > 0
      ? (
          reports.reduce(
            (acc: number, report: { overallScore: number }) =>
              acc + report.overallScore,
            0
          ) / reports.length
        ).toFixed(1)
      : "N/A";

  const radarChartReport = React.useMemo(() => {
    if (!userProfile?.reports || userProfile.reports.length === 0) {
      return { answers: [] as Answer[] };
    }

    const scoresByQuestion: {
      [key: string]: { total: number; count: number };
    } = {};

    userProfile.reports.forEach((report: any) => {
      report.answers.forEach((answer: any) => {
        if (
          answer.question?.category === "NUMERIC" &&
          answer.numericalContent !== null
        ) {
          const questionText = answer.question.questionText;
          if (!scoresByQuestion[questionText]) {
            scoresByQuestion[questionText] = { total: 0, count: 0 };
          }
          scoresByQuestion[questionText].total += answer.numericalContent;
          scoresByQuestion[questionText].count += 1;
        }
      });
    });

    const averagedAnswers: Answer[] = Object.entries(scoresByQuestion).map(
      ([questionText, data]) => ({
        question: { category: "NUMERIC" as const, questionText },
        numericalContent: data.total / data.count,
      })
    );

    return { answers: averagedAnswers };
  }, [userProfile]);

  return (
    <AppTheme>
      <CssBaseline enableColorScheme />
      <Navbar />
      <ViewReportModal
        open={open}
        currentReportId={currentReportId}
        handleClose={handleClose}
      ></ViewReportModal>
      <PageContainer sx={{ minHeight: "100dvh", height: "auto" }}>
        <Grid container spacing={2} sx={{ mt: "50px" }}>
          <Grid size={4}>
            {isProfileLoading ? (
              <OutlinedCard label="Loading..." content="" />
            ) : (
              <ProfileCard
                firstname={userProfile?.firstName}
                lastname={userProfile?.lastName}
                email={userProfile?.email}
                profilepicture={userProfile?.profileIcon}
                tooltipDescription="Information about the consultant."
              />
            )}
          </Grid>
          <Grid size={4}>
            <OutlinedCard
              label="Senaste kund"
              content={reports?.[0]?.company ?? "..."}
              description={`Team: ${userProfile?.team ?? "..."}`}
            ></OutlinedCard>
          </Grid>
          <Grid size={4}>
            <OutlinedCard
              label="Genomsnittligt betyg"
              content={averageScore}
              description={"Av alla rapporter"}
            ></OutlinedCard>
          </Grid>
        </Grid>
        {error ? (
          <Typography
            sx={{
              textAlign: "left",
              color: "error.main",
              fontSize: 12,
              fontFamily: "Helvetica",
              pt: 2,
              minHeight: 10,
            }}
          >
            {" "}
            Något gick fel vid inläsning av data, försök igen senare.
          </Typography>
        ) : null}
        <Grid container spacing={2} sx={{ mt: "10px" }}>
          <Grid size={4}>
            <Stack spacing={2}>
              <ReportsChart
                dailyAverageData={userProfile?.dailyAverages || []}
                loading={areReportsLoading}
              />
              <RadarChartCard
                label="Genomsnittliga betyg per kategori"
                report={radarChartReport}
              />
            </Stack>
          </Grid>
          <Grid size={8}>
            <ReportTable
              reports={reports || []}
              loading={areReportsLoading}
              handleOpen={handleOpen}
            />
          </Grid>
        </Grid>
      </PageContainer>
    </AppTheme>
  );
}
