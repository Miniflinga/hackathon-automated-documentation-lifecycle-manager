import React from 'react';
import AppTheme from '../theme/AppTheme';
import CssBaseline from '@mui/material/CssBaseline';
import PageContainer from '../components/PageContainer';
import AdminUserTable from '../components/AdminUserTable';
import Navbar from '../components/Navbar';
import type { NextPage } from 'next';


const AdminPage: NextPage = () => {


  return (
      <AppTheme>
          <CssBaseline enableColorScheme />
                <Navbar isAdmin={true} /> 

          <PageContainer sx={{ maxWidth: '100%' }}>
    
                <AdminUserTable />
          </PageContainer>
      </AppTheme> 
  );
}

export default AdminPage;
