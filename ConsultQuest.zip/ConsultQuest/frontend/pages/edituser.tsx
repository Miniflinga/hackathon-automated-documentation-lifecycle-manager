import React, { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/router";
import UserForm, { UserFormValues } from "../components/UserForm";
import { useTeams, useUpdateUser, useUser } from "../hooks/users";

export default function EditUserPage() {
  const router = useRouter();
  const idParam = router.query.id;
  const id = Array.isArray(idParam) ? Number(idParam[0]) : Number(idParam);
  if (!id || Number.isNaN(id)) return null;

  const { data: teams = [], isLoading: teamsLoading, isError: teamsError } = useTeams();
  const { data: user, isLoading: userLoading, isError: userError } = useUser(id, true);
  const update = useUpdateUser(id, { onSuccess: () => router.push("/admin") });

  const [values, setValues] = useState<UserFormValues>({
    firstName: "", lastName: "", email: "", roles: [], teamIds: [],
  });

  useEffect(() => {
    if (user) {
      setValues({
        firstName: user.firstName ?? "",
        lastName: user.lastName ?? "",
        email: user.email ?? "",
        roles: user.roles ?? [],
        teamIds: user.teamIds ?? [],
      });
    }
  }, [user]);

  const loading = teamsLoading || userLoading || update.isLoading;
  const errorMsg = useMemo(() => {
    if (teamsError || userError) return "Kunde inte ladda data.";
    const mErr = (update.error as any)?.response?.data?.message;
    return mErr ?? null;
  }, [teamsError, userError, update.error]);

  return (
    <UserForm
      title="Edit User"
      submitLabel="Spara ändringar"
      values={values}
      teams={teams}
      loading={loading}
      errorMsg={errorMsg}
      successMsg={update.isSuccess ? "Ändringarna sparades" : null}
      onChange={setValues}
      onSubmit={(v) => update.mutate(v)}
    />
  );
}
