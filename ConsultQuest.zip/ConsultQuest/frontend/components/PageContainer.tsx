import { styled } from "@mui/material/styles";
import Box from "@mui/material/Box";

const PageContainer = styled(Box)(({ theme }) => ({
  display: "flex",
  flexDirection: "column",
  justifyContent: "center",
  minHeight: "100dvh",
  padding: theme.spacing(2),

  [theme.breakpoints.up("sm")]: {
    padding: theme.spacing(4),
  },
}));

export default PageContainer;
