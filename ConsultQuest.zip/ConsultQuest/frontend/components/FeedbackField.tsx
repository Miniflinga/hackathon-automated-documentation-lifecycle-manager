import React from 'react';
import { Box, Typography, TextField, Card, CardContent } from '@mui/material';

interface FeedbackFieldProps {
  title?: string;
  label?: string;
  value?: string;
  onChange: (value: string) => void;
  maxLength?: number;
}

export default function FeedbackField({
  title = "Återkoppling",
  label = "Skriv ytterligare återkoppling här",
  value = "",
  onChange,
  maxLength = 500,
}: FeedbackFieldProps) {
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newValue = e.target.value;
    if (newValue.length <= maxLength) {
      onChange(newValue);
    }
  };

  return (
    <Box alignItems={"center"} sx={{ width: '100%', py: 1 }}>
      <Card variant="outlined" sx={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
        <CardContent sx={{ flexGrow: 1, display: 'flex', flexDirection: 'column' }}>
          <Typography sx={{ fontSize: '1rem', fontWeight: 'bold', textAlign: 'left' }}>{title}</Typography>
          <TextField
            fullWidth
            hiddenLabel
            id="feedback"
            placeholder={label}
            variant="standard"
            InputProps={{
              disableUnderline: true,
              sx: {
                padding: '8px 0px',
                fontSize: '0.875rem',
                flexGrow: 1,
                alignItems: 'flex-start'
              }
            }}
            name="feedback"
            multiline
            rows={4} 
            value={value}
            onChange={handleChange}
            sx={{ flexGrow: 1 }}
          />
          <Typography
            variant="caption"
            sx={{ textAlign: 'right', color: 'text.secondary', alignSelf: 'flex-end' }}
          >
            {value?.length || 0} / {maxLength}
          </Typography>
        </CardContent>
      </Card>
    </Box>
  );
}