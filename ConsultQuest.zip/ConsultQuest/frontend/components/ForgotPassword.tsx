  import * as React from 'react';
  import Button from '@mui/material/Button';
  import Dialog from '@mui/material/Dialog';
  import DialogActions from '@mui/material/DialogActions';
  import DialogContent from '@mui/material/DialogContent';
  import DialogContentText from '@mui/material/DialogContentText';
  import DialogTitle from '@mui/material/DialogTitle';
  import OutlinedInput from '@mui/material/OutlinedInput';
  import { useMutation } from 'react-query';
  import { api } from '../api'; // adjust the path if needed

  interface ForgotPasswordProps {
    open: boolean;
    handleClose: () => void;
  }

  export default function ForgotPassword({ open, handleClose }: ForgotPasswordProps) {

    const [email, setEmail] = React.useState('');

    const resetPasswordMutation = useMutation(
      (email: string) =>
        api.post('/api/invites/reset-password', email, {
          headers: { 'Content-Type': 'text/plain;charset=UTF-8' },
        }),
      {
        onSettled: () => {
          // Always show the same UX to avoid user enumeration
          handleClose();
        },
      });

    return (
      <Dialog
        open={open}
        onClose={handleClose}
        slotProps={{
          paper: {
            component: 'form',
            onSubmit: (event: React.FormEvent<HTMLFormElement>) => {
              event.preventDefault();
              resetPasswordMutation.mutate(email.trim());
            },
            sx: { backgroundImage: 'none' },
          },
        }}
      >
        <DialogTitle>Reset password</DialogTitle>
        <DialogContent
          sx={{ display: 'flex', flexDirection: 'column', gap: 2, width: '100%' }}
        >
          <DialogContentText>
            Enter your account&apos;s email address, and we&apos;ll send you a link to
            reset your password.
          </DialogContentText>
          <OutlinedInput
            autoFocus
            required
            margin="dense"
            id="email"
            name="email"
            label="Email address"
            placeholder="Email address"
            type="email"
            fullWidth
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            disabled={resetPasswordMutation.isLoading}
          />
        </DialogContent>
        <DialogActions sx={{ pb: 3, px: 3 }}>
          <Button onClick={handleClose} disabled={resetPasswordMutation.isLoading}>Cancel</Button>
          <Button variant="contained" type="submit" disabled={resetPasswordMutation.isLoading || !email}>
            {resetPasswordMutation.isLoading ? 'Skickar…' : 'Fortsätt'}
          </Button>
        </DialogActions>
      </Dialog>
    );
  }
