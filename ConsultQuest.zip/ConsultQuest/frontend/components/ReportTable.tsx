import * as React from 'react';
import { CircularProgress, Box, Typography, Theme } from '@mui/material';
import Paper from '@mui/material/Paper';
import CheckIcon from '@mui/icons-material/Check';
import ClearIcon from '@mui/icons-material/Clear';
import { SxProps } from '@mui/system';
import { DataGrid, GridColDef } from '@mui/x-data-grid';
import { svSE } from '@mui/x-data-grid/locales'; // Changes language to Swedish


interface Report {
  id: number;
  company: string;
  consultant: string;
  overallScore: number;
  createdDate: Date;
  status: boolean;
}

interface Column {
  id: keyof Report;
  label: string;
  minWidth?: number;
  align?: 'right' | 'center' | 'left';
}

// Kolumndefinitioner för rapporttabellen
const columns: GridColDef[] = [
  { field: 'id', headerName: 'ID', minWidth: 50, type: 'number', align: 'left', headerAlign: 'left'},
  { field: 'company', headerName: 'Kund', minWidth: 170, type: 'string', flex: 2 },
  { field: 'consultant', headerName: 'Konsult', minWidth: 170, type: 'string', flex: 2 },
  { field: 'overallScore', headerName: 'Totalbetyg', minWidth: 100, align: 'center', headerAlign:'center', type: 'number', flex: 1},
  { field: 'createdDate', headerName: 'Skapad', minWidth: 120,
    valueFormatter: (value: Date) => {
      // format how the date displays (e.g. YYYY-MM-DD)
      if(!value) return '';
      return value.toLocaleDateString('sv-SE');
    }, type: 'date', flex: 1},
  { field: 'status', headerName: 'Granskad', minWidth: 100, align: 'center', headerAlign: 'center', type: 'boolean', flex: 1,
    renderCell: (params) =>
      params.value ? <CheckIcon color="success" /> : <ClearIcon color="error" />,
   }
]

export default function ReportTable({ reports = [], loading = false, handleOpen }: { reports: Report[], loading?: boolean, handleOpen:  (id: number) => void}) {
  
  const centerFlex: SxProps<Theme> = { display: 'flex', justifyContent: 'center', alignItems: 'center', flexGrow: 1, minHeight: '200px' };

  return (
    <Paper sx={{ width: '100%', overflow: 'hidden', display: 'flex', flexDirection: 'column', height: '100%' }}>
      {loading && (
        <Box sx={centerFlex}>
          <CircularProgress />
        </Box>
      )}
      {!loading && reports.length === 0 && (
        <Box sx={centerFlex}>
          <Typography variant="body1" color="text.secondary">
            Inga rapporter att visa.
          </Typography>
        </Box>
      )}
      {!loading && reports.length > 0 && (
        <>
      <DataGrid columns={columns} rows={reports} onRowClick={(params) => handleOpen(params.row.id)}
              sx={{
                flexGrow: 1,
          // disable cell selection style
          '.MuiDataGrid-cell:focus': {
            outline: 'none'
          },
          // pointer cursor on ALL rows
          '& .MuiDataGrid-row:hover': {
            cursor: 'pointer'
          },

          '.MuiDataGrid-selectedRowCount': {
            display: 'none'
          },

          '& .MuiDataGrid-columnHeaderTitle': {
            fontWeight: 'bold',
          },
        }}
        pageSizeOptions={[10, 25, 100]}
        localeText={svSE.components.MuiDataGrid.defaultProps.localeText}
        initialState={{
              pagination: {
                paginationModel: {
                  pageSize: 10,
                  page: 0, // Optional: starts at first page
                },
              },
            }}>
      </DataGrid>     
      </>
      )}
    </Paper>
  );
}
