import * as React from 'react';
import { useTheme } from '@mui/material/styles';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import Typography from '@mui/material/Typography';
import { LineChart } from '@mui/x-charts/LineChart';
import { Box, CircularProgress, Tooltip, IconButton } from '@mui/material';
import InfoIcon from '@mui/icons-material/Info';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import 'dayjs/locale/sv';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import dayjs from 'dayjs';
import weekOfYear from 'dayjs/plugin/weekOfYear';
import isoWeek from 'dayjs/plugin/isoWeek';
import advancedFormat from 'dayjs/plugin/advancedFormat';

dayjs.extend(weekOfYear);
dayjs.extend(isoWeek);
dayjs.extend(advancedFormat);
dayjs.locale('sv');

function groupByWeek(data: DailyAverage[]) {
  const weekGroups: Record<string, DailyAverage[]> = {};

  data.forEach(entry => {
    const date = dayjs(entry.date);
    const weekKey = `${date.year()}-W${date.isoWeek()}`;
    if (!weekGroups[weekKey]) {
      weekGroups[weekKey] = [];
    }
    weekGroups[weekKey].push(entry);
  });

  return Object.entries(weekGroups).map(([key, entries]) => {
    const questionMap: Record<number, { total: number; count: number; questionText: string }> = {};

    entries.forEach(entry => {
      entry.averageScores.forEach(({ questionId, score, questionText }) => {
        if (!questionMap[questionId]) {
          questionMap[questionId] = { total: 0, count: 0, questionText };
        }
        questionMap[questionId].total += score;
        questionMap[questionId].count += 1;
      });
    });

    const averageScores = Object.entries(questionMap).map(([id, { total, count, questionText }]) => ({
      questionId: Number(id),
      score: total / count,
      questionText,
    }));

    const weekStart = dayjs(entries[0].date).startOf('isoWeek');
    return {
      date: weekStart.toDate(),
      averageScores,
      submissions: entries.reduce((sum, e) => sum + e.submissions, 0),
    };
  });
}

function groupByMonth(data: DailyAverage[]) {
  const monthGroups: Record<string, DailyAverage[]> = {};

  data.forEach(entry => {
    const date = dayjs(entry.date);
    const monthKey = `${date.year()}-${date.month()}`; // month is 0-indexed
    if (!monthGroups[monthKey]) {
      monthGroups[monthKey] = [];
    }
    monthGroups[monthKey].push(entry);
  });

  return Object.entries(monthGroups).map(([key, entries]) => {
    const questionMap: Record<number, { total: number; count: number; questionText: string }> = {};

    entries.forEach(entry => {
      entry.averageScores.forEach(({ questionId, score, questionText }) => {
        if (!questionMap[questionId]) {
          questionMap[questionId] = { total: 0, count: 0, questionText };
        }
        questionMap[questionId].total += score;
        questionMap[questionId].count += 1;
      });
    });

    const averageScores = Object.entries(questionMap).map(([id, { total, count, questionText }]) => ({
      questionId: Number(id),
      score: total / count,
      questionText,
    }));

    const monthStart = dayjs(entries[0].date).startOf('month');
    return {
      date: monthStart.toDate(),
      averageScores,
      submissions: entries.reduce((sum, e) => sum + e.submissions, 0),
    };
  });
}


function AreaGradient({ color, id }: { color: string; id: string }) {
  return (
    <defs>
      <linearGradient id={id} x1="50%" y1="0%" x2="50%" y2="100%">
        <stop offset="0%" stopColor={color} stopOpacity={0.5} />
        <stop offset="100%" stopColor={color} stopOpacity={0} />
      </linearGradient>
    </defs>
  );
}

export interface DailyAverage {
  date: Date;
  //questions: {questionId: number; text: string};
  averageScores: { questionId: number; score: number, questionText: string }[];
  submissions: number;
} 

export default function ReportsChart({ dailyAverageData = [], loading = false, description = "" }: { dailyAverageData: DailyAverage[], loading?: boolean, description?: string }) {
  const [startDate, setStartDate] = React.useState<dayjs.Dayjs | null>(dayjs().subtract(1, 'year'));
  console.log('DailyAverage', dailyAverageData);
  const [endDate, setEndDate] = React.useState<dayjs.Dayjs | null>(dayjs());
  const theme = useTheme();

  // Define a color palette for chart series
  const colorPalette = [
    theme.palette.primary.main,
    theme.palette.primary.light,
    theme.palette.secondary.main,
    theme.palette.orange.main
  ];

  const { chartData, xAxisData, sortedIds } = React.useMemo(() => {
    if (!dailyAverageData || dailyAverageData.length === 0) {
      return { chartData: [], xAxisData: [], sortedIds: []  };
    }

    const filteredData = dailyAverageData.filter(entry => {
    const entryDate = dayjs(entry.date);
    return (!startDate || entryDate.isAfter(startDate.subtract(1, 'day'))) &&
          (!endDate || entryDate.isBefore(endDate.add(1, 'day')));
    });

    const durationInMonths = endDate?.diff(startDate, 'month', true) ?? 0;

    let aggregatedData: DailyAverage[] = [];

    if (durationInMonths > 12) {
      aggregatedData = groupByMonth(filteredData);
    } else if (durationInMonths > 2) {
      aggregatedData = groupByWeek(filteredData);
    } else {
      aggregatedData = filteredData; // Use raw daily data
    }

    const dates = aggregatedData.map(r => {
      const d = dayjs(r.date);
      if (durationInMonths > 12) {
        return d.format('MMM YYYY'); // "Oct 2025"
      } else if (durationInMonths > 2) {
        return `v. ${d.isoWeek()} (${d.format('MMM D')})`; // "v. 42 (Oct 14)"
      } else {
        return d.format('MMM D'); // "Oct 14"
      }
    });
    /*const dates = filteredData.map(r => {
        const d = new Date(r.date);
        return d.toLocaleDateString('sv-SE', { month: 'short', day: 'numeric' });
      });*/

    const idToAverages: Record<number, number[]> = {};
    const idToQuestionText: Record<number, string> = {};
    // Use aggregatedData instead of sortedDailyReports to match xAxisData
    const sortedAggregatedReports = [...aggregatedData].sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

    for (const entry of sortedAggregatedReports) {
      for (const { questionId, score, questionText } of entry.averageScores) {
        if (!idToAverages[questionId]) {
            idToAverages[questionId] = [];
        } 
        
        idToAverages[questionId].push(score);


        if(!idToQuestionText[questionId]) {
          idToQuestionText[questionId] = questionText;
        } else{
          idToQuestionText[questionId] = questionText; // Update to latest text if changed
        }
      }
    }
    const sortedIds = Object.keys(idToAverages).map(Number).sort((a, b) => a - b);

    const scores = sortedIds.map((id, index) => ({
                  id: `series-${id}`,
                  label: idToQuestionText[id] || `Question ${id}`,
                  showMark: false,
                  stack: 'total',
                  area: true,
                  data: idToAverages[id],
                  color: colorPalette[index % colorPalette.length],
                }));
      return { chartData: scores, xAxisData: dates, sortedIds: sortedIds  };
    
  }, [dailyAverageData, startDate, endDate]);

  // Generate styles for area gradients based on series ids
  const areaGradientStyles = sortedIds?.reduce((styles: Record<string, any>, id) => {
      styles[`& .MuiAreaElement-series-series-${id}`] = {
        fill: `url('#gradient-${id}')`,
      };
      return styles;
    }, {} as Record<string, any>);

  if (loading) {
    return (
      <Card variant="outlined" sx={{ width: '100%', height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <CircularProgress />
      </Card>
    );
  }

  if (dailyAverageData?.length === 0) {
      return (
        <Card variant="outlined" sx={{ width: '100%', height: '100%', position: "relative"}}>
            {description && (
              <Tooltip title={description} placement="top-start">
                <IconButton
                  aria-label="info"
                  size="small"
                  sx={{
                    position: "absolute",
                    top: 8,
                    right: 0,
                    backgroundColor: "transparent",
                    borderRadius: "100%",
                    width: "10px",
                    height: "10px",
                    mr: 2,
                    mt: 1,
                  }}
                >
                  <InfoIcon fontSize="small" />
                </IconButton>
              </Tooltip>
            )}
            <CardContent>
                <Typography component="h2" variant="subtitle2" gutterBottom>
                    Totalbetyg över tid
                </Typography>
                <Box sx={{height: 250, display: 'flex', alignItems: 'center', justifyContent: 'center'}}>
                    <Typography variant="body1" color="text.secondary">
                        Ingen data att visa.
                    </Typography>
                </Box>
            </CardContent>
        </Card>
      )
  }

  return (
    <Card variant="outlined" sx={{ width: '100%', position: "relative" }}>
      <CardContent>
       
          <Typography gutterBottom variant="body1" sx={{ textAlign: 'left', color: 'text.secondary', fontSize: 16, fontFamily: 'Helvetica', paddingBottom: 2 }}>
              Totalbetyg över tid
          </Typography>
          {description && (
        <Tooltip title={description} placement="top-start">
          <IconButton
            aria-label="info"
            size="small"
            sx={{
              position: "absolute",
              top: 8,
              right: 0,
              backgroundColor: "transparent",
              borderRadius: "100%",
              width: "10px",
              height: "10px",
              mr: 2,
              mt: 1,
            }}
          >
            <InfoIcon fontSize="small" />
          </IconButton>
        </Tooltip>
      )}
            <LocalizationProvider dateAdapter={AdapterDayjs} adapterLocale="sv">
                  <Box display="flex" alignItems="right" width="100%" sx={{position: 'absolute', top: 40, right: 16, justifyContent: 'flex-end'}}>
                      <DatePicker
                        label={"Start datum"}
                        defaultValue={startDate}
                        onChange={(newValue) => setStartDate(newValue)}
                        slotProps={{ field: { shouldRespectLeadingZeros: true }, textField: { size: 'small', sx: { maxWidth: 140 },} }}
                        sx={{marginRight: 0}}
                      />
                      <Typography sx={{ mx: 0.5 }}>-</Typography>
                      <DatePicker
                        label={"Slut datum"}
                        defaultValue={endDate}
                        onChange={(newValue) => setEndDate(newValue)}
                        slotProps={{ field: { shouldRespectLeadingZeros: true }, textField: { size: 'small', sx: { maxWidth: 140 }, } }}
                        sx={{marginLeft: 0}}
                      />
                  </Box>
            </LocalizationProvider>
 
        <LineChart
          xAxis={[
            {
              scaleType: 'point',
              data: xAxisData,
            },
          ]}
          yAxis={[{ min: 0, max: 40 }]}
          series={chartData}
          height={250}
          margin={{ left: 30, right: 20, top: 30, bottom: 30 }}
          grid={{ horizontal: true }}
          sx={areaGradientStyles}
          hideLegend={false}
          slotProps={{
            legend: {
              position: {
                vertical: 'bottom',
                horizontal: 'center',
              },
              direction: 'horizontal',
            },
          }}
        >
          {/*<AreaGradient color={color} id="scoreGradient" />*/}
          {sortedIds?.map((id, index) => (
              <AreaGradient
                key={id}
                id={`gradient-${id}`}
                color={colorPalette[index % colorPalette.length]}
              />
          ))}
        </LineChart>
      </CardContent>
    </Card>
  );
}