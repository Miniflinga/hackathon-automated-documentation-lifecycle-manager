import React from "react";
import {
  Box, FormControl, FormLabel, TextField, Select, MenuItem,
  Button, Alert, Typography, CssBaseline
} from "@mui/material"; import MuiCard from '@mui/material/Card';
import { styled } from "@mui/material/styles";
import Image from "next/image";
import HiqLogo from "/public/assets/logoPink.png";
import AppTheme from "../theme/AppTheme";
import ColorModeSelect from "../theme/ColorModeSelect";
import PageContainer from "./PageContainer";

export type Role = "MANAGER" | "SALES" | "CONSULTANT" | "ADMIN";
export type UserFormValues = {
  firstName: string; lastName: string; email: string; roles: Role[]; teamIds: number[];
};
const Card = styled(MuiCard)(({ theme }) => ({
  display: 'flex',
  flexDirection: 'column',
  alignSelf: 'center',
  width: '100%',
  padding: theme.spacing(4),
  gap: theme.spacing(2),
  margin: 'auto',
  [theme.breakpoints.up('sm')]: {
    maxWidth: '450px',
  },
  boxShadow:
    'hsla(220, 30%, 5%, 0.05) 0px 5px 15px 0px, hsla(220, 25%, 10%, 0.05) 0px 15px 35px -5px',
  ...theme.applyStyles('dark', {
    boxShadow:
      'hsla(220, 30%, 5%, 0.5) 0px 5px 15px 0px, hsla(220, 25%, 10%, 0.08) 0px 15px 35px -5px',
  }),
}));

type Props = {
  title: string;
  submitLabel: string;
  values: UserFormValues;
  teams: Array<{ id: number; name: string }>;
  loading?: boolean;
  errorMsg?: string | null;
  successMsg?: string | null;
  onChange(values: UserFormValues): void;
  onSubmit(values: UserFormValues): void;
};

export default function UserForm({
  title,
  submitLabel,
  values,
  teams,
  loading,
  errorMsg,
  successMsg,
  onChange,
  onSubmit,
}: Props) {
  const set = <K extends keyof UserFormValues>(k: K, v: UserFormValues[K]) =>
    onChange({ ...values, [k]: v });

  return (
    <AppTheme>
      <PageContainer>
        <Card variant="outlined">
          <Box sx={{ display: "flex", justifyContent: "center", mb: 1 }}>
            <Image src={HiqLogo} alt="HiQ Logo" style={{ width: 180, height: "auto" }} />
          </Box>

          <Typography component="h1" variant="h4" sx={{ fontFamily: "AlmarenaNeue" }}>
            {title}
          </Typography>

          {errorMsg && <Alert severity="error" variant="outlined">{errorMsg}</Alert>}
          {successMsg && <Alert severity="success" variant="outlined">{successMsg}</Alert>}

          <Box
            component="form"
            onSubmit={(e) => { e.preventDefault(); onSubmit(values); }}
            sx={{ display: "flex", flexDirection: "column", gap: 2 }}
          >
            <FormControl>
              <FormLabel htmlFor="firstname">Förnamn</FormLabel>
              <TextField
                id="firstName"
                required
                fullWidth
                value={values.firstName}
                onChange={(e) => set("firstName", e.target.value)}
              />
            </FormControl>

            <FormControl>
              <FormLabel htmlFor="lastname">Efternamn</FormLabel>
              <TextField
                id="lastName"
                required
                fullWidth
                value={values.lastName}
                onChange={(e) => set("lastName", e.target.value)}
              />
            </FormControl>

            <FormControl>
              <FormLabel htmlFor="email">Email</FormLabel>
              <TextField
                id="email"
                type="email"
                required
                fullWidth
                value={values.email}
                onChange={(e) => set("email", e.target.value)}
              />
            </FormControl>

            <FormControl>
              <FormLabel>Roll</FormLabel>
              <Select
                multiple
                value={values.roles as unknown as string[]}
                onChange={(e) =>
                  set("roles", (e.target.value as unknown as Role[]) ?? [])
                }
              >
                <MenuItem value={"MANAGER"}>Manager</MenuItem>
                <MenuItem value={"SALES"}>Seller</MenuItem>
                <MenuItem value={"CONSULTANT"}>Consultant</MenuItem>
                <MenuItem value={"ADMIN"}>Admin</MenuItem>
              </Select>
            </FormControl>

            <FormControl>
              <FormLabel>Team</FormLabel>
              <Select
                multiple
                value={values.teamIds.map(String) as unknown as string[]}
                onChange={(e) =>
                  set(
                    "teamIds",
                    ((e.target.value as unknown as string[]) ?? []).map(Number)
                  )
                }
              >
                {teams.map((t) => (
                  <MenuItem key={t.id} value={String(t.id)}>
                    {t.name}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>

            <Button type="submit" variant="contained" color="blue" disabled={!!loading}>
              {loading ? "Laddar..." : submitLabel}
            </Button>
          </Box>
        </Card>
      </PageContainer>
    </AppTheme>
  );
}
