import React from "react";
import {
  Slider,
  Typography,
  Box,
  Tooltip,
  IconButton,
  Card, // Added Card
  Stack, // Added Stack
} from "@mui/material";
import InfoIcon from "@mui/icons-material/Info";

interface ReportSliderProps {
  title?: string;
  description?: string;
  value: number;
  onChange: (value: number) => void;
}

export default function ReportSlider({
  title = "Score",
  description,
  value,
  onChange,
}: ReportSliderProps) {
  const handleChange = (event: Event, newValue: number | number[]) => {
    // We expect a single number value from the slider
    if (typeof newValue === "number") {
      onChange(newValue);
    }
  };

  return (
    <Box sx={{ width: "100%", py: 1 }}>
      <Card variant="outlined" sx={{ p: 2, position: "relative" }}>
        <Typography
          sx={{ fontSize: "1rem", fontWeight: "bold", textAlign: "left" }}
        >
          {title}
        </Typography>
        {description && (
          <Tooltip title={description} placement="top-start">
            <IconButton
              aria-label="info"
              size="small"
              sx={{
                position: "absolute",
                top: 8,
                right: 0,
                backgroundColor: "transparent",
                borderRadius: "100%",
                width: "10px",
                height: "10px",
                mr: 2,
                mt: 1,
              }}
            >
              <InfoIcon fontSize="small" />
            </IconButton>
          </Tooltip>
        )}
        <Slider
          sx={{ color: "#ff98d5" }}
          aria-label={title}
          onChange={handleChange}
          value={value}
          step={1}
          marks
          min={1}
          max={10}
          valueLabelDisplay="auto"
        />
        <Stack direction="row" spacing={2} justifyContent={"space-between"}>
          <Box sx={{ display: "flex", alignItems: "center" }}>
            <Typography sx={{ fontSize: "1rem", fontWeight: "bold" }}>
              1
            </Typography>
          </Box>

          <Box sx={{ display: "flex", alignItems: "center" }}>
            <Typography
              justifyContent="flex-end"
              sx={{ fontSize: "1rem", fontWeight: "bold" }}
            >
              10
            </Typography>
          </Box>
        </Stack>
      </Card>
    </Box>
  );
}
