import * as React from 'react';
import { useTheme } from '@mui/material/styles';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import Typography from '@mui/material/Typography';
import { Box, CircularProgress } from '@mui/material';
import { RadarChart } from '@mui/x-charts/RadarChart';


type Report = {
  id: number; 
  clientName: string;
  consultantName: string;
  submissionDate: Date;
  answers: {
    id: number;
    question: { 
        id: number; 
        questionText: string; 
        category: string; 
        [key: string]: any; // Allow other properties
        };
    textContent: string | null;
    numericalContent: number | null;
    [key: string]: any; // Allow other properties
  }[],
  [key: string]: any; // Allow other properties
}

export default function ReportRadarChart({ report, loading = false }: { report: Report, loading?: boolean }) {
  const theme = useTheme();

  const primaryColor = theme.palette.primary.main;

  if (loading) {
    return (
      <Card variant="outlined" sx={{ width: '100%', height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <CircularProgress />
      </Card>
    );
  }

  if (!report) {
      return (
        <Card variant="outlined" sx={{ width: '100%', height: '100%'}}>
            <CardContent>
                <Typography component="h2" variant="subtitle2" gutterBottom>
                    Totalbetyg över tid
                </Typography>
                <Box sx={{height: 250, display: 'flex', alignItems: 'center', justifyContent: 'center'}}>
                    <Typography variant="body1" color="text.secondary">
                        Ingen data att visa.
                    </Typography>
                </Box>
            </CardContent>
        </Card>
      )
  }

  return (
    <Card variant="outlined" sx={{ width: '100%' }}>
      <CardContent>
        <Typography gutterBottom variant="body1" sx={{ textAlign: 'left', color: 'text.secondary', fontSize: 16, fontFamily: 'Helvetica', paddingBottom: 2 }}>
            Numeriska betyg
        </Typography>
        
        <RadarChart
            colors={[primaryColor]}
            height={400}
            series={[{
                data: report?.answers?.filter(a => a.question?.category === 'NUMERIC')?.map(a => a.numericalContent ?? 0) || [],
                                }]}
                radar={{
                        metrics: (report?.answers ?? [])
                                    ?.filter((a: any) => a.question?.category === 'NUMERIC' && a.numericalContent != null)
                                      ?.map((a: any) => ({  name: a.question?.questionText, max: 10})),
            }}/>
      </CardContent>
    </Card>
  );
}