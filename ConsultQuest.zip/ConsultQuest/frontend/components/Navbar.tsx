import React, { useState } from "react";
import AppBar from "@mui/material/AppBar";
import { useMutation, useQuery } from "react-query";
import Toolbar from "@mui/material/Toolbar";
import IconButton from "@mui/material/IconButton";
import Avatar from "@mui/material/Avatar";
import Menu from "@mui/material/Menu";
import MenuItem from "@mui/material/MenuItem";
import ListItemIcon from "@mui/material/ListItemIcon";
import Box from "@mui/material/Box";
import Button from "@mui/material/Button";
import { styled, alpha, SxProps, Theme } from "@mui/material/styles";
import Autocomplete from "@mui/material/Autocomplete";
import TextField from "@mui/material/TextField";
import Settings from "@mui/icons-material/Settings";
import Logout from "@mui/icons-material/Logout";
import PersonIcon from "@mui/icons-material/Person";
import { useRouter } from "next/router";
import { api } from "../api";
import { useMe } from "../hooks/users";

interface UserDTO {
  id: number;
  firstName: string;
  lastName: string;
  email: string;
  roles: string[];
}

interface ClientDTO {
    id: number;
    name: string;
}

const retrieveUsers = async (): Promise<UserDTO[]> => {
  const { data } = await api.get("/api/users/all");
  return data;
};

const retrieveClients = async (): Promise<ClientDTO[]> => {
    const { data } = await api.get("/api/client");
    return data;
  };

function Navbar() {
  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
  const open = Boolean(anchorEl);
  const router = useRouter();
  const { data: me, isLoading: isLoadingMe, error: meError } = useMe();
  const isAdmin = me?.roles.includes("ADMIN") || false;

  const { data: users = [] } = useQuery<UserDTO[]>(
    "allUsersForSearch",
    retrieveUsers,
    {
      staleTime: 5 * 60 * 1000,
    }
  );

  const { data: clients = [] } = useQuery<ClientDTO[]>(
    "allClientsForSearch",
    retrieveClients,
    {
      staleTime: 5 * 60 * 1000,
    }
  );

  const searchOptions = React.useMemo(() => {
    const userOptions = users
        .filter(user => user.roles.includes('CONSULTANT'))
        .map(user => ({ ...user, type: 'user' }));
    const clientOptions = clients.map(client => ({ ...client, type: 'client' }));
    return [...clientOptions, ...userOptions];
}, [users, clients]);

  const handleMenu = (event: React.MouseEvent<HTMLElement>) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = async () => {
    setAnchorEl(null);
  };

  const handleProfileClick = () => {
    console.log("Profile clicked");
    handleClose();
  };

  const handleSettingsClick = () => {
    console.log("Settings clicked");
    handleClose();
  };

  const logoutMutation = useMutation(() => api.post("/logout"), {
    onSuccess: () => {
      router.push("/login");
    },
    onError: (error) => {
      console.error("Logout failed", error);
    },
  });

  const handleLogoutClick = async () => {
    handleClose();
    logoutMutation.mutate();
  };

  const isActive = (path: string) => router.pathname === path;

  // Styled search wrapper
  const Search = styled("div")(({ theme }) => ({
    position: "relative",
    borderRadius: theme.shape.borderRadius,
    backgroundColor: alpha(theme.palette.common.white, 0.15),
    color: "white",
    "&:hover": {
      backgroundColor: alpha(theme.palette.common.white, 0.25),
    },
    marginRight: theme.spacing(2),
    marginLeft: 0,
    width: "100%",
    [theme.breakpoints.up("sm")]: {
      marginLeft: theme.spacing(3),
      width: "auto",
    },
  }));

  const pillButtonStyle: SxProps<Theme> = {
    borderRadius: "999px",
    color: "salmon",
    textTransform: "none",
    fontWeight: "bold",
    mx: 1,
    border: "2px solid transparent",
    "&:hover": {
      backgroundColor: alpha("#ffcada", 0.15),
    },
  };

  const activePillStyle: SxProps<Theme> = {
    ...pillButtonStyle,
    borderColor: "#ffcada",
    backgroundColor: alpha("#bf0170", 0.05),
  };

  return (
    <AppBar
      position="fixed"
      color="transparent"
      elevation={0}
      sx={{
        backgroundColor: alpha("#151415", 0.5),
        backdropFilter: "blur(10px)",
        boxShadow: 3,
      }}
    >
      <Toolbar sx={{ position: "relative" }}>
        <Box sx={{ display: "flex", alignItems: "center" }}>
          <img
            src="/assets/logoPink.png"
            alt="Logo"
            style={{ width: "100px", height: "100%", objectFit: "contain" }}
          />
        </Box>

        {/* Navigation Pills */}
        <Box
          sx={{
            position: "absolute",
            left: "250px",
            transform: "translateX(-50%)",
            display: "flex",
          }}
        >
          <Button
            sx={{
              fontFamily: "AlmarenaNeue",
              ...(isActive("/dashboard") ? activePillStyle : pillButtonStyle),
            }}
            onClick={() => router.push("/dashboard")}
          >
            Dashboard
          </Button>
          <Button
            sx={{
              fontFamily: "AlmarenaNeue",
              ...(isActive("/createforminvite")
                ? activePillStyle
                : pillButtonStyle),
            }}
            onClick={() => router.push("/createforminvite")}
          >
            + Skapa formulär
          </Button>
        </Box>

        <Box sx={{ flexGrow: 1 }} />

        {/* Admin button */}
        {isAdmin && (
          <Button
            sx={isActive("/admin") ? activePillStyle : pillButtonStyle}
            onClick={() => router.push("/admin")}
          >
            Adminpanel
          </Button>
        )}

        {/* User search */}
        <Search>
          <Autocomplete
            popupIcon={null}
            id="user-search"
            options={searchOptions}
            groupBy={(option) => option.type === 'user' ? 'Användare' : 'Företag'}
            getOptionLabel={(option) =>
                option.type === 'user' ? `${option.firstName} ${option.lastName}` : option.name
            }
            onChange={(event, value) => {
              if (value) {
                if (value.type === 'user') {
                    router.push(`/profile/${value.id}`);
                } else if (value.type === 'client') {
                    router.push(`/companies/${value.id}`);
                }
              }
            }}
            renderInput={({ InputProps, ...params }) => (
              <TextField
                {...params}
                placeholder="Sök användare eller företag..."
                variant="standard"
                sx={{
                  width: 300,
                  "& .MuiInput-root": {
                    color: "white",
                    paddingLeft: "1em",
                    "&:before": {
                      borderBottom: "1px solid rgba(255, 255, 255, 0.42)",
                    },
                    "&:hover:not(.Mui-disabled):before": {
                      borderBottom: "1px solid white",
                    },
                  },
                  "& .MuiInputLabel-root": {
                    color: "rgba(255, 255, 255, 0.7)",
                  },
                  "& .MuiAutocomplete-endAdornment .MuiSvgIcon-root": {
                    color: "white",
                  },
                }}
                InputProps={{
                  ...InputProps,
                  endAdornment: null, // This will completely remove the end adornment
                  disableUnderline: true,
                }}
              />
            )}
          />
        </Search>

        {/* User avatar + menu */}
        <div>
          <IconButton
            size="large"
            aria-label="account of current user"
            aria-haspopup="true"
            onClick={handleMenu}
            sx={{ p: 0, borderRadius: "50%", backgroundColor: "transparent" }}
          >
            <Avatar
              sx={{
                width: 32,
                height: 32,
                bgcolor: "#ffcada",
                fontSize: "0.875rem",
              }}
            >
              JD
            </Avatar>
          </IconButton>
          <Menu
            id="menu-appbar"
            anchorEl={anchorEl}
            keepMounted
            open={open}
            onClose={handleClose}
            anchorOrigin={{ vertical: "bottom", horizontal: "right" }}
            transformOrigin={{ vertical: "top", horizontal: "right" }}
            PaperProps={{
              sx: {
                backgroundColor: "#333333",
                color: "white",
                mt: 2.5,
                "& .MuiMenuItem-root": {
                  "&:hover": {
                    backgroundColor: "#424242",
                  },
                },
                "& .MuiListItemIcon-root": {
                  color: "white",
                },
              },
            }}
          >
            {/*<MenuItem onClick={handleProfileClick}>
              <ListItemIcon>
                <PersonIcon fontSize="small" />
              </ListItemIcon>
              Profile
            </MenuItem>
            <MenuItem onClick={handleSettingsClick}>
              <ListItemIcon>
                <Settings fontSize="small" />
              </ListItemIcon>
              Settings
            </MenuItem>*/}
            <MenuItem onClick={handleLogoutClick}>
              <ListItemIcon>
                <Logout fontSize="small" />
              </ListItemIcon>
              Logga ut
            </MenuItem>
          </Menu>
        </div>
      </Toolbar>
    </AppBar>
  );
}

export default Navbar;