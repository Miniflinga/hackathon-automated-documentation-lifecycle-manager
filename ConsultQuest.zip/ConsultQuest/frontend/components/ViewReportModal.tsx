import {
  alpha,
  AppBar,
  Box,
  Grid,
  IconButton,
  Modal,
  Paper,
  Stack,
  Toolbar,
  Typography,
  useTheme,
  Switch,
  FormControlLabel,
} from "@mui/material";
import CloseIcon from "@mui/icons-material/Close";
import OutlinedCard from "./Cards/OutlinedCard";
import ReportRadarChart from "./ReportRadarChart";
import RadarChartCard from "./Cards/RadarChartCard";
import { api } from "../api";
import { useMutation, useQuery, useQueryClient } from "react-query";
import { useState } from "react";

interface Answer {
  question: {
    category: "NUMERIC" | "TEXT";
    questionText: string;
  };
  numericalContent: number | null;
}

type FullReport = {
  id: number;
  clientName: string;
  consultantName: string;
  submissionDate: Date;
  status: boolean;
  answers: {
    id: number;
    question: {
      id: number;
      questionText: string;
      category: string;
      [key: string]: any; // Allow other properties
    };
    textContent: string | null;
    numericalContent: number | null;
    [key: string]: any; // Allow other properties
  }[];
  [key: string]: any; // Allow other properties
};

const style = {
  padding: "20px",
  borderRadius: "8px",
  width: "80vw", // Set width to 80% of the viewport width
  maxWidth: "1200px", // Optional: Limit the maximum width for larger screens
  height: "80vh", // Adjust height based on content
  // Center the modal content on the screen
  position: "absolute", // Ensure modal content stays within the viewport
  top: "50%",
  left: "50%",
  transform: "translate(-50%, -50%)",
  overflow: "auto", // Enable scrolling if content overflows
  boxShadow: 24,
};

const retrieveClientAverage = async (clientId: number) => {
  const { data } = await api.get(`/api/form/averageClientScore/${clientId}`);
  return data;
};

const patchSeenStatus = async ({ id, seen }: { id: number; seen: boolean }) => {
  await api.patch(`/api/form/setSeen/${id}`, seen);
};

const retrieveGivenReport = async (id: number | null) => {
  const { data } = await api.get(`/api/form/response/${id}`);
  return data;
};

export default function ViewReportModal({
  open = false,
  currentReportId,
  handleClose,
}: {
  open: boolean;
  currentReportId: number | null;
  handleClose: () => void;
}) {
  const theme = useTheme();
  const queryClient = useQueryClient();

  // Fetch detailed report data when a report is selected
  const {
    data: givenReport,
    error: givenReportError,
    isLoading: givenReportLoading,
  } = useQuery(
    [`givenReport${currentReportId}`, currentReportId],
    () => retrieveGivenReport(currentReportId),
    {
      enabled:
        open && currentReportId !== undefined && currentReportId !== null, // Only run this query when modal is open
    }
  );

  const useSwitchToggle = useMutation({
    mutationFn: patchSeenStatus,
    onSuccess: () => {
      // update the cached table data without refetching
      // TODO: idk what happens if it become givenReportnull
      queryClient.invalidateQueries([`givenReport${currentReportId}`]);
      queryClient.invalidateQueries(["clients"]);
      queryClient.invalidateQueries([`userProfile`]); // if a lot of reports for single user remake to update cache
      queryClient.setQueryData(["dashboardDataResponses"], (old: any) => {
        if (!old) return old;

        return old.map((item: any) =>
          item.submissionId === currentReportId
            ? { ...item, status: !givenReport?.status }
            : item
        );
      });
    },
  });

  const date = givenReport?.submissionDate
    ? new Date(givenReport.submissionDate)
    : null;

  const formattedDate = date?.toLocaleString(undefined, {
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    hour12: false, // Use 24-hour format, remove if you want 12-hour AM/PM
  });

  // Fetch detailed report data when a report is selected
  // TODO: check if key can be dynamic. Might fetch an unuseful amount of times now.
  const { data: clientAverage } = useQuery(
    ["clientAverage", givenReport],
    () => retrieveClientAverage(givenReport?.clientId),
    {
      enabled:
        givenReport?.clientId !== undefined && givenReport?.clientId !== null,
    }
  );

  const handleSwitch = () => {
    useSwitchToggle.mutate({
      id: givenReport?.submissionId,
      seen: !givenReport?.status,
    });
  };

  const coreCategories = ["Glädje", "Enkelhet", "Resultat", "Ansvar"];
  const radarChartAnswers =
    (givenReport?.answers?.filter(
      (answer: any) =>
        answer.question?.category === "NUMERIC" &&
        coreCategories.includes(answer.question?.questionText)
    ) as Answer[]) || [];

  return (
    <Modal
      open={open}
      onClose={handleClose}
      slotProps={{
        backdrop: {
          style: {
            backdropFilter: "blur(8px)", // Apply blur effect to the background
            backgroundImage:
              "radial-gradient(ellipse at 50% 50%, hsla(240, 1%, 30%, 0.15), hsla(240, 1%, 10%, 0.3))", // Light gradient
            backgroundColor: "rgba(0, 0, 0, 0.1)", // Semi-transparent background to darken
          },
        },
      }}
    >
      <Paper sx={{ ...style }}>
        <AppBar
          position="fixed"
          color="transparent"
          elevation={0}
          sx={{
            backgroundColor: alpha("#151415", 0.5),
            backdropFilter: "blur(10px)",
            boxShadow: 3,
          }}
        >
          <Toolbar sx={{ position: "relative" }}>
            <Box
              sx={{
                display: "flex",
                flexGrow: 1,
                gap: 2,
                alignItems: "center",
              }}
            >
              <Typography sx={{ fontFamily: "AlmarenaNeue" }}>
                {givenReport?.clientName}
              </Typography>
              <Typography sx={{ fontFamily: "AlmarenaNeue" }}>
                {givenReport?.consultantName}
              </Typography>
              <Typography sx={{ fontFamily: "AlmarenaNeue" }}>
                {formattedDate}
              </Typography>
            </Box>
            <Box
              sx={{
                display: "flex",
                gap: 2,
                flexGrow: 1,
                position: "absolute",
                top: 10,
                right: 2,
                alignItems: "center",
              }}
            >
              <FormControlLabel
                label="Granskad:"
                labelPlacement="start"
                control={
                  <Switch
                    checked={givenReport?.status}
                    onChange={handleSwitch}
                    sx={{
                      "& .MuiSwitch-switchBase.Mui-checked": {
                        color: theme.palette.secondary.main,
                        "&:hover": {
                          backgroundColor: alpha(
                            theme.palette.secondary.main,
                            theme.palette.action.hoverOpacity
                          ),
                        },
                      },
                      "& .MuiSwitch-switchBase.Mui-checked + .MuiSwitch-track":
                        {
                          backgroundColor: theme.palette.secondary.main,
                        },
                    }}
                  />
                }
              />
              <IconButton
                onClick={handleClose}
                size="small"
                sx={{
                  "&:focus": {
                    outline: "none",
                    backgroundColor: "transparent",
                  },
                }}
              >
                <CloseIcon fontSize="small" />
              </IconButton>
            </Box>
          </Toolbar>
        </AppBar>
        <Stack spacing={2} sx={{ mt: "60px" }}>
          <RadarChartCard
            label={"Numeriska betyg"}
            report={{ answers: radarChartAnswers }}
            secondData={
              (clientAverage?.averageScores?.map((item) => item.score) ??
                []) as number[]
            }
            loading={givenReportLoading}
          />
          {givenReport?.answers?.map((answer: any) =>
            answer.question?.category === "TEXT" ? (
              //<Grid key={answer.question?.id} sx={{ width: "100%" }}>
              <OutlinedCard
                label={answer.question?.questionText}
                minWidth={250}
                contentWeight={"body1"}
                content={answer.textContent != null ? answer.textContent : "-"}
                loading={givenReportLoading}
              ></OutlinedCard>
            ) : // </Grid>
            null
          )}
        </Stack>
      </Paper>
    </Modal>
  );
}
