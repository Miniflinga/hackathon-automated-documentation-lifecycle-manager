import * as React from 'react';
import { Theme } from '@mui/material/styles';
import { useQuery,  useMutation, useQueryClient } from 'react-query';
import Paper from '@mui/material/Paper';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TablePagination from '@mui/material/TablePagination';
import TableRow from '@mui/material/TableRow';
import Box from '@mui/material/Box';
import TextField from '@mui/material/TextField';
import { CircularProgress, Typography,   Dialog, DialogTitle, DialogContent, DialogActions,
        Snackbar, Alert, Tooltip } from '@mui/material';
import Button from '@mui/material/Button';
import IconButton from '@mui/material/IconButton';
import Avatar from '@mui/material/Avatar';
import { useRouter } from 'next/router';
import InputAdornment from '@mui/material/InputAdornment';

import SearchIcon from '@mui/icons-material/Search';
import FilterListIcon from '@mui/icons-material/FilterList';
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/Delete';
import { api } from '../api';

interface Column {
  id: 'userId' | 'profileIcon' | 'firstName' | 'lastName' | 'role' | 'team' | 'lastModified' | 'actions';
  label: string;
  minWidth?: number;
  align?: 'right' | 'center' | 'left';
}

const columns: readonly Column[] = [
  { id: 'userId', label: 'User ID', minWidth: 80 },
  { id: 'profileIcon', label: 'Profilikon', minWidth: 100 },
  { id: 'firstName', label: 'Förnamn', minWidth: 150 },
  { id: 'lastName', label: 'Efternamn', minWidth: 150 },
  { id: 'role', label: 'Roll', minWidth: 120 },
  { id: 'team', label: 'Team', minWidth: 120 },
  { id: 'lastModified', label: 'Senast ändrad', minWidth: 150, },
  { id: 'actions', label: 'Verktyg', minWidth: 120, align: 'center' },
];

interface ApiUser {
  id: number;
  firstName: string;
  lastName: string;
  roles: string[];
  teams: string[];
  lastModified?: string;
}

interface RowData {
  userId: number;
  profileIcon: string;
  firstName: string;
  lastName: string;
  role: string;
  team: string;
  lastModified?: string;
}

function initials(firstName: string = '', lastName: string = ''): string {
  const f = firstName.trim().charAt(0) || '';
  const l = lastName.trim().charAt(0) || '';
  return (f + l).toUpperCase();
}

function mapApiUserToRow(u: ApiUser): RowData {
  return {
    userId: u.id,
    profileIcon: initials(u.firstName, u.lastName),
    firstName: u.firstName,
    lastName: u.lastName,
    role: Array.isArray(u.roles) ? u.roles.join(', ') : '',
    team: Array.isArray(u.teams) ? u.teams.join(', ') : '',
    lastModified: u.lastModified?.slice(0,16), 
  };
}

const retrieveAllUsers = async () => {
  const { data } = await api.get('/api/users/all');
  return data;
};

export default function AdminUserTable() {
  const [page, setPage] = React.useState(0);
  const [rowsPerPage, setRowsPerPage] = React.useState(10);
  const [confirmOpen, setConfirmOpen] = React.useState(false);
  const [deletingId, setDeletingId] = React.useState<number | null>(null);
  const [toast, setToast] = React.useState<{open: boolean; message: string; severity: 'success' | 'error'}>({
  open: false, message: '', severity: 'success'});
  const [companyModalOpen, setCompanyModalOpen] = React.useState(false);
  const [companyName, setCompanyName] = React.useState('');
  const router = useRouter();
  const queryClient = useQueryClient();

    const goToEdit = (id: number) => router.push(`/edituser?id=${id}`);

  const deleteUser = async (id: number) => {
    await api.delete(`/api/users/delete/${id}`);
  };

  const deleteMutation = useMutation(deleteUser, {
    onSuccess: () => {
      queryClient.invalidateQueries('allUsers'); // refresh user list
      setToast({ open: true, message: 'Användaren borttagen.', severity: 'success' });
      setDeletingId(null);
    },
    onError: () => {
      setToast({ open: true, message: 'Misslyckades med att ta bort användare.', severity: 'error' });
      setDeletingId(null);
    },
    onSettled: () => setConfirmOpen(false),
  });

  const createCompany = async (companyName: string) => {
    const { data } = await api.post('/api/client', { name: companyName });
    return data;
  };

  const createCompanyMutation = useMutation(createCompany, {
      onSuccess: () => {
          queryClient.invalidateQueries("allClientsForSearch");
          setToast({ open: true, message: 'Företag skapat.', severity: 'success' });
          setCompanyModalOpen(false);
          setCompanyName('');
      },
      onError: () => {
          setToast({ open: true, message: 'Misslyckades med att skapa företag.', severity: 'error' });
      },
  });

  const handleAskDelete = (id: number) => {
    setDeletingId(id);
    setConfirmOpen(true);
  };
  
  const handleConfirmDelete = () => {
    if (deletingId != null) deleteMutation.mutate(deletingId);
  };

  const handleCancelDelete = () => {
    setConfirmOpen(false);
    setDeletingId(null);
  };

  const handleOpenCompanyModal = () => setCompanyModalOpen(true);
  const handleCloseCompanyModal = () => {
      if (createCompanyMutation.isLoading) return;
      setCompanyModalOpen(false);
      setCompanyName('');
  }
  const handleCreateCompany = () => {
      if (companyName.trim()) {
          createCompanyMutation.mutate(companyName.trim());
      }
  };

  const { data: rows = [], isLoading, isError } = useQuery('allUsers', retrieveAllUsers, {
    select: (users: ApiUser[]) => (users || []).map(mapApiUserToRow),
  });
  
  const handleChangePage = (event: unknown, newPage: number) => setPage(newPage);
  const handleChangeRowsPerPage = (e: React.ChangeEvent<HTMLInputElement>) => {
    setRowsPerPage(+e.target.value);
    setPage(0);
  };

  return (
      <Paper sx={{ width: '100%', overflow: 'hidden', p: 1, backgroundColor: 'background.paper' }}>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 2 }}>
          <TextField
            variant="outlined"
            size="small"
            placeholder="Sök i rapport"
            InputProps={{ startAdornment: (<InputAdornment position="start"><SearchIcon /></InputAdornment>) }}
            sx={{ width: '300px' }}
          />
          <Button variant="outlined" startIcon={<FilterListIcon />}>
            Sortera
          </Button>
        </Box>

        <TableContainer>
          <Table stickyHeader aria-label="sticky table">
            <TableHead>
              <TableRow>{columns.map((column) => (<TableCell key={column.id} align={column.align} style={{ minWidth: column.minWidth, fontWeight: 'bold' }}>{column.label}</TableCell>))}</TableRow>
            </TableHead>
            {isLoading ? (
              <TableBody>
                <TableRow>
                  <TableCell colSpan={columns.length} align="center">
                    <CircularProgress />
                  </TableCell>
                </TableRow>
              </TableBody>
            ) : isError ? (
              <TableBody>
                <TableRow>
                  <TableCell colSpan={columns.length} align="center">
                    <Typography color="error">Kunde inte ladda användare.</Typography>
                  </TableCell>
                </TableRow>
              </TableBody>
            ) : (
              <TableBody>
                {rows.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage).map((row) => (
                  <TableRow hover role="checkbox" tabIndex={-1} key={row.userId}>
                    {columns.map((column) => {
                      const value = row[column.id as keyof RowData];
                      if (column.id === 'profileIcon') {
                        return (<TableCell key={column.id} align={column.align}><Avatar sx={{ bgcolor: 'primary.main', width: 32, height: 32, fontSize: '0.875rem' }}>{value}</Avatar></TableCell>);
                      }
                      if (column.id === 'actions') {
                        const isThisDeleting = deletingId === row.userId && deleteMutation.isLoading;
                        return (
                          <TableCell key={column.id} align={column.align}>
                            <Tooltip title="Redigera">
                              <IconButton
                                size="small"
                                onClick={(e) => { e.stopPropagation(); goToEdit(row.userId); }}
                                aria-label={`Redigera ${row.firstName} ${row.lastName}`}
                              >
                                <EditIcon fontSize="inherit" />
                              </IconButton>
                            </Tooltip>

                            <Tooltip title="Ta bort">
                              <IconButton
                                size="small"
                                sx={{ ml: 1 }}
                                onClick={(e) => { e.stopPropagation(); handleAskDelete(row.userId); }}
                                disabled={isThisDeleting}
                                aria-label={`Ta bort användaren ${row.firstName} ${row.lastName}`}
                              >
                                {isThisDeleting ? <CircularProgress size={16} /> : <DeleteIcon fontSize="inherit" />}
                              </IconButton>
                            </Tooltip>
                          </TableCell>
                        );
                      }
                      return (<TableCell key={column.id} align={column.align}>{value}</TableCell>);
                    })}
                  </TableRow>
                ))}
              </TableBody>
            )}
          </Table>
        </TableContainer>

        <TablePagination
          rowsPerPageOptions={[10, 25, 100]}
          component="div"
          count={rows.length}
          rowsPerPage={rowsPerPage}
          page={page}
          onPageChange={handleChangePage}
          onRowsPerPageChange={handleChangeRowsPerPage}
          labelRowsPerPage="Rader per sida"
        />

        <Box sx={{ display: 'flex', justifyContent: 'flex-end', mt: 2, gap: 1 }}>
            <Button variant="contained" color="blue" onClick={handleOpenCompanyModal}>Skapa företag</Button>
            <Button variant="contained" color="blue" onClick={() => router.push('/signup')}>Skapa användare</Button>
        </Box>
        <Dialog open={confirmOpen} onClose={handleCancelDelete}>
          <DialogTitle>Radera användare?</DialogTitle>
          <DialogContent>
            <Typography>Är du säker på att du vill radera denna användare? Denna åtgärd kan inte ångras.</Typography>
          </DialogContent>
          <DialogActions>
            <Button onClick={handleCancelDelete} disabled={deleteMutation.isLoading}>Avbryt</Button>
            <Button color="error" variant="contained" onClick={handleConfirmDelete} disabled={deleteMutation.isLoading}>
              {deleteMutation.isLoading ? <CircularProgress size={18} /> : 'Radera'}
            </Button>
          </DialogActions>
        </Dialog>

        <Dialog open={companyModalOpen} onClose={handleCloseCompanyModal}>
            <DialogTitle>Skapa nytt företag</DialogTitle>
            <DialogContent>
                <TextField
                    autoFocus
                    margin="dense"
                    id="name"
                    label="Företagsnamn"
                    type="text"
                    fullWidth
                    variant="standard"
                    value={companyName}
                    onChange={(e) => setCompanyName(e.target.value)}
                    disabled={createCompanyMutation.isLoading}
                />
            </DialogContent>
            <DialogActions>
                <Button onClick={handleCloseCompanyModal} disabled={createCompanyMutation.isLoading}>Avbryt</Button>
                <Button onClick={handleCreateCompany} variant="contained" disabled={createCompanyMutation.isLoading}>
                    {createCompanyMutation.isLoading ? <CircularProgress size={24} /> : 'Skapa'}
                </Button>
            </DialogActions>
        </Dialog>

        <Snackbar
          open={toast.open}
          autoHideDuration={3000}
          onClose={() => setToast((t) => ({ ...t, open: false }))}>
          <Alert
            onClose={() => setToast((t) => ({ ...t, open: false }))}
            severity={toast.severity}
            variant="filled"
            sx={{ width: '100%' }}
          >
            {toast.message}
          </Alert>
        </Snackbar>
      </Paper>
  );
}