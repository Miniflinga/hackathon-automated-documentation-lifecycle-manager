import * as React from "react";
import Box from "@mui/material/Box";
import Card from "@mui/material/Card";
import CardContent from "@mui/material/CardContent";
import Typography from "@mui/material/Typography";
import { Avatar, Grid, Stack, Tooltip, IconButton } from "@mui/material";
import InfoIcon from "@mui/icons-material/Info";

interface ProfileCardProps {
  firstname?: string;
  lastname?: string;
  email?: string;
  minHeight?: number;
  profilepicture?: string;
  tooltipDescription?: string;
}

export default function ProfileCard({
  firstname,
  lastname,
  email,
  minHeight = 100,
  profilepicture,
  tooltipDescription,
}: ProfileCardProps) {
  const initials = `${firstname ? firstname[0] : ""}${
    lastname ? lastname[0] : ""
  }`.toUpperCase();
  return (
    <Box sx={{ minWidth: 275, minHeight: minHeight, height: "100%" }}>
      <Card
        variant="outlined"
        sx={{
          position: "relative",
          height: "100%",
          display: "flex",
          flexDirection: "column",
          backgroundColor: "#bf007050 !important",
        }}
      >
        <Tooltip title={tooltipDescription} placement="top-start">
            <IconButton
              aria-label="info"
              size="small"
              sx={{
                position: "absolute",
                top: 8,
                right: 0,
                backgroundColor: "transparent",
                borderRadius: "100%",
                width: "10px",
                height: "10px",
                mr: 2,
                mt: 1,
              }}
            >
              <InfoIcon fontSize="small" />
            </IconButton>
          </Tooltip>
        <CardContent
          sx={{ flexGrow: 1, display: "flex", alignItems: "center" }}
        >
          <Grid container spacing={2} alignItems="center">
            <Grid size={6}>
              <Avatar
                alt={`${firstname} ${lastname}`}
                src={profilepicture}
                variant="square"
                sx={{ width: 130, height: 130, borderRadius: "8px" }}
              >
                {initials}
              </Avatar>
            </Grid>
            <Grid size={6}>
              <Box width={200}>
                <Stack>
                  <Typography
                    gutterBottom
                    variant="body1"
                    sx={{
                      textAlign: "left",
                      color: "text.secondary",
                      fontSize: 16,
                      fontFamily: "Helvetica",
                      paddingBottom: 2,
                    }}
                  ></Typography>

                  <Typography
                    variant="h3"
                    sx={{
                      textAlign: "left",
                      paddingTop: 2,
                      fontFamily: "AlmarenaNeue",
                    }}
                  >
                    {firstname} {lastname}
                  </Typography>
                  <Typography
                    variant="body2"
                    sx={{
                      textAlign: "left",
                      color: "text.secondary",
                      fontSize: 18,
                      fontFamily: "Helvetica",
                      paddingTop: 2,
                      minHeight: 40,
                    }}
                  >
                    {email}
                  </Typography>
                </Stack>
              </Box>
            </Grid>
          </Grid>
        </CardContent>
      </Card>
    </Box>
  );
}