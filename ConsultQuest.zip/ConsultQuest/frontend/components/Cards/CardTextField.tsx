import * as React from 'react';
import Box from '@mui/material/Box';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import Typography from '@mui/material/Typography';
import TextField from '@mui/material/TextField';
import { Tooltip, IconButton } from '@mui/material';
import InfoIcon from '@mui/icons-material/Info';

interface CardTextFieldProps {
  label?: string;
  description?: string;
  minHeight?: number;
  value: string;
  onChange: (value: string) => void;
  maxLength?: number;
}

export default function CardTextField({
  label = "Label",
  description = "",
  minHeight = 170,
  value,
  onChange,
  maxLength = 100,
}: CardTextFieldProps) {
  return (
    <Box sx={{ minWidth: 275 }}>
      <Card variant="outlined" sx={{ position: "relative", height: '100%', minHeight: minHeight, display: 'flex', flexDirection: 'column' }}>
        <Tooltip title={description} placement="top-start">
            <IconButton
              aria-label="info"
              size="small"
              sx={{
                position: "absolute",
                top: 8,
                right: 0,
                backgroundColor: "transparent",
                borderRadius: "100%",
                width: "10px",
                height: "10px",
                mr: 2,
                mt: 1,
              }}
            >
              <InfoIcon fontSize="small" />
            </IconButton>
          </Tooltip>
        <CardContent sx={{ flexGrow: 1 }}>
          <Typography gutterBottom variant="body1" sx={{ textAlign: 'left', color: 'text.secondary', fontSize: 16, fontFamily: 'Helvetica', paddingBottom: 2 }}>
            {label}
          </Typography>
          <TextField
            required
            fullWidth
            variant="standard"
            value={value || ''}
            onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
              if (e.target.value.length <= maxLength) {
                onChange(e.target.value);
              }
            }}
            inputProps={{ maxLength: maxLength }}
            placeholder=""
            multiline
            rows={2}
            sx={{ mb: 1 }}
          />
          <Typography
            variant="caption"
            sx={{ textAlign: 'right', color: 'text.secondary', alignSelf: 'flex-end' }}
          >
            {value?.length || 0} / {maxLength}
          </Typography>
        </CardContent>
      </Card>
    </Box>
  );
}