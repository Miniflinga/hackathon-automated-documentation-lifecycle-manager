// components/Cards/CardDropDown.jsx
import * as React from 'react';
import Box from '@mui/material/Box';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import Typography from '@mui/material/Typography';
import Autocomplete from '@mui/material/Autocomplete';
import TextField from '@mui/material/TextField';
import { Skeleton, Tooltip, IconButton } from '@mui/material';
import InfoIcon from '@mui/icons-material/Info';

interface CardDropDownProps<T> {
  title?: string;
  label?: string;
  description?: string;
  tooltipDescription?: string;
  minHeight?: number;
  value: T | null;
  menuItems: readonly T[];
  getOptionLabel?: (option: T) => string;
  isOptionEqualToValue?: (option: T, value: T) => boolean;
  onChange: (newValue: T | null) => void;
  isLoading?: boolean;
  isError?: boolean;
  errorText?: string;
}

export default function CardDropDown<T>({
  title = "Title",
  label = "Label",
  description = "",
  tooltipDescription,
  minHeight = 150,
  value = null,
  menuItems = [],
  getOptionLabel = (option: any) => option?.name || String(option),
  isOptionEqualToValue = (option, val) => option === val,
  onChange,
  isLoading,
  isError,
  errorText = "Något gick fel, försök igen senare."
}: CardDropDownProps<T>) {
  return (
    <Box sx={{ minWidth: 275,  height: '100%' }}>
      <Card
        variant="outlined"
        sx={{
          position: "relative",
          height: '100%',
          display: 'flex',
          flexDirection: 'column',
          textAlign: 'left',
          minHeight: minHeight
        }}
      >
        <Tooltip title={tooltipDescription || description} placement="top-start">
            <IconButton
              aria-label="info"
              size="small"
              sx={{
                position: "absolute",
                top: 8,
                right: 0,
                backgroundColor: "transparent",
                borderRadius: "100%",
                width: "10px",
                height: "10px",
                mr: 2,
                mt: 1,
              }}
            >
              <InfoIcon fontSize="small" />
            </IconButton>
          </Tooltip>
        <CardContent sx={{ flexGrow: 1 }}>
          <Typography
            gutterBottom
            variant="body1"
            sx={{
              textAlign: 'left',
              color: 'text.secondary',
              fontSize: 16,
              fontFamily: 'Helvetica',
              pb: 2
            }}
          >
            {title}
          </Typography>

          {isError? <Typography
            variant="body2"
            sx={{
              textAlign: 'left',
              color: 'error.main',
              fontSize: 12,
              fontFamily: 'Helvetica',
              pt: 2,
              minHeight: 10
            }}
          >
            {errorText}
          </Typography> : null}

          {isLoading? <Skeleton animation="wave" height={40} /> : <Autocomplete
            options={menuItems}
            getOptionLabel={getOptionLabel as (option: T) => string}
            value={value}
            onChange={(event: any, newValue: T | null) => onChange(newValue)}
            isOptionEqualToValue={isOptionEqualToValue as (option: T, value: T) => boolean}
            renderInput={(params) => (
              <TextField 
                {...params} 
                placeholder={label} // Use placeholder instead of a redundant label
                variant="outlined" 
                sx={{
                  // Center the text inside the input field
                  '& .MuiInputBase-input': {
                    textAlign: 'left',
                  },
                  // Ensure there is enough padding on the right for the arrow icon
                  '&.MuiTextField-root .MuiOutlinedInput-root': {
                    paddingRight: '40px !important',
                  },
                }}
              />
            )}
          />}
          <Typography
            variant="body2"
            sx={{
              textAlign: 'left',
              color:'text.secondary',
              fontSize: 18,
              fontFamily: 'Helvetica',
              pt: 2,
              minHeight: 40
            }}
          >
            {description}
          </Typography>
        </CardContent>
      </Card>
    </Box>
  );
}