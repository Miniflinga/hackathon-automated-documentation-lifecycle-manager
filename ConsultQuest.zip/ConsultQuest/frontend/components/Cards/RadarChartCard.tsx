import * as React from "react";
import Box from "@mui/material/Box";
import Card from "@mui/material/Card";
import { useTheme, alpha } from "@mui/material/styles";
import CardContent from "@mui/material/CardContent";
import Typography from "@mui/material/Typography";
import { CircularProgress, Tooltip, IconButton } from "@mui/material";
import { RadarChart } from "@mui/x-charts/RadarChart";
import Stack from "@mui/material/Stack";
import InfoIcon from "@mui/icons-material/Info";

interface Answer {
  question: {
    category: "NUMERIC" | "TEXT";
    questionText: string;
  };
  numericalContent: number | null;
}

function CircularProgressWithLabel(props: { value: number; label: string }) {
  return (
    <Stack
      direction="row"
      spacing={2}
      alignItems="center"
      sx={{ minWidth: 150 }}
    >
      <Box sx={{ position: "relative", display: "inline-flex" }}>
        <CircularProgress
          variant="determinate"
          sx={{
            color: (theme) => alpha(theme.palette.primary.main, 0.5),
          }}
          size={60}
          thickness={4}
          value={100}
        />
        <CircularProgress
          variant="determinate"
          value={props.value * 10}
          size={60}
          thickness={4}
          sx={{
            position: "absolute",
            left: 0,
            color: (theme) => theme.palette.primary.main,
          }}
        />
        <Box
          sx={{
            top: 0,
            left: 0,
            bottom: 0,
            right: 0,
            position: "absolute",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          <Typography
            variant="caption"
            component="div"
            sx={{
              color: "text.secondary",
              fontWeight: "bold",
              fontSize: "1rem",
            }}
          >
            {props.value.toFixed(1)}
          </Typography>
        </Box>
      </Box>
      <Typography variant="body1" sx={{ fontSize: "0.9rem" }}>
        {props.label}
      </Typography>
    </Stack>
  );
}

interface RadarChartCardProps {
  label?: string;
  description?: string;
  minHeight?: number;
  loading?: boolean;
  report?: {
    answers: Answer[];
  };
  secondData?: number[];
}

export default function RadarChartCard({
  label = "Customer",
  description = "",
  minHeight = 100,
  loading = false,
  report,
  secondData,
}: RadarChartCardProps) {
  const theme = useTheme();
  const primaryColor = theme.palette.primary.main;

  const numericAnswers = React.useMemo(
    () =>
      report?.answers?.filter(
        (a) => a.question?.category === "NUMERIC" && a.numericalContent != null
      ) || [],
    [report]
  );

  // TODO: idk if useMemo should be used here. It was a quick fix to create different series for chart
  const series = React.useMemo(
    () => 
      secondData? [{ data: numericAnswers.map((a) => a.numericalContent ?? 0), 
        color: theme.palette.primary.main,
        label: "Betyg i rapporten"
      }, {
        data: secondData ?? [0, 0, 0, 0],
        color: theme.palette.secondary.main,
        label: "Medelvärde för kunden"
      }] : [ {data: numericAnswers.map((a) => a.numericalContent ?? 0)}], 
      [secondData, numericAnswers]
  );

  return (
    <Box sx={{ minWidth: 275, minHeight: minHeight, height: "100%" }}>
      {loading ? (
        <Card
          variant="outlined"
          sx={{
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            flexGrow: 1,
            minHeight: minHeight + 100,
          }}
        >
          <CircularProgress />
        </Card>
      ) : (
        <Card
          variant="outlined"
          sx={{ position: "relative", height: "100%", display: "flex", flexDirection: "column" }}
        >
          {description && (
            <Tooltip title={description} placement="top-start">
              <IconButton
                aria-label="info"
                size="small"
                sx={{
                  position: "absolute",
                  top: 8,
                  right: 0,
                  backgroundColor: "transparent",
                  borderRadius: "100%",
                  width: "10px",
                  height: "10px",
                  mr: 2,
                  mt: 1,
                }}
              >
                <InfoIcon fontSize="small" />
              </IconButton>
            </Tooltip>
          )}
          <CardContent sx={{ flexGrow: 1 }}>
            <Typography
              gutterBottom
              variant="body1"
              sx={{
                textAlign: "left",
                color: "text.secondary",
                fontSize: 16,
                fontFamily: "Helvetica",
                paddingBottom: 2,
              }}
            >
              {label}
            </Typography>
            <Stack direction="row" spacing={4} alignItems="center">
              {numericAnswers.length > 0 ? (
                <RadarChart
                  height={300}
                  colors={[primaryColor]}
                  series={series}
                  radar={{
                    metrics: numericAnswers.map((a) => ({
                      name: a.question.questionText,
                      max: 10,
                    })),
                  }}
                  slotProps={{
                    polarAxis: {
                      labelStyle: { fontSize: "1rem" },
                    },
                  }}
                />
              ) : null}
              {numericAnswers.length > 0 ? (
                <>
                  <Stack
                    direction="column"
                    spacing={2.5}
                    sx={{ minWidth: 150 }}
                  >
                    {numericAnswers.map((answer) => (
                      <CircularProgressWithLabel
                        key={answer.question.questionText}
                        value={answer.numericalContent ?? 0}
                        label={answer.question.questionText}
                      />
                    ))}
                  </Stack>
                </>
              ) : (
                <Box
                  sx={{
                    height: 300,
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    flexGrow: 1,
                  }}
                >
                  <Typography variant="body1" color="text.secondary">
                    Ingen data att visa.
                  </Typography>
                </Box>
              )}
            </Stack>
            <Typography
              variant="body2"
              sx={{
                textAlign: "left",
                color: "text.secondary",
                fontSize: 18,
                fontFamily: "Helvetica",
                paddingTop: 2,
                minHeight: 40,
              }}
            >
              {description}
            </Typography>
          </CardContent>
        </Card>
      )}
    </Box>
  );
}