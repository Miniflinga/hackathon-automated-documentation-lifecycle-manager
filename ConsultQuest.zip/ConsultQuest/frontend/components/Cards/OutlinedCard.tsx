import * as React from "react";
import Box from "@mui/material/Box";
import Card from "@mui/material/Card";
import CardContent from "@mui/material/CardContent";
import Typography, { TypographyProps } from "@mui/material/Typography";
import { CircularProgress, Tooltip, IconButton } from "@mui/material";
import InfoIcon from "@mui/icons-material/Info";

interface TrendDTO {
  text: string;
  direction: 'increase' | 'decrease' | 'stable';
  changeValue: number;
}

interface OutlinedCardProps {
  label?: string;
  content?: React.ReactNode;
  tooltip?: string;
  description?: string;
  contentWeight?: TypographyProps["variant"];
  minHeight?: number;
  minWidth?: number;
  loading?: boolean;
  trend?: TrendDTO;
}

export default function OutlinedCard({
  label = "Customer",
  content = "",
  contentWeight = "h4",
  tooltip = "",
  description = "",
  minHeight = 100,
  loading = false,
  minWidth = 275,
  trend,
}: OutlinedCardProps) {
  const getTrendColor = () => {
    if (!trend) return "text.secondary";
    switch (trend.direction) {
      case "increase":
        return "success.main";
      case "decrease":
        return "error.main";
      default:
        return "text.secondary";
    }
  };

  return (
    <Box sx={{ minWidth: {minWidth}, minHeight: minHeight, height: "100%" }}>
      {loading ? (
        <Card
          variant="outlined"
          sx={{
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            flexGrow: 1,
            minHeight: minHeight + 100,
          }}
        >
          <CircularProgress />
        </Card>
      ) : (
        <Card
          variant="outlined"
          sx={{ position: "relative", height: "100%", display: "flex", flexDirection: "column" }}
        >
          {tooltip && (
            <Tooltip title={tooltip} placement="top-start">
              <IconButton
                aria-label="info"
                size="small"
                sx={{
                  position: "absolute",
                  top: 8,
                  right: 0,
                  backgroundColor: "transparent",
                  borderRadius: "100%",
                  width: "10px",
                  height: "10px",
                  mr: 2,
                  mt: 1,
                }}
              >
                <InfoIcon fontSize="small" />
              </IconButton>
            </Tooltip>
          )}
          <CardContent sx={{ flexGrow: 1 }}>
            <Typography
              gutterBottom
              variant="body1"
              sx={{
                textAlign: "left",
                color: "text.secondary",
                fontSize: 16,
                fontFamily: "Helvetica",
                paddingBottom: 2,
              }}
            >
              {label}
            </Typography>
            <Typography
              variant={contentWeight ?? "h4"}
              component="div"
              sx={{ textAlign: "left", fontFamily: "AlmarenaNeue", whiteSpace: "normal", overflowWrap: "break-word" }}
            >
              {content}
            </Typography>
            {trend && (
              <Typography
                variant="caption"
                sx={{
                  textAlign: "left",
                  color: getTrendColor(),
                  fontSize: 14,
                  fontFamily: "Helvetica",
                  paddingTop: 2,
                  minHeight: 40,
                }}
              >
                {trend.text}
              </Typography>
            )}
            {(description && !trend)&& (
              <Typography
                variant="caption"
                sx={{
                  textAlign: "left",
                  fontSize: 14,
                  fontFamily: "Helvetica",
                  paddingTop: 100,
                  minHeight: 40,
                }}
              >
                {description}
              </Typography>
            )}
          </CardContent>
        </Card>
      )}
    </Box>
  );
}
