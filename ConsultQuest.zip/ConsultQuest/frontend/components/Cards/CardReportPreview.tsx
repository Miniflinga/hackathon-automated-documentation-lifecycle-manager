import * as React from "react";
import Box from "@mui/material/Box";
import Card from "@mui/material/Card";
import CardContent from "@mui/material/CardContent";
import Typography from "@mui/material/Typography";
import ReportSlider from "../ReportSlider";
import FeedbackField from "../FeedbackField";
import { Skeleton, Tooltip, IconButton } from "@mui/material";
import InfoIcon from "@mui/icons-material/Info";

interface Question {
  id: number | string;
  questionText: string;
  category: "NUMERIC" | "TEXT";
  description?: string;
}

const renderQuestion = (q: Question) => {
  // Preview is non-interactive, so we don't pass onChange
  switch (q.category) {
    case "NUMERIC":
      return (
        <ReportSlider
          key={q.id}
          title={q.questionText}
          description={q.description}
          value={5} // Default preview value
          onChange={() => {}} // Pass a no-op function
        />
      );
    case "TEXT":
      return (
        <FeedbackField
          key={q.id}
          title={q.questionText}
          label={q.description ?? "Skriv ytterligare återkoppling här"}
          value="" // Pass an empty string for controlled components
          onChange={() => {}} // Pass a no-op function
        />
      );
    default:
      return null;
  }
};

interface CardReportPreviewProps {
  label?: string;
  tooltipDescription?: string;
  minHeight?: number;
  questions?: Question[];
  loading?: boolean;
}

export default function CardReportPreview({
  label = "Customer",
  tooltipDescription = "",
  minHeight = 100,
  questions = [],
  loading = false,
}: CardReportPreviewProps) {
  return (
    <Box sx={{ minWidth: 275, minHeight: { minHeight }, height: "100%" }}>
      <Card
        variant="outlined"
        sx={{ position: "relative", height: "100%", display: "flex", flexDirection: "column" }}
      >
        <Tooltip title={tooltipDescription} placement="top-start">
            <IconButton
              aria-label="info"
              size="small"
              sx={{
                position: "absolute",
                top: 8,
                right: 0,
                backgroundColor: "transparent",
                borderRadius: "100%",
                width: "10px",
                height: "10px",
                mr: 2,
                mt: 1,
              }}
            >
              <InfoIcon fontSize="small" />
            </IconButton>
          </Tooltip>
        <CardContent
          sx={{
            flexGrow: 1,
            overflowY: "auto",
            scrollbarWidth: "thin",
            scrollbarColor: "#ccc transparent",
            "&::-webkit-scrollbar": {
              width: "6px",
            },
            "&::-webkit-scrollbar-track": {
              background: "transparent",
              ml: "5px",
            },
            "&::-webkit-scrollbar-thumb": {
              backgroundColor: "#ccc",
              borderRadius: "10px",
            },
            "&::-webkit-scrollbar-thumb:hover": {
              backgroundColor: "#aaa",
            },
          }}
        >
          <Typography
            gutterBottom
            variant="body1"
            sx={{
              textAlign: "left",
              color: "text.secondary",
              fontSize: 16,
              fontFamily: "Helvetica",
              paddingBottom: 2,
            }}
          >
            {label}
          </Typography>
          {loading ? (
            <>
              <Skeleton variant="text" width="80%" sx={{ mb: 2 }} />
              <Skeleton variant="rectangular" height={60} sx={{ mb: 2 }} />
              <Skeleton variant="rectangular" height={90} />
            </>
          ) : questions.length > 0 ? (
            questions.map(renderQuestion)
          ) : (
            <Typography sx={{ color: "text.secondary" }}>
              Inga frågor att visa.
            </Typography>
          )}
        </CardContent>
      </Card>
    </Box>
  );
}
