import * as React from 'react';
import { PieChart } from '@mui/x-charts/PieChart';
import { useDrawingArea } from '@mui/x-charts/hooks';
import { styled, useTheme } from '@mui/material/styles';
import Typography from '@mui/material/Typography';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import Box from '@mui/material/Box';
import Stack from '@mui/material/Stack';
import LinearProgress, { linearProgressClasses } from '@mui/material/LinearProgress';
import { CircularProgress, Tooltip, IconButton } from '@mui/material';
import InfoIcon from '@mui/icons-material/Info';

const StyledText = styled('text')(
  ({ theme }) => ({
    textAnchor: 'middle',
    dominantBaseline: 'central',
    fill: "white",
    fontFamily: "AlmarenaNeue"
  })
);

interface Report {
  id: number;
  company: string;
  consultant: string;
  overallScore: number;
  createdDate: string;
  status: boolean;
}


function PieCenterLabel({ primaryText, secondaryText }: { primaryText: string; secondaryText: string }) {
  const { width, height, left, top } = useDrawingArea();
  const primaryY = top + height / 2 - 10;
  const secondaryY = primaryY + 24;

  return (
    <React.Fragment>
      <StyledText
        x={left + width / 2}
        y={primaryY}
        sx={{ fontSize: '1.5rem', fontWeight: 'bold' }}
      >
        {primaryText}
      </StyledText>
      <StyledText x={left + width / 2} y={secondaryY} sx={{ fontSize: '0.875rem' }}>
        {secondaryText}
      </StyledText>
    </React.Fragment>
  );
}

export default function CompanyScoresChart({ reports = [], loading = false, description = "" }: { reports: Report[], loading?: boolean, description?: string }) {
  const theme = useTheme();

  const { companyData, totalAverage } = React.useMemo(() => {
    if (!reports || reports.length === 0) {
      return { companyData: [], totalAverage: 0 };
    }

    type CompanyScores = {
      [key: string]: {
        totalScore: number;
        count: number;
      };
    };

    const companyScores = reports.reduce((acc: CompanyScores, report) => {
      if (!acc[report.company]) {
        acc[report.company] = { totalScore: 0, count: 0 };
      }
      acc[report.company].totalScore += report.overallScore;
      acc[report.company].count += 1;
      return acc;
    }, {} as CompanyScores);

    const data = Object.entries(companyScores).map(([name, { totalScore, count }]) => ({
      name,
      value: totalScore / count, // Average score
    }));

    const overallTotal = reports.reduce((sum, r) => sum + r.overallScore, 0);
    const avg = reports.length > 0 ? (overallTotal / reports.length).toFixed(1) : 0;

    return { companyData: data, totalAverage: avg };
  }, [reports]);

  const colors = [
    theme.palette.primary.light,
    theme.palette.primary.main,
    theme.palette.secondary.light,
    theme.palette.secondary.main, // Changed from pink.light to primary.light
  ];

  if (loading) {
    return (
      <Card variant="outlined" sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', flexGrow: 1, minHeight: 200 }}>
        <CircularProgress />
      </Card>
    );
  }

  if (companyData.length === 0) {
    return (
        <Card variant="outlined" sx={{ flexGrow: 1, minHeight: 200, position: "relative" }}>
            {description && (
              <Tooltip title={description} placement="top-start">
                <IconButton
                  aria-label="info"
                  size="small"
                  sx={{
                    position: "absolute",
                    top: 8,
                    right: 0,
                    backgroundColor: "transparent",
                    borderRadius: "100%",
                    width: "10px",
                    height: "10px",
                    mr: 2,
                    mt: 1,
                  }}
                >
                  <InfoIcon fontSize="small" />
                </IconButton>
              </Tooltip>
            )}
            <CardContent>
                <Typography component="h2" variant="subtitle2">Betyg per kund</Typography>
                <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: '100%', minHeight: 150 }}>
                    <Typography variant="body1" color="text.secondary">Ingen data att visa.</Typography>
                </Box>
            </CardContent>
        </Card>
    );
  }

  return (
    <Card
      variant="outlined"
      sx={{ position: "relative", display: 'flex', flexDirection: 'column', gap: '8px', flexGrow: 1 }}
    >
      {description && (
        <Tooltip title={description} placement="top-start">
          <IconButton
            aria-label="info"
            size="small"
            sx={{
              position: "absolute",
              top: 8,
              right: 0,
              backgroundColor: "transparent",
              borderRadius: "100%",
              width: "10px",
              height: "10px",
              mr: 2,
              mt: 1,
            }}
          >
            <InfoIcon fontSize="small" />
          </IconButton>
        </Tooltip>
      )}
      <CardContent>
        <Typography gutterBottom variant="body1" sx={{ textAlign: 'left', color: 'text.secondary', fontSize: 16, fontFamily: 'Helvetica', paddingBottom: 2 }}>
            Betyg per kund
        </Typography>
        <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <PieChart
            colors={colors}
            series={[{ data: companyData, innerRadius: 60, outerRadius: 80, valueFormatter: (v) => v.value.toFixed(1) }]}
            height={200}
            width={200}
            margin={{ top: 20, bottom: 20, left: 20, right: 20 }}
            hideLegend
          >
            <PieCenterLabel primaryText={totalAverage.toString()} secondaryText="Snittbetyg" />
          </PieChart>
        </Box>
        {companyData.map((company, index) => (
          <Stack
            key={company.name}
            direction="row"
            sx={{ alignItems: 'center', gap: 2, pb: 1 }}
          >
            <Stack sx={{ gap: 0.5, flexGrow: 1 }}>
              <Stack direction="row" sx={{ justifyContent: 'space-between', alignItems: 'center' }}>
                <Typography variant="body2" sx={{ fontWeight: '500' }}>
                  {company.name}
                </Typography>
                <Typography variant="body2" sx={{ color: 'text.secondary' }}>
                  {company.value.toFixed(1)} / 40
                </Typography>
              </Stack>
              <LinearProgress
                variant="determinate"
                value={company.value * 2.5} // Scale 0-40 to 0-100 for progress bar
                sx={{
                  [`& .${linearProgressClasses.bar}`]: {
                    backgroundColor: colors[index % colors.length],
                  },
                }}
              />
            </Stack>
          </Stack>
        ))}
      </CardContent>
    </Card>
  );
}