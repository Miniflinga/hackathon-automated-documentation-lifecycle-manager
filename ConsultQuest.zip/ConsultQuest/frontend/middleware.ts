// middleware.ts
import { NextRequest, NextResponse } from "next/server";

type Role = "ADMIN" | "SALES" | "MANAGER";

// Define which paths need which roles
const RULES: Array<{ prefix: string; roles?: Role[] }> = [
  { prefix: "/admin", roles: ["ADMIN"] },
  { prefix: "/signup", roles: ["ADMIN"] },
  { prefix: "/dashboard", roles: ["SALES", "ADMIN", "MANAGER"] },
  { prefix: "/createforminvite", roles: ["SALES", "ADMIN", "MANAGER"] },
];

//set true to skip logging in when in devmode
const devMode = false; //true;

// Backend endpoint to check the current logged-in user
const ME_PATH = "http://localhost:8080/api/auth/me";

export async function middleware(req: NextRequest) {
  const { pathname } = req.nextUrl;

  // find the roles that are needed for the path
  const match = RULES.find(
    (rule) => pathname === rule.prefix || pathname.startsWith(rule.prefix + "/")
  );

  // If no rule matches -> public page
  //or skip if we are on devmode
  if (!match || devMode) {
    return NextResponse.next();
  }

  // check the user roles my getting the infromation on the sessionid for the logged in user
  const res = await fetch(ME_PATH, {
    method: "GET",
    headers: { cookie: req.headers.get("cookie") ?? "" },
  });

  // if not logged in -> go to /login
  if (!res.ok) {
    const loginUrl = req.nextUrl.clone();
    loginUrl.pathname = "/login";
    loginUrl.searchParams.set("from", pathname);
    return NextResponse.redirect(loginUrl);
  }

  // if roles are required check them
  if (match.roles?.length) {
    const user = (await res.json()) as { roles?: Role[] };
    //check if the user has the role needed for this page
    const hasRole = match.roles.some((role) => user.roles?.includes(role));

    if (!hasRole) {
      const denyUrl = req.nextUrl.clone();
      denyUrl.pathname = "/forbidden";
      return NextResponse.redirect(denyUrl);
    }
  }

  // auth is correct redirect to wanted page
  return NextResponse.next();
}

// tell the middleware what paths to check
//add more when more protected paths are needed
export const config = {
  matcher: ["/admin/:path*", "/signup/:path*", "/dashboard/:path*", "/createforminvite/:path*"],
};
