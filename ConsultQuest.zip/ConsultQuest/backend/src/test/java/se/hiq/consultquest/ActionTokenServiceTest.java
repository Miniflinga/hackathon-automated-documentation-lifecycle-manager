package se.hiq.consultquest;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import java.util.Map;


import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

import java.util.Optional;

import se.hiq.consultquest.repository.*;
import se.hiq.consultquest.entity.*;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.time.OffsetDateTime;

import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.junit.jupiter.api.extension.ExtendWith;

import com.fasterxml.jackson.databind.ObjectMapper;
import se.hiq.consultquest.entity.*;
import se.hiq.consultquest.repository.ActionTokenRepository;

import se.hiq.consultquest.util.*;

import java.time.OffsetDateTime;
import java.util.Map;
import java.util.Set;


@ExtendWith(MockitoExtension.class)
class ActionTokenServiceTest {
    @Mock
    private ActionTokenRepository repo;
    @Mock
    private ObjectMapper mapper = new ObjectMapper();

    @InjectMocks
    private ActionTokenService service;

    @Captor
    private ArgumentCaptor<ActionToken> tokenCaptor;

    @Test
    void createToken_test() {
        OffsetDateTime exp = OffsetDateTime.parse("2030-01-01T12:00:00Z");
        Map<String,Object> payload = Map.of("clientId", 1, "userId", 2);

        String raw = service.createToken(ActionToken.Type.RATE_USER, exp,
                "alice@example.com", 42L, 7L, payload);

        assertNotNull(raw);
        assertFalse(raw.isBlank());

        verify(repo).save(tokenCaptor.capture());
        ActionToken saved = tokenCaptor.getValue();

        // stored hash is sha256(raw); raw is NOT stored
        assertNotNull(saved.getTokenHash());
        assertNotEquals(raw, saved.getTokenHash());
        assertEquals(TokenUtil.sha256Hex(raw), saved.getTokenHash());

        // other fields
        assertEquals(ActionToken.Type.RATE_USER, saved.getType());
        assertEquals(exp, saved.getExpiresAt());
        assertEquals("alice@example.com", saved.getEmail());
        assertEquals(42L, saved.getUserId());
        assertEquals(7L, saved.getClientId());

        Map<String,Object> parsed = service.payload(saved); 
        assertEquals(payload, parsed);
    }

    
    @Test
    void consume_test() {
        String raw = "RAW123";
        String hash = TokenUtil.sha256Hex(raw);
        ActionToken.Type type = ActionToken.Type.RATE_USER;

        ActionToken token = new ActionToken();
        token.setTokenHash(hash);
        token.setType(type);
        token.setExpiresAt(OffsetDateTime.now().plusDays(1));

        // First call returns the token, second call returns empty (as DB would after consumedAt is set)
        when(repo.findByTokenHashAndTypeInAndConsumedAtIsNullAndExpiresAtAfter(
                eq(hash), eq(Set.of(type)), any(OffsetDateTime.class)))
            .thenReturn(Optional.of(token), Optional.empty());

        // 1st consume works and sets consumedAt
        ActionToken returned = service.consume(raw, type);
        assertSame(token, returned);
        assertNotNull(token.getConsumedAt());

        // 2nd consume throws (no longer found)
        assertThrows(IllegalArgumentException.class, () -> service.consume(raw, type));

        // verify the repo was queried twice
        verify(repo, times(2)).findByTokenHashAndTypeInAndConsumedAtIsNullAndExpiresAtAfter(
            eq(hash), eq(Set.of(type)), any(OffsetDateTime.class)
        );
    }

    @Test
    void isValid_test() {
        String raw = "RAW123";
        String hash = TokenUtil.sha256Hex(raw);
        ActionToken.Type type = ActionToken.Type.RATE_USER;

        ActionToken token = new ActionToken();
        token.setTokenHash(hash);
        token.setType(type);
        token.setExpiresAt(OffsetDateTime.now().plusDays(1));

        // 1st and 2nd call returns the token (from isValid() and consume()), 3rd call returns empty (isValid() after consume)
        // isValid() uses ...Type...
        when(repo.findByTokenHashAndTypeAndConsumedAtIsNullAndExpiresAtAfter(
                eq(hash), eq(type), any(OffsetDateTime.class)))
            .thenReturn(Optional.of(token))   // before consume()
            .thenReturn(Optional.empty());    // after consume()

        // consume() uses ...TypeIn...
        when(repo.findByTokenHashAndTypeInAndConsumedAtIsNullAndExpiresAtAfter(
                eq(hash), eq(Set.of(type)), any(OffsetDateTime.class)))
            .thenReturn(Optional.of(token));  // successful consume

        // isValid should be true before consume is called
        assert(service.isValid(raw, type));

        ActionToken returned = service.consume(raw, type);

        // should be false after consume
        assertFalse(service.isValid(raw, type));

        // verifies
        verify(repo, times(2)).findByTokenHashAndTypeAndConsumedAtIsNullAndExpiresAtAfter(
            eq(hash), eq(type), any(OffsetDateTime.class));
        verify(repo, times(1)).findByTokenHashAndTypeInAndConsumedAtIsNullAndExpiresAtAfter(
            eq(hash), eq(Set.of(type)), any(OffsetDateTime.class));
    }

    @Test
    void payload_test() {
        ActionTokenService service = new ActionTokenService(null); // repo not used in this test

        // create a token with a payload
        ActionToken token = new ActionToken();
        token.setPayloadJson("{\"clientId\":1,\"userId\":2,\"name\":\"Alice\"}");

        // call payload() method
        Map<String,Object> result = service.payload(token);

        // Check returned Map
        assertEquals(1, result.get("clientId"));
        assertEquals(2, result.get("userId"));
        assertEquals("Alice", result.get("name"));
    }
}
