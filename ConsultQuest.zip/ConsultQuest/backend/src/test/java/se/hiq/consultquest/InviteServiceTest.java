package se.hiq.consultquest;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import se.hiq.consultquest.dto.InviteRequest;
import org.springframework.security.crypto.password.PasswordEncoder;

import se.hiq.consultquest.util.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyMap;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.ArgumentMatchers.isNull;
import static org.mockito.ArgumentMatchers.same;
import static org.mockito.Mockito.*;
import org.mockito.ArgumentCaptor;
import org.springframework.test.util.ReflectionTestUtils;
import se.hiq.consultquest.dto.FormInviteDto;
import se.hiq.consultquest.repository.*;
import se.hiq.consultquest.entity.*;

import java.time.OffsetDateTime;

import java.util.*;

@ExtendWith(MockitoExtension.class)
class InviteServiceTest {
    @Mock
    private UsersRepository usrRepo; // Create a mock "fake" object
    @Mock
    private TeamRepository teamRepo;
    @Mock
    private PasswordEncoder encoder;
    @Mock
    private AppMailer mailer;
    @Mock
    private ActionTokenService tokens;
    @Mock
    private ClientRepository clientRepo;
    
    // Create an instance of inviteService that injects the mocks above
    @InjectMocks
    private InviteService invServ;

    // ---- Test methods -----
    @Test
    // sendInviteSignup() when user already exists (should throw IllegalStateException)
    void sendInviteSignupUserExists_test() {
        InviteRequest req = new InviteRequest();
        req.setEmail("test@example.com");

        // When usersRepo.findByEmail with this email is called, return a non-empty Optional 
        when(usrRepo.findByEmail("test@example.com")).thenReturn(Optional.of(new Users()));

        // Expect IllegalStateException
        assertThrows(IllegalStateException.class, ()-> {invServ.sendInviteSignUp(req);});

        // Verify that no token was created and no email was sent
        verify(tokens, never()).createToken(any(), any(), any(), any(), any(), any());
        verify(mailer, never()).send(any(), any(), any());
    }

    @Test
    void sendInviteSignupHappy_test() {
        // Inject @Value fields on the service instance
        int inviteTtlDays = 7;
        String frontendUrl = "https://consultquest.example.com";
        ReflectionTestUtils.setField(invServ, "inviteTtlDays", inviteTtlDays);  // changes private fields
        ReflectionTestUtils.setField(invServ, "frontendUrl", frontendUrl);

        // Arrange request
        InviteRequest req = new InviteRequest();
        req.setEmail("new.user@example.com");
        req.setFirstName("New");
        req.setLastName("User");
        req.setRoles(List.of("ROLE_USER", "ROLE_SELLER"));
        req.setTeamIds(List.of(10L, 20L));

        // No existing user
        when(usrRepo.findByEmail("new.user@example.com")).thenReturn(Optional.empty());

        // Stub token creation; capture expiresAt and payload
        String rawToken = "RAW123TOKEN";
        ArgumentCaptor<OffsetDateTime> expCap = ArgumentCaptor.forClass(OffsetDateTime.class);
        ArgumentCaptor<Map<String, Object>> payloadCap = ArgumentCaptor.forClass(Map.class);

        when(tokens.createToken(
                eq(ActionToken.Type.INVITE),
                expCap.capture(),
                eq("new.user@example.com"),
                isNull(),
                isNull(),
                payloadCap.capture()
        )).thenReturn(rawToken);

        // Capture the email body
        ArgumentCaptor<String> bodyCap = ArgumentCaptor.forClass(String.class);

        // Act
        assertDoesNotThrow(() -> invServ.sendInviteSignUp(req));

        // Assert: repo check done
        verify(usrRepo).findByEmail("new.user@example.com");

        // Assert: token creation called once with expected args
        verify(tokens, times(1)).createToken(
                eq(ActionToken.Type.INVITE),
                any(OffsetDateTime.class),
                eq("new.user@example.com"),
                isNull(),
                isNull(),
                anyMap()
        );

        // expiresAt = now + inviteTtlDays (+- 5 sec)
        OffsetDateTime exp = expCap.getValue();
        OffsetDateTime min = OffsetDateTime.now().plusDays(inviteTtlDays).minusSeconds(5);
        OffsetDateTime max = OffsetDateTime.now().plusDays(inviteTtlDays).plusSeconds(5);
        assertTrue(!exp.isBefore(min) && !exp.isAfter(max), "expiresAt should be now+TTL (±5s)");

        // Payload propagated correctly
        Map<String, Object> payload = payloadCap.getValue();
        assertEquals("New", payload.get("firstName"));
        assertEquals("User", payload.get("lastName"));
        assertEquals(List.of("ROLE_USER", "ROLE_SELLER"), payload.get("roles"));
        assertEquals(List.of(10L, 20L), payload.get("teamIds"));

        // Email sent with correct link & TTL text
        verify(mailer).send(eq("new.user@example.com"),
                eq("Du har blivit inbjuden till ConsultQuest"),
                bodyCap.capture());

        String body = bodyCap.getValue();
        String expectedLink = frontendUrl + "/accept-invite?token=" + rawToken;
        assertTrue(body.contains(expectedLink), "Email body should contain invite link with token");
        assertTrue(body.contains(String.valueOf(inviteTtlDays)), "Email body should mention TTL days");
    }
    
    @Test
    void sendInviteFormHappy_test() {
        // Inject @Value fields
        int inviteTtlDays = 7;
        String frontendUrl = "https://consultquest.example.com";
        ReflectionTestUtils.setField(invServ, "inviteTtlDays", inviteTtlDays);
        ReflectionTestUtils.setField(invServ, "frontendUrl", frontendUrl);

        // Arrange request
        FormInviteDto req = new FormInviteDto();
        req.setClientId(100L);
        req.setUserId(200L);
        req.setConsultantEmail("consultant@example.com");
        req.setClientEmail("client@company.com");
        req.setFormTemplateName("quality-followup");

        // Repos say client & user exist
        when(clientRepo.existsById(100L)).thenReturn(true);
        when(usrRepo.existsById(200L)).thenReturn(true);

        // Consultant lookup
        Users consultant = new Users();
        consultant.setId(300L);
        consultant.setFirstName("Ada");
        consultant.setLastName("Lovelace");
        when(usrRepo.findByEmail("consultant@example.com")).thenReturn(Optional.of(consultant));

        // Capture expiresAt and payload; return a fixed raw token
        String rawToken = "RAW_FORM_TOKEN";
        ArgumentCaptor<OffsetDateTime> expCap = ArgumentCaptor.forClass(OffsetDateTime.class);
        ArgumentCaptor<Map<String,Object>> payloadCap = ArgumentCaptor.forClass(Map.class);

        when(tokens.createToken(
                eq(ActionToken.Type.RATE_USER),
                expCap.capture(),
                eq("client@company.com"),
                eq(200L),
                eq(100L),
                payloadCap.capture()
        )).thenReturn(rawToken);

        // Capture email body
        ArgumentCaptor<String> bodyCap = ArgumentCaptor.forClass(String.class);

        // Act
        assertDoesNotThrow(() -> invServ.sendInviteForm(req));

        // Assert existence checks and consultant lookup
        verify(clientRepo).existsById(100L);
        verify(usrRepo).existsById(200L);
        verify(usrRepo).findByEmail("consultant@example.com");

        // Assert token creation called once with expected args
        verify(tokens, times(1)).createToken(
                eq(ActionToken.Type.RATE_USER),
                any(OffsetDateTime.class),
                eq("client@company.com"),
                eq(200L),
                eq(100L),
                anyMap()
        );

        // expiresAt ≈ now + inviteTtlDays +- 5s
        OffsetDateTime exp = expCap.getValue();
        OffsetDateTime min = OffsetDateTime.now().plusDays(inviteTtlDays).minusSeconds(5);
        OffsetDateTime max = OffsetDateTime.now().plusDays(inviteTtlDays).plusSeconds(5);
        assertTrue(!exp.isBefore(min) && !exp.isAfter(max), "expiresAt should be now+TTL (+- 5s)");

        // Payload contents propagated correctly
        Map<String,Object> payload = payloadCap.getValue();
        assertEquals("consultant@example.com", payload.get("consultantEmail"));
        assertEquals("quality-followup", payload.get("formTemplateName"));
        assertEquals(100, ((Number)payload.get("clientId")).intValue());
        assertEquals(200, ((Number)payload.get("userId")).intValue());
        assertEquals(300, ((Number)payload.get("consultantUserId")).intValue());
        assertEquals("Ada Lovelace", payload.get("consultantName"));

        // Email sent with correct link & TTL text
        verify(mailer).send(eq("client@company.com"),
                eq("Du har blivit inbjuden till kvalitetsuppföljning"),
                bodyCap.capture());

        String body = bodyCap.getValue();
        String expectedLink = frontendUrl + "/form?token=" + rawToken;
        assertTrue(body.contains(expectedLink), "Email body should contain form link with token");
        assertTrue(body.contains(String.valueOf(inviteTtlDays)), "Email body should mention TTL days");
    }

    @Test
    void sendInviteForm_clientNotFound_throws() {
        // Arrange
        FormInviteDto req = new FormInviteDto();
        req.setClientId(100L);
        req.setUserId(200L);
        req.setConsultantEmail("consultant@example.com");
        req.setClientEmail("client@company.com");
        req.setFormTemplateName("quality-followup");

        when(clientRepo.existsById(100L)).thenReturn(false); // client missing

        // Act + Assert
        assertThrows(IllegalArgumentException.class, () -> invServ.sendInviteForm(req));

        // No token/email should be produced
        verify(tokens, never()).createToken(any(), any(), any(), any(), any(), any());
        verify(mailer, never()).send(any(), any(), any());
    }

    @Test
    void sendInviteForm_userNotFound_throws() {
        // Arrange
        FormInviteDto req = new FormInviteDto();
        req.setClientId(100L);
        req.setUserId(200L);
        req.setConsultantEmail("consultant@example.com");
        req.setClientEmail("client@company.com");
        req.setFormTemplateName("quality-followup");

        when(clientRepo.existsById(100L)).thenReturn(true);
        when(usrRepo.existsById(200L)).thenReturn(false); // user missing

        // Act + Assert
        assertThrows(IllegalArgumentException.class, () -> invServ.sendInviteForm(req));

        // No token/email should be produced
        verify(tokens, never()).createToken(any(), any(), any(), any(), any(), any());
        verify(mailer, never()).send(any(), any(), any());
    }

    @Test
    void sendInviteForm_consultantNotFound_throws() {
        // Arrange
        FormInviteDto req = new FormInviteDto();
        req.setClientId(100L);
        req.setUserId(200L);
        req.setConsultantEmail("consultant@example.com");
        req.setClientEmail("client@company.com");
        req.setFormTemplateName("quality-followup");

        when(clientRepo.existsById(100L)).thenReturn(true);
        when(usrRepo.existsById(200L)).thenReturn(true);
        when(usrRepo.findByEmail("consultant@example.com")).thenReturn(Optional.empty()); // consultant missing

        // Act + Assert
        assertThrows(IllegalStateException.class, () -> invServ.sendInviteForm(req));

        // No token/email should be produced
        verify(tokens, never()).createToken(any(), any(), any(), any(), any(), any());
        verify(mailer, never()).send(any(), any(), any());
    }



}
