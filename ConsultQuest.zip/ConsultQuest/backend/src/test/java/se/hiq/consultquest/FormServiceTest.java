package se.hiq.consultquest;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import java.util.Map;

import se.hiq.consultquest.service.FormService;

import se.hiq.consultquest.util.ActionTokenService;
import se.hiq.consultquest.util.AppMailer;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

import java.util.List;
import java.util.Optional;

import se.hiq.consultquest.repository.*;
import se.hiq.consultquest.entity.enums.QuestionCategory;

import se.hiq.consultquest.entity.*;
import se.hiq.consultquest.dto.FormSubmitDto;
import se.hiq.consultquest.dto.AnswerDto;
import org.springframework.web.server.ResponseStatusException;


@ExtendWith(MockitoExtension.class)
class FormServiceTest {
    @Mock
    private FormRepository formRepository;
    @Mock
    private QuestionRepository questionRepository;
    @Mock
    private FormSubmissionRepository formSubmissionRepository;
    @Mock
    private ActionTokenService tokens;
    @Mock
    private ClientRepository clientRepository;
    @Mock
    private UsersRepository usersRepository;
    @Mock
    private AppMailer mailer;
    
    // Create an instance of formService that injects the mocks above
    @InjectMocks
    private FormService formService;

    // ---- Test methods -----

    // getForm() 
    // when found form returns dto
    // when not found throws ResponseStatusException
    @Test
    void getForm_test() {
        // Arrange
        Form mockForm = mock(Form.class);
        Question q = mock(Question.class);

        when(formRepository.findByFormTemplateName("template1")).thenReturn(Optional.of(mockForm));
        when(mockForm.getFormTemplateName()).thenReturn("template1");
        when(mockForm.getQuestions()).thenReturn(List.of(q));
        when(q.getId()).thenReturn(42L);
        when(q.getQuestionText()).thenReturn("How satisfied are you?");
        when(q.getDescription()).thenReturn("1-10 slider");
        when(q.getCategory()).thenReturn(QuestionCategory.NUMERIC);

        // call getForm()
        var result = formService.getForm("template1");

        // Check that everything exists
        assertNotNull(result);
        verify(formRepository).findByFormTemplateName("template1");
        verify(mockForm).getQuestions();
        verify(q).getQuestionText();
        verify(q).getDescription();
        verify(q).getCategory();

        // getForm() when template is missing should throw exception
        when(formRepository.findByFormTemplateName("missing")).thenReturn(Optional.empty());
        assertThrows(ResponseStatusException.class, () -> formService.getForm("missing"));
    }

    // Saves submission
    @Test 
    void saveFormSubmission_testHappy() {
        // mocked dto and answer dto
        FormSubmitDto dto = mock(FormSubmitDto.class);
        AnswerDto answerDto = mock(AnswerDto.class);
        ActionToken mockToken = mock(ActionToken.class);

        // define what should be returned on mocks
        when(dto.token()).thenReturn("token-abc");
        when(dto.answers()).thenReturn(List.of(answerDto));
        when(answerDto.questionId()).thenReturn(101L);
        when(answerDto.value()).thenReturn("7");

        // Token handling
        when(tokens.consume(eq("token-abc"), any())).thenReturn(mockToken);
        when(tokens.payload(mockToken))
            .thenReturn(Map.of("clientId", 1, "userId", 2, "consultantUserId", 3));
        when(mockToken.getPayloadJson()).thenReturn("{\"consultantName\": \"myName\"}");

        // Entities returned by getReferenceById
        Client client = mock(Client.class);
        Users seller = mock(Users.class);
        Users consultant = mock(Users.class);
        when(clientRepository.getReferenceById(1L)).thenReturn(client); // 1L is a made up id, L means Long (instead of int)
        when(clientRepository.findById(0L)).thenReturn(Optional.of(client));
        when(usersRepository.getReferenceById(2L)).thenReturn(seller);
        when(usersRepository.getReferenceById(3L)).thenReturn(consultant);
        when(usersRepository.findById(0L)).thenReturn(Optional.of(seller));

        // Question repository returns a numeric question
        Question question = mock(Question.class);
        when(questionRepository.findById(101L)).thenReturn(Optional.of(question));
        when(question.getCategory()).thenReturn(QuestionCategory.NUMERIC);

        // Mock the save method to populate the ID
        when(formSubmissionRepository.save(any(FormSubmission.class))).thenAnswer(invocation -> {
            FormSubmission savedSubmission = invocation.getArgument(0, FormSubmission.class);
            savedSubmission.setId(1L); // Set a mock ID
            return savedSubmission;
        });

        // Act
        formService.saveFormSubmission(dto);

        // Assert - verify important interactions happened
        verify(tokens).consume(eq("token-abc"), any());
        verify(tokens).payload(mockToken);
        verify(clientRepository).getReferenceById(1L);
        verify(usersRepository).getReferenceById(2L);
        verify(usersRepository).getReferenceById(3L);
        verify(questionRepository).findById(101L);
        verify(formSubmissionRepository).save(any());
    }

    // When questionId is invalid, a InvalidQuestionException should be thrown
    @Test
    void saveFormSubmission_test_invalidQuestion_throwsInvalidQuestionException() {
        // Arrange
        FormSubmitDto dto = mock(FormSubmitDto.class);
        AnswerDto answerDto = mock(AnswerDto.class);
        ActionToken mockToken = mock(ActionToken.class);

        when(dto.token()).thenReturn("token-abc");
        when(dto.answers()).thenReturn(List.of(answerDto));
        when(answerDto.questionId()).thenReturn(999L);
        // don't stub answerDto.value()

        when(tokens.consume(eq("token-abc"), eq(ActionToken.Type.RATE_USER))).thenReturn(mockToken);
        when(tokens.payload(mockToken)).thenReturn(
            Map.of("clientId", 1, "userId", 2, "consultantUserId", 3)
        );

        Client client = mock(Client.class);
        Users seller = mock(Users.class); 
        Users consultant = mock(Users.class);
        when(clientRepository.getReferenceById(1L)).thenReturn(client);
        when(usersRepository.getReferenceById(2L)).thenReturn(seller);
        when(usersRepository.getReferenceById(3L)).thenReturn(consultant);

        when(questionRepository.findById(999L)).thenReturn(Optional.empty());

        // Assert
        assertThrows(FormService.InvalidQuestionException.class,
            () -> formService.saveFormSubmission(dto));
    }

    // Slider value not between 0 and 10 throws InvalidAnswerException
    @Test
    void saveFormSubmission_test_invalidValue() {
        // Arrange
        FormSubmitDto dto = mock(FormSubmitDto.class);
        AnswerDto answerDto = mock(AnswerDto.class);
        ActionToken mockToken = mock(ActionToken.class);

        when(dto.token()).thenReturn("token-abc");
        when(dto.answers()).thenReturn(List.of(answerDto));
        when(answerDto.questionId()).thenReturn(101L);

        when(tokens.consume(eq("token-abc"), eq(ActionToken.Type.RATE_USER))).thenReturn(mockToken);
        when(tokens.payload(mockToken)).thenReturn(
            Map.of("clientId", 1, "userId", 2, "consultantUserId", 3)
        );

        Client client = mock(Client.class);
        Users seller = mock(Users.class); 
        Users consultant = mock(Users.class);
        when(clientRepository.getReferenceById(1L)).thenReturn(client);
        when(usersRepository.getReferenceById(2L)).thenReturn(seller);
        when(usersRepository.getReferenceById(3L)).thenReturn(consultant);

        // Question repository returns a numeric question
        Question question = mock(Question.class);
        when(questionRepository.findById(101L)).thenReturn(Optional.of(question));
        
        when(question.getCategory()).thenReturn(QuestionCategory.NUMERIC);

        when(answerDto.value()).thenReturn("11");
        assertThrows(FormService.InvalidAnswerException.class,
            () -> formService.saveFormSubmission(dto));
        
        // When question category is set to numeric but string cant be converted to int
        when(answerDto.value()).thenReturn("abc");
        assertThrows(FormService.InvalidAnswerException.class,
            () -> formService.saveFormSubmission(dto));
    }
}