package se.hiq.consultquest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConsultquestApplicationTests {

	@Test
	boolean contextLoads() {
		return true;
	}

}
