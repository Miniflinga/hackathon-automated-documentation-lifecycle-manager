-- sample client
INSERT INTO team (name) VALUES ('team1');
INSERT INTO team (name) VALUES ('team2');
INSERT INTO team (name) VALUES ('team3');

INSERT INTO client (name) VALUES ('Unicorn Super Power');
INSERT INTO client (name) VALUES ('Agents of the Void');
INSERT INTO client (name) VALUES ('Incorporated International');


-- sample user (NoOpPasswordEncoder => plain text is okay)

INSERT INTO users (password, email, role, first_name, last_name, last_modified)
VALUES
  ('123', 'adretessrmin@example.com', 3, 'Admin', 'User', now()),
  ('123', 'admetertein@example.com', 2, 'Admetertin', 'teterte', now()),
  ('123', 'admieegfgn@example.com', 8, 'Eugene', 'Usekjyukyer', now()),
  ('123', 'konsult1@example.com', 16, 'Anna', 'Andersson', now()),
  ('123', 'konsult2@example.com', 18, 'Per', 'Persson', now()),
  ('123', 'konsult3@example.com', 16, 'Gustav', 'Gustafsson', now());


INSERT INTO user_team (user_id, team_id) VALUES
  (1, 1),  -- jdoe → team1
  (2, 2),  -- bdoe → team2
  (3, 3),  -- gdoe → team3
  (4, 1),
  (5, 2),
  (6, 3);


-- sample questions based on question entity
INSERT INTO question (question_text, description, category) VALUES
('Glädje', 'Tillför konsulten energi, hur är det att jobba med konsulten?', 'NUMERIC'),
('Enkelhet', 'Gör konsulten det svåra enkelt, är det enkelt att kommunicera med konsulten?', 'NUMERIC'),
('Resultat', 'Leverarar konsulten kvalitet i tid? Är konsultent kompetent?', 'NUMERIC'),
('Ansvar', 'Tar konsulten ansvar för sitt arbete? Hur är samarbetet med konsulten?', 'NUMERIC'),
('Återkoppling', 'Övrig feedback.', 'TEXT'),
('Glädje', 'Tillför konsulten energi, hur är det att jobba med konsulten?', 'TEXT'),
('Enkelhet', 'Gör konsulten det svåra enkelt, är det enkelt att kommunicera med konsulten?', 'TEXT'),
('Resultat', 'Leverarar konsulten kvalitet i tid? Är konsultent kompetent?', 'TEXT'),
('Ansvar', 'Tar konsulten ansvar för sitt arbete? Hur är samarbetet med konsulten?', 'TEXT');
-- Nya frågor för mallar
-- Ändrar icke-grundläggande frågor från NUMERIC till TEXT
INSERT INTO question (question_text, description, category) VALUES
('Nöjdhet över lag', 'Hur nöjd är du över lag med konsultens insats hittills?', 'TEXT'),
('Vad kan personen göra för att bli bättre?', 'Finns det något specifikt konsulten kan fokusera på för att förbättra sig?', 'TEXT'),
-- Nya frågor för nya mallar
('Skulle ni rekommendera konsulten till andra projekt?', 'Baserat på er samlade erfarenhet, skulle ni rekommendera denna konsult internt eller externt?', 'TEXT'),
('Uppfylldes projektets mål?', 'I vilken utsträckning anser ni att konsultens bidrag hjälpte till att uppfylla de övergripande projektmålen?', 'TEXT'),
('Proaktivitet och initiativ', 'Hur väl tar konsulten egna initiativ och agerar proaktivt för att driva arbetet framåt?', 'TEXT'),
('Samarbete med teamet', 'Hur väl fungerar konsulten i teamet och med andra intressenter?', 'TEXT');

-- Nya frågor specifikt för "Nybörjare"-mallen
INSERT INTO question (question_text, description, category) VALUES
('Hur har konsultens första tid i uppdraget varit?', 'Beskriv ditt initiala intryck av konsultens start och anpassning till teamet och arbetsuppgifterna.', 'TEXT'),
('Finns det något särskilt stöd konsulten behöver initialt?', 'Identifiera eventuella områden där extra stöd eller introduktion kan vara värdefullt för konsulten.', 'TEXT');


-- sample forms based on form entity
INSERT INTO form (form_template_name, created_on) VALUES ('Standard', CURRENT_TIMESTAMP);
INSERT INTO form (form_template_name, created_on) VALUES ('Nybörjare', CURRENT_TIMESTAMP);
INSERT INTO form (form_template_name, created_on) VALUES ('Projektavslut', CURRENT_TIMESTAMP);
INSERT INTO form (form_template_name, created_on) VALUES ('Löpande uppföljning', CURRENT_TIMESTAMP);


-- sample form_questions based on form_question entity
-- Koppla alla frågor till "Standard"-mallen
DELETE FROM form_question WHERE form_template_id = 1;
INSERT INTO form_question (form_template_id, question_id, question_order) VALUES
(1, 1, 0), -- Glädje (NUMERIC)
(1, 6, 1), -- Glädje (TEXT)
(1, 2, 2), -- Enkelhet (NUMERIC)
(1, 7, 3), -- Enkelhet (TEXT)
(1, 3, 4), -- Resultat (NUMERIC)
(1, 8, 5), -- Resultat (TEXT)
(1, 4, 6), -- Ansvar (NUMERIC)
(1, 9, 7), -- Ansvar (TEXT)
(1, 10, 8), -- Nöjdhet över lag (TEXT)
(1, 11, 9), -- Vad kan personen göra för att bli bättre? (TEXT)
(1, 5, 10); -- Återkoppling (TEXT)

-- Koppla alla frågor till "Nybörjare"-mallen
DELETE FROM form_question WHERE form_template_id = 2;
INSERT INTO form_question (form_template_id, question_id, question_order) VALUES
(2, 1, 0), -- Glädje (NUMERIC)
(2, 6, 1), -- Glädje (TEXT)
(2, 2, 2), -- Enkelhet (NUMERIC)
(2, 7, 3), -- Enkelhet (TEXT)
(2, 3, 4), -- Resultat (NUMERIC)
(2, 8, 5), -- Resultat (TEXT)
(2, 4, 6), -- Ansvar (NUMERIC)
(2, 9, 7), -- Ansvar (TEXT)
(2, 16, 8), -- Hur har konsultens första tid i uppdraget varit? (TEXT)
(2, 17, 9), -- Finns det något särskilt stöd konsulten behöver initialt? (TEXT)
(2, 5, 10); -- Återkoppling (TEXT)

-- Koppla frågor till "Projektavslut"-mallen (alla standardfrågor + nya)
DELETE FROM form_question WHERE form_template_id = 3;
INSERT INTO form_question (form_template_id, question_id, question_order) VALUES
(3, 1, 0), -- Glädje (NUMERIC)
(3, 6, 1), -- Glädje (TEXT)
(3, 2, 2), -- Enkelhet (NUMERIC)
(3, 7, 3), -- Enkelhet (TEXT)
(3, 3, 4), -- Resultat (NUMERIC)
(3, 8, 5), -- Resultat (TEXT)
(3, 4, 6), -- Ansvar (NUMERIC)
(3, 9, 7), -- Ansvar (TEXT)
(3, 10, 8), -- Nöjdhet över lag (TEXT)
(3, 11, 9), -- Vad kan personen göra för att bli bättre? (TEXT)
(3, 13, 10), -- Uppfylldes projektets mål? (TEXT)
(3, 12, 11), -- Skulle ni rekommendera konsulten... (TEXT)
(3, 5, 12);  -- Återkoppling (TEXT)

-- Koppla frågor till "Löpande uppföljning"-mallen (alla standardfrågor + nya)
DELETE FROM form_question WHERE form_template_id = 4;
INSERT INTO form_question (form_template_id, question_id, question_order) VALUES
(4, 1, 0), -- Glädje (NUMERIC)
(4, 6, 1), -- Glädje (TEXT)
(4, 2, 2), -- Enkelhet (NUMERIC)
(4, 7, 3), -- Enkelhet (TEXT)
(4, 3, 4), -- Resultat (NUMERIC)
(4, 8, 5), -- Resultat (TEXT)
(4, 4, 6), -- Ansvar (NUMERIC)
(4, 9, 7), -- Ansvar (TEXT)
(4, 10, 8), -- Nöjdhet över lag (TEXT)
(4, 11, 9), -- Vad kan personen göra för att bli bättre? (TEXT)
(4, 14, 10), -- Proaktivitet och initiativ (TEXT)
(4, 15, 11), -- Samarbete med teamet (TEXT)
(4, 5, 12);  -- Återkoppling (TEXT)





-- sample form submissions based on form_submission entity
INSERT INTO form_submission (consultant_id, client_id, seller_id, submitted_on, seen) VALUES
(4, 1, 2, CURRENT_TIMESTAMP, FALSE),
(5, 2, 3, CURRENT_TIMESTAMP, FALSE),
(4, 1, 2, CURRENT_TIMESTAMP - INTERVAL '10 days', TRUE),
(5, 2, 3, CURRENT_TIMESTAMP - INTERVAL '20 days', TRUE),
(6, 3, 1, CURRENT_TIMESTAMP - INTERVAL '5 days', FALSE),
(6, 3, 1, CURRENT_TIMESTAMP - INTERVAL '15 days', TRUE),
(4, 1, 2, CURRENT_TIMESTAMP - INTERVAL '30 days', TRUE),
(5, 2, 3, CURRENT_TIMESTAMP - INTERVAL '25 days', TRUE),
(6, 3, 1, CURRENT_TIMESTAMP - INTERVAL '12 days', TRUE),
(4, 1, 2, CURRENT_TIMESTAMP - INTERVAL '3 days', FALSE),
(5, 2, 3, CURRENT_TIMESTAMP - INTERVAL '7 days', FALSE),
(6, 3, 1, CURRENT_TIMESTAMP - INTERVAL '1 days', FALSE),
(4, 1, 2, CURRENT_TIMESTAMP - INTERVAL '40 days', TRUE),
(5, 2, 3, CURRENT_TIMESTAMP - INTERVAL '35 days', TRUE),
(6, 3, 1, CURRENT_TIMESTAMP - INTERVAL '18 days', TRUE),
(4, 1, 2, CURRENT_TIMESTAMP - INTERVAL '28 days', TRUE),
(5, 2, 3, CURRENT_TIMESTAMP - INTERVAL '22 days', TRUE),
(6, 3, 1, CURRENT_TIMESTAMP - INTERVAL '14 days', TRUE),
(4, 1, 2, CURRENT_TIMESTAMP - INTERVAL '8 days', TRUE),
(5, 2, 3, CURRENT_TIMESTAMP - INTERVAL '6 days', TRUE),
(6, 3, 1, CURRENT_TIMESTAMP - INTERVAL '2 days', TRUE),
(4, 1, 2, CURRENT_TIMESTAMP - INTERVAL '365 days', TRUE),
(5, 2, 3, CURRENT_TIMESTAMP - INTERVAL '200 days', TRUE),
(6, 3, 1, CURRENT_TIMESTAMP - INTERVAL '150 days', TRUE),
(4, 1, 2, CURRENT_TIMESTAMP - INTERVAL '90 days', TRUE),
(5, 2, 3, CURRENT_TIMESTAMP - INTERVAL '60 days', TRUE),
(6, 3, 1, CURRENT_TIMESTAMP - INTERVAL '30 days', TRUE),
(4, 1, 2, CURRENT_TIMESTAMP - INTERVAL '15 days', TRUE),
(5, 2, 3, CURRENT_TIMESTAMP - INTERVAL '10 days', TRUE),
(6, 3, 1, CURRENT_TIMESTAMP - INTERVAL '250 days', TRUE),
(4, 1, 2, CURRENT_TIMESTAMP - INTERVAL '301 days', TRUE),
(5, 2, 3, CURRENT_TIMESTAMP - INTERVAL '115 days', TRUE),
(6, 3, 1, CURRENT_TIMESTAMP - INTERVAL '100 days', TRUE),
(4, 1, 2, CURRENT_TIMESTAMP - INTERVAL '45 days', TRUE),
(5, 2, 3, CURRENT_TIMESTAMP - INTERVAL '75 days', TRUE),
(6, 3, 1, CURRENT_TIMESTAMP - INTERVAL '85 days', TRUE);


-- sample answers based on answer entity
INSERT INTO answer (form_submission_id, question_id, text_content, numerical_content) VALUES
(1, 1, NULL, 8),
(1, 6, 'Konsulten är mycket trevlig och lätt att samarbeta med.', NULL),
(1, 2, NULL, 9),
(1, 7, 'Kommunikationen är alltid tydlig och enkel att förstå.', NULL),
(1, 3, NULL, 7),
(1, 8, 'Konsulten levererar oftast i tid och med bra kvalitet.', NULL),
(1, 4, NULL, 8),
(1, 9, 'Konsulten tar ansvar för sitt arbete och är pålitlig.', NULL),
(1, 5, 'Återkopplingen är snabb och konstruktiv.', NULL),

(2, 1, NULL, 7),
(2, 6, 'Konsulten är professionell och lätt att arbeta med.', NULL),
(2, 2, NULL, 8),
(2, 7, 'Kommunikationen är oftast tydlig och enkel att förstå.', NULL),
(2, 3, NULL, 6),
(2, 8, 'Konsulten levererar ibland i tid och med bra kvalitet.', NULL),
(2, 4, NULL, 7),
(2, 9, 'Konsulten tar ansvar för sitt arbete och är pålitlig.', NULL),
(2, 5, '', NULL),

(3, 1, NULL, 9),
(3, 6, 'Konsulten är mycket trevlig och lätt att samarbeta med.', NULL),
(3, 2, NULL, 10),
(3, 7, 'Kommunikationen är alltid tydlig och enkel att förstå.', NULL),
(3, 3, NULL, 8),
(3, 8, 'Konsulten levererar oftast i tid och med bra kvalitet.', NULL),
(3, 4, NULL, 9),
(3, 9, 'Konsulten tar ansvar för sitt arbete och är pålitlig.', NULL),
(3, 5, 'Jag skulle jobba med hen igen', NULL),

(4, 1, NULL, 4),
(4, 6, 'Konsulten är lite brysk ibland', NULL),
(4, 2, NULL, 5),
(4, 7, 'Kommunikationen är ibland svår att förstå.', NULL),
(4, 3, NULL, 6),
(4, 8, 'Konsulten levererar ibland i tid och med bra kvalitet.', NULL),
(4, 4, NULL, 5),
(4, 9, 'Konsulten tar ibland ansvar för sitt arbete och är pålitlig.', NULL),
(4, 5, 'Återkopplingen är ibland långsam och okonstruktiv.', NULL),

(5, 1, NULL, 6),
(5, 6, 'Konsulten är professionell och lätt att arbeta med.', NULL),
(5, 2, NULL, 7),
(5, 7, 'Kommunikationen är oftast tydlig och enkel att förstå.', NULL),
(5, 3, NULL, 5),
(5, 8, 'Konsulten levererar ibland i tid och med bra kvalitet.', NULL),
(5, 4, NULL, 6),
(5, 9, 'Konsulten tar ansvar för sitt arbete och är pålitlig.', NULL),
(5, 5, '', NULL),

(6, 1, NULL, 8),
(6, 6, 'Konsulten är mycket trevlig och lätt att samarbeta med.', NULL),
(6, 2, NULL, 9),
(6, 7, 'Kommunikationen är alltid tydlig och enkel att förstå.', NULL),
(6, 3, NULL, 7),
(6, 8, 'Konsulten levererar oftast i tid och med bra kvalitet.', NULL),
(6, 4, NULL, 8),
(6, 9, 'Konsulten tar ansvar för sitt arbete och är pålitlig.', NULL),
(6, 5, 'Återkopplingen är snabb och konstruktiv.', NULL),

(7, 1, NULL, 9),
(7, 6, 'Konsulten är mycket trevlig och lätt att samarbeta med.', NULL),
(7, 2, NULL, 10),
(7, 7, 'Kommunikationen är alltid tydlig och enkel att förstå.', NULL),
(7, 3, NULL, 8),
(7, 8, 'Konsulten levererar oftast i tid och med bra kvalitet.', NULL),
(7, 4, NULL, 9),
(7, 9, 'Konsulten tar ansvar för sitt arbete och är pålitlig.', NULL),
(7, 5, 'Jag skulle jobba med hen igen', NULL),

(8, 1, NULL, 7),
(8, 6, 'Konsulten är professionell och lätt att arbeta med.', NULL),
(8, 2, NULL, 8),
(8, 7, 'Kommunikationen är oftast tydlig och enkel att förstå.', NULL),
(8, 3, NULL, 6),
(8, 8, 'Konsulten levererar ibland i tid och med bra kvalitet.', NULL),
(8, 4, NULL, 7),
(8, 9, 'Konsulten tar ansvar för sitt arbete och är pålitlig.', NULL),
(8, 5, '', NULL),

(9, 1, NULL, 8),
(9, 6, 'Konsulten är väldigt trevlig', NULL),
(9, 2, NULL, 4),
(9, 7, 'Kommunikationen är ibland svår att förstå.', NULL),
(9, 3, NULL, 5),
(9, 8, 'Konsulten levererar ibland i tid och med bra kvalitet.', NULL),
(9, 4, NULL, 4),
(9, 9, 'Konsulten tar ibland ansvar för sitt arbete och är pålitlig.', NULL),
(9, 5, 'Återkopplingen är ibland långsam och okonstruktiv.', NULL),

(10, 1, NULL, 6),
(10, 6, 'Konsulten är professionell och lätt att arbeta med.', NULL),
(10, 2, NULL, 7),
(10, 7, 'Kommunikationen är oftast tydlig och enkel att förstå.', NULL),
(10, 3, NULL, 5),
(10, 8, 'Konsulten levererar ibland i tid och med bra kvalitet.', NULL),
(10, 4, NULL, 6),
(10, 9, 'Konsulten tar ansvar för sitt arbete och är pålitlig.', NULL),
(10, 5, '', NULL),

(11, 1, NULL, 9),
(11, 6, 'Konsulten är mycket trevlig och lätt att samarbeta med.', NULL),
(11, 2, NULL, 10),
(11, 7, 'Kommunikationen är alltid tydlig och enkel att förstå.', NULL),
(11, 3, NULL, 8),
(11, 8, 'Konsulten levererar oftast i tid och med bra kvalitet.', NULL),
(11, 4, NULL, 9),
(11, 9, 'Konsulten tar ansvar för sitt arbete och är pålitlig.', NULL),
(11, 5, 'Jag skulle jobba med hen igen', NULL),

(12, 1, NULL, 7),
(12, 6, 'Konsulten är professionell och lätt att arbeta med.', NULL),
(12, 2, NULL, 8),
(12, 7, 'Kommunikationen är oftast tydlig och enkel att förstå.', NULL),
(12, 3, NULL, 6),
(12, 8, 'Konsulten levererar ibland i tid och med bra kvalitet.', NULL),
(12, 4, NULL, 7),
(12, 9, 'Konsulten tar ansvar för sitt arbete och är pålitlig.', NULL),
(12, 5, '', NULL),

(13, 1, NULL, 8),
(13, 6, 'Konsulten är mycket trevlig och lätt att samarbeta med.', NULL),
(13, 2, NULL, 9),
(13, 7, 'Kommunikationen är alltid tydlig och enkel att förstå.', NULL),
(13, 3, NULL, 7),
(13, 8, 'Konsulten levererar oftast i tid och med bra kvalitet.', NULL),
(13, 4, NULL, 8),
(13, 9, 'Konsulten tar ansvar för sitt arbete och är pålitlig.', NULL),
(13, 5, 'Återkopplingen är snabb och konstruktiv.', NULL),

(14, 1, NULL, 9),
(14, 6, 'Konsulten är mycket trevlig och lätt att samarbeta med.', NULL),
(14, 2, NULL, 10),
(14, 7, 'Kommunikationen är alltid tydlig och enkel att förstå.', NULL),
(14, 3, NULL, 8),
(14, 8, 'Konsulten levererar oftast i tid och med bra kvalitet.', NULL),
(14, 4, NULL, 9),
(14, 9, 'Konsulten tar ansvar för sitt arbete och är pålitlig.', NULL),
(14, 5, 'Jag skulle jobba med hen igen', NULL),

(15, 1, NULL, 7),
(15, 6, 'Konsulten är professionell och lätt att arbeta med.', NULL),
(15, 2, NULL, 8),
(15, 7, 'Kommunikationen är oftast tydlig och enkel att förstå.', NULL),
(15, 3, NULL, 6),
(15, 8, 'Konsulten levererar ibland i tid och med bra kvalitet.', NULL),
(15, 4, NULL, 7),
(15, 9, 'Konsulten tar ansvar för sitt arbete och är pålitlig.', NULL),
(15, 5, '', NULL),

(16, 1, NULL, 8),
(16, 6, 'Konsulten är väldigt trevlig', NULL),
(16, 2, NULL, 4),
(16, 7, 'Kommunikationen är ibland svår att förstå.', NULL),
(16, 3, NULL, 5),
(16, 8, 'Konsulten levererar ibland i tid och med bra kvalitet.', NULL),
(16, 4, NULL, 4),
(16, 9, 'Konsulten tar ibland ansvar för sitt arbete och är pålitlig.', NULL),
(16, 5, 'Återkopplingen är ibland långsam och okonstruktiv.', NULL),

(17, 1, NULL, 6),
(17, 6, 'Konsulten är professionell och lätt att arbeta med.', NULL),
(17, 2, NULL, 7),
(17, 7, 'Kommunikationen är oftast tydlig och enkel att förstå.', NULL),
(17, 3, NULL, 5),
(17, 8, 'Konsulten levererar ibland i tid och med bra kvalitet.', NULL),
(17, 4, NULL, 6),
(17, 9, 'Konsulten tar ansvar för sitt arbete och är pålitlig.', NULL),
(17, 5, '', NULL),

(18, 1, NULL, 9),
(18, 6, 'Konsulten är mycket trevlig och lätt att samarbeta med.', NULL),
(18, 2, NULL, 10),
(18, 7, 'Kommunikationen är alltid tydlig och enkel att förstå.', NULL),
(18, 3, NULL, 8),
(18, 8, 'Konsulten levererar oftast i tid och med bra kvalitet.', NULL),
(18, 4, NULL, 9),
(18, 9, 'Konsulten tar ansvar för sitt arbete och är pålitlig.', NULL),
(18, 5, 'Jag skulle jobba med hen igen', NULL),

(19, 1, NULL, 7),
(19, 6, 'Konsulten är professionell och lätt att arbeta med.', NULL),
(19, 2, NULL, 10),
(19, 7, 'Kommunikationen är oftast tydlig och enkel att förstå.', NULL),
(19, 3, NULL, 1),
(19, 8, 'Konsulten levererar ibland i tid och med bra kvalitet.', NULL),
(19, 4, NULL, 9),
(19, 9, 'Konsulten tar ansvar för sitt arbete och är pålitlig.', NULL),
(19, 5, '', NULL),

(20, 1, NULL, 8),
(20, 6, 'Konsulten är mycket trevlig och lätt att samarbeta med.', NULL),
(20, 2, NULL, 9),
(20, 7, 'Kommunikationen är alltid tydlig och enkel att förstå.', NULL),
(20, 3, NULL, 7),
(20, 8, 'Konsulten levererar oftast i tid och med bra kvalitet.', NULL),
(20, 4, NULL, 8),
(20, 9, 'Konsulten tar ansvar för sitt arbete och är pålitlig.', NULL),
(20, 5, 'Återkopplingen är snabb och konstruktiv.', NULL),

(21, 1, NULL, 9),
(21, 6, 'Konsulten är mycket trevlig och lätt att samarbeta med.', NULL),
(21, 2, NULL, 10),
(21, 7, 'Kommunikationen är alltid tydlig och enkel att förstå.', NULL),
(21, 3, NULL, 8),
(21, 8, 'Konsulten levererar oftast i tid och med bra kvalitet.', NULL),
(21, 4, NULL, 9),
(21, 9, 'Konsulten tar ansvar för sitt arbete och är pålitlig.', NULL),
(21, 5, 'Jag skulle jobba med hen igen', NULL),

(22, 1, NULL, 7),
(22, 6, 'Konsulten är professionell och lätt att arbeta med.', NULL),
(22, 2, NULL, 8),
(22, 7, 'Kommunikationen är oftast tydlig och enkel att förstå.', NULL),
(22, 3, NULL, 6),
(22, 8, 'Konsulten levererar ibland i tid och med bra kvalitet.', NULL),
(22, 4, NULL, 7),
(22, 9, 'Konsulten tar ansvar för sitt arbete och är pålitlig.', NULL),
(22, 5, '', NULL),

(23, 1, NULL, 8),
(23, 6, 'Konsulten är väldigt trevlig', NULL),
(23, 2, NULL, 4),
(23, 7, 'Kommunikationen är ibland svår att förstå.', NULL),
(23, 3, NULL, 5),
(23, 8, 'Konsulten levererar ibland i tid och med bra kvalitet.', NULL),
(23, 4, NULL, 4),
(23, 9, 'Konsulten tar ibland ansvar för sitt arbete och är pålitlig.', NULL),
(23, 5, 'Återkopplingen är ibland långsam och okonstruktiv.', NULL),

(24, 1, NULL, 6),
(24, 6, 'Konsulten är professionell och lätt att arbeta med.', NULL),
(24, 2, NULL, 7),
(24, 7, 'Kommunikationen är oftast tydlig och enkel att förstå.', NULL),
(24, 3, NULL, 5),
(24, 8, 'Konsulten levererar ibland i tid och med bra kvalitet.', NULL),
(24, 4, NULL, 6),
(24, 9, 'Konsulten tar ansvar för sitt arbete och är pålitlig.', NULL),
(24, 5, '', NULL),

(25, 1, NULL, 9),
(25, 6, 'Konsulten är mycket trevlig och lätt att samarbeta med.', NULL),
(25, 2, NULL, 10),
(25, 7, 'Kommunikationen är alltid tydlig och enkel att förstå.', NULL),
(25, 3, NULL, 8),
(25, 8, 'Konsulten levererar oftast i tid och med bra kvalitet.', NULL),
(25, 4, NULL, 9),
(25, 9, 'Konsulten tar ansvar för sitt arbete och är pålitlig.', NULL),
(25, 5, 'Jag skulle jobba med hen igen', NULL),

(26, 1, NULL, 7),
(26, 6, 'Konsulten är professionell och lätt att arbeta med.', NULL),
(26, 2, NULL, 8),
(26, 7, 'Kommunikationen är oftast tydlig och enkel att förstå.', NULL),
(26, 3, NULL, 6),
(26, 8, 'Konsulten levererar ibland i tid och med bra kvalitet.', NULL),
(26, 4, NULL, 7),
(26, 9, 'Konsulten tar ansvar för sitt arbete och är pålitlig.', NULL),
(26, 5, '', NULL),

(27, 1, NULL, 8),
(27, 6, 'Konsulten är väldigt trevlig', NULL),
(27, 2, NULL, 4),
(27, 7, 'Kommunikationen är ibland svår att förstå.', NULL),
(27, 3, NULL, 5),
(27, 8, 'Konsulten levererar ibland i tid och med bra kvalitet.', NULL),
(27, 4, NULL, 4),
(27, 9, 'Konsulten tar ibland ansvar för sitt arbete och är pålitlig.', NULL),
(27, 5, 'Återkopplingen är ibland långsam och okonstruktiv.', NULL),

(28, 1, NULL, 6),
(28, 6, 'Konsulten är professionell och lätt att arbeta med.', NULL),
(28, 2, NULL, 7),
(28, 7, 'Kommunikationen är oftast tydlig och enkel att förstå.', NULL),
(28, 3, NULL, 5),
(28, 8, 'Konsulten levererar ibland i tid och med bra kvalitet.', NULL),
(28, 4, NULL, 6),
(28, 9, 'Konsulten tar ansvar för sitt arbete och är pålitlig.', NULL),
(28, 5, '', NULL),

(29, 1, NULL, 9),
(29, 6, 'Konsulten är mycket trevlig och lätt att samarbeta med.', NULL),
(29, 2, NULL, 10),
(29, 7, 'Kommunikationen är alltid tydlig och enkel att förstå.', NULL),
(29, 3, NULL, 8),
(29, 8, 'Konsulten levererar oftast i tid och med bra kvalitet.', NULL),
(29, 4, NULL, 9),
(29, 9, 'Konsulten tar ansvar för sitt arbete och är pålitlig.', NULL),
(29, 5, 'Jag skulle jobba med hen igen', NULL),

(30, 1, NULL, 7),
(30, 6, 'Konsulten är professionell och lätt att arbeta med.', NULL),
(30, 2, NULL, 8),
(30, 7, 'Kommunikationen är oftast tydlig och enkel att förstå.', NULL),
(30, 3, NULL, 6),
(30, 8, 'Konsulten levererar ibland i tid och med bra kvalitet.', NULL),
(30, 4, NULL, 7),
(30, 9, 'Konsulten tar ansvar för sitt arbete och är pålitlig.', NULL),
(30, 5, '', NULL),

(31, 1, NULL, 8),
(31, 6, 'Konsulten är väldigt trevlig', NULL),
(31, 2, NULL, 4),
(31, 7, 'Kommunikationen är ibland svår att förstå.', NULL),
(31, 3, NULL, 5),
(31, 8, 'Konsulten levererar ibland i tid och med bra kvalitet.', NULL),
(31, 4, NULL, 4),
(31, 9, 'Konsulten tar ibland ansvar för sitt arbete och är pålitlig.', NULL),
(31, 5, 'Återkopplingen är ibland långsam och okonstruktiv.', NULL),

(32, 1, NULL, 6),
(32, 6, 'Konsulten är professionell och lätt att arbeta med.', NULL),
(32, 2, NULL, 7),
(32, 7, 'Kommunikationen är oftast tydlig och enkel att förstå.', NULL),
(32, 3, NULL, 5),
(32, 8, 'Konsulten levererar ibland i tid och med bra kvalitet.', NULL),
(32, 4, NULL, 6),
(32, 9, 'Konsulten tar ansvar för sitt arbete och är pålitlig.', NULL),
(32, 5, '', NULL),

(33, 1, NULL, 9),
(33, 6, 'Konsulten är mycket trevlig och lätt att samarbeta med.', NULL),
(33, 2, NULL, 10),
(33, 7, 'Kommunikationen är alltid tydlig och enkel att förstå.', NULL),
(33, 3, NULL, 8),
(33, 8, 'Konsulten levererar oftast i tid och med bra kvalitet.', NULL),
(33, 4, NULL, 9),
(33, 9, 'Konsulten tar ansvar för sitt arbete och är pålitlig.', NULL),
(33, 5, 'Jag skulle jobba med hen igen', NULL),

(34, 1, NULL, 7),
(34, 6, 'Konsulten är professionell och lätt att arbeta med.', NULL),
(34, 2, NULL, 8),
(34, 7, 'Kommunikationen är oftast tydlig och enkel att förstå.', NULL),
(34, 3, NULL, 6),
(34, 8, 'Konsulten levererar ibland i tid och med bra kvalitet.', NULL),
(34, 4, NULL, 7),
(34, 9, 'Konsulten tar ansvar för sitt arbete och är pålitlig.', NULL),
(34, 5, '', NULL),

(35, 1, NULL, 8),
(35, 6, 'Konsulten är väldigt trevlig', NULL),
(35, 2, NULL, 4),
(35, 7, 'Kommunikationen är ibland svår att förstå.', NULL),
(35, 3, NULL, 5),
(35, 8, 'Konsulten levererar ibland i tid och med bra kvalitet.', NULL),
(35, 4, NULL, 4),
(35, 9, 'Konsulten tar ibland ansvar för sitt arbete och är pålitlig.', NULL),
(35, 5, 'Återkopplingen är ibland långsam och okonstruktiv.', NULL),

(36, 1, NULL, 6),
(36, 6, 'Konsulten är professionell och lätt att arbeta med.', NULL),
(36, 2, NULL, 7),
(36, 7, 'Kommunikationen är oftast tydlig och enkel att förstå.', NULL),
(36, 3, NULL, 5),
(36, 8, 'Konsulten levererar ibland i tid och med bra kvalitet.', NULL),
(36, 4, NULL, 6),
(36, 9, 'Konsulten tar ansvar för sitt arbete och är pålitlig.', NULL),
(36, 5, '', NULL);