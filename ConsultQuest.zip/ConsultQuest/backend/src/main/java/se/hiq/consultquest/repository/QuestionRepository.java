package se.hiq.consultquest.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import se.hiq.consultquest.entity.Question;

public interface QuestionRepository extends JpaRepository<Question, Long> {
    
}
