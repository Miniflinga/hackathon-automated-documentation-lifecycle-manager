package se.hiq.consultquest.service;

import java.time.YearMonth;
import java.time.ZoneId;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import lombok.RequiredArgsConstructor;
import se.hiq.consultquest.dto.DashboardResponse;
import se.hiq.consultquest.dto.FormDto;
import se.hiq.consultquest.dto.FormSubmitDto;
import se.hiq.consultquest.dto.QuestionDto;
import se.hiq.consultquest.dto.AverageScore;
import se.hiq.consultquest.dto.ClientReportScore;
import se.hiq.consultquest.dto.DashboardData;
import se.hiq.consultquest.dto.DailyAverageDto;
import se.hiq.consultquest.dto.TrendDTO;
import se.hiq.consultquest.repository.*;
import se.hiq.consultquest.entity.enums.MandatoryQuestions;
import se.hiq.consultquest.entity.enums.QuestionCategory;

import se.hiq.consultquest.util.ActionTokenService;
import se.hiq.consultquest.util.AppMailer;
import se.hiq.consultquest.entity.*;

import java.time.LocalDate;
import java.util.*;

@Service
@RequiredArgsConstructor
public class FormService {

    private final FormRepository formRepository;
    private final QuestionRepository questionRepository;
    private final FormSubmissionRepository formSubmissionRepository;
    private final ActionTokenService tokens;
    private final ClientRepository clientRepository;
    private final UsersRepository usersRepository;
    private final AppMailer mailer;

    @Value("${app.frontend-url}")
    private String frontendUrl;
    
    
    public FormDto getForm(String formTemplateName) {
        Optional<Form> formOpt = formRepository.findByFormTemplateName(formTemplateName);

        if (formOpt.isEmpty()) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Form template not found");
        } else {
            Form form = formOpt.get();
            List<Question> questionEntities = form.getQuestions();
            System.out.println("Questions from DB: " + questionEntities);
            List<QuestionDto> questions = new ArrayList<>();
            questionEntities.forEach(question -> {
                questions.add(new QuestionDto(
                        question.getId(),
                        question.getQuestionText(),
                        question.getDescription(),
                        question.getCategory()
                ));
            });
            //return new FormDto(form.getFormTemplateName(), questions, Optional.of(new Users()), Optional.of(new Client()), Optional.of(new Users()));
            return new FormDto(form.getFormTemplateName(), questions);
        }
    }

    @Transactional
    public void saveFormSubmission(FormSubmitDto dto) {
        FormSubmission submission = new FormSubmission();
        var t = tokens.consume(dto.token(), ActionToken.Type.RATE_USER);
        var payload = tokens.payload(t);

        Long clientId = ((Number) payload.get("clientId")).longValue();
        Long sellerId = ((Number) payload.get("userId")).longValue();
        Long consultantId = ((Number) payload.get("consultantUserId")).longValue();

        Client client = clientRepository.getReferenceById(clientId);
        Users seller = usersRepository.getReferenceById(sellerId);
        Users consultant = usersRepository.getReferenceById(consultantId);
        
        List<Answer> answers = dto.answers().stream().map(answerDto -> {
            Answer answer = new Answer();
            Question question = questionRepository.findById(answerDto.questionId())
                .orElseThrow(() -> new InvalidQuestionException("Invalid question ID: " + answerDto.questionId()));
            answer.setQuestion(question);
            // Determine if the answer is numerical or text based on question category
            if (question.getCategory() == QuestionCategory.NUMERIC) {
                try {
                    int numericValue = Integer.parseInt(answerDto.value());
                    if (numericValue < 0 || numericValue > 10) {
                        throw new InvalidAnswerException("Slider value must be between 0 and 10");
                    }
                    answer.setNumericalContent(numericValue);
                } catch (NumberFormatException e) {
                    throw new InvalidAnswerException("Expected numerical answer for question ID: " + answerDto.questionId());
                }
            } else {
                answer.setTextContent(answerDto.value());
            }
            answer.setFormSubmission(submission); // link back
            return answer;
        }).collect(Collectors.toList());

        submission.setAnswers(answers);
        submission.setClient(client);
        submission.setSeller(seller);
        submission.setConsultant(consultant);

        formSubmissionRepository.save(submission);

        // Send confirmation email creator of email which is userid in actiontoken

        notifyOriginator(t, submission.getId());
        
    }

    private void notifyOriginator(ActionToken t, long submissionId) {
        Users originator = usersRepository.findById(t.getUserId())
        .orElseThrow(() -> new IllegalStateException("Creator user not found"));
        Client client = clientRepository.findById(t.getClientId())
        .orElseThrow(() -> new IllegalStateException("Client not found"));

        String consultant = ActionTokenService.read(t.getPayloadJson()).get("consultantName").toString();
        String link = String.format("%s/dashboard?report=%d", frontendUrl, submissionId);
        String body = """
            %s har svarat på kvalitetsuppföljning för %s.
            
            Klicka på länken för att se resultatet:
            %s
            
            """.formatted(consultant, client.getName(), link);

        mailer.send(originator.getEmail(), "Kvalitetsuppföljning svarat", body);
    }

        public class InvalidQuestionException extends RuntimeException {
        public InvalidQuestionException(String message) {
            super(message);
        }
    }

        public class InvalidAnswerException extends RuntimeException {
        public InvalidAnswerException(String message) {
            super(message);
        }
    }

    public List<DailyAverageDto> getDailyAverages(List<FormSubmission> submissions) {
        // Group by LocalDate
        Map<LocalDate, List<FormSubmission>> byDay = submissions.stream()
            .collect(Collectors.groupingBy(sub ->
                sub.getSubmittedOn().atZone(ZoneId.systemDefault()).toLocalDate()
            ));

        List<DailyAverageDto> result = new ArrayList<>();

        for (Map.Entry<LocalDate, List<FormSubmission>> entry : byDay.entrySet()) {
            LocalDate day = entry.getKey();
            List<FormSubmission> daySubs = entry.getValue();

            List<AverageScore> scores = getAveragePerQuestion(daySubs);

            if (!scores.isEmpty()) {
                DailyAverageDto dailyAverage = new DailyAverageDto();
                dailyAverage.setDate(day);
                dailyAverage.setAverageScores(scores);
                dailyAverage.setSubmissions((long) daySubs.size());
                result.add(dailyAverage);
            }
        }

        // Sort by date
        result.sort(Comparator.comparing(DailyAverageDto::getDate));
        return result;
    }

    public List<DashboardResponse> getAllFormResponses() {
        List<FormSubmission> submissions = formSubmissionRepository.findAllByOrderBySubmittedOnDesc();
        List<DashboardResponse> dashboardResponses = new ArrayList<>();

        for (FormSubmission submission : submissions) {
            DashboardResponse dr = dashboardResponseForSubmission(submission);
            dashboardResponses.add(dr);
        }

        return dashboardResponses;

    }

    public DashboardData getDashboardData(){
        List<FormSubmission> formSubmissions = formSubmissionRepository.findAllByOrderBySubmittedOnDesc();
        DashboardData dashboardData = new DashboardData();
      
        dashboardData.setTotalResponses(formSubmissions.size());
        
        // Number of monthly responses 
        YearMonth currentMonth = YearMonth.now();
        YearMonth lastMonth = currentMonth.minusMonths(1);
        List<FormSubmission> currentMonthSubmissions = formSubmissions.stream()
                .filter(sub -> YearMonth.from(sub.getSubmittedOn().atZone(ZoneId.systemDefault())).equals(currentMonth))
                .collect(Collectors.toList());
        List<FormSubmission> lastMonthSubmissions = formSubmissions.stream()
                .filter(sub -> YearMonth.from(sub.getSubmittedOn().atZone(ZoneId.systemDefault())).equals(lastMonth))
                .collect(Collectors.toList());

        int countCurrentMonth = currentMonthSubmissions.size();
        int countLastMonth = lastMonthSubmissions.size();
        
        dashboardData.setMonthlyResponses(countCurrentMonth);
        dashboardData.setLastMonthResponses(countLastMonth);

        // Calculates increase percentage
        float monthlyPercentageIncrease = countLastMonth > 0 ? ((float)(countCurrentMonth - countLastMonth) / countLastMonth) * 100 : 0;
        dashboardData.setMonthlyPercentageIncrease(monthlyPercentageIncrease);

        //Calculates average score
        float averageScore = calculateAverageScore(formSubmissions);
        if (formSubmissions == null || formSubmissions.isEmpty()) {
            averageScore = 0;
        }
        float totalScore = 0;
        int count = 0;
        for (FormSubmission submission : formSubmissions) {
            List<Integer> numericalScores = submission.getAnswers().stream()
                    .map(Answer::getNumericalContent)
                    .filter(Objects::nonNull)
                    .collect(Collectors.toList());
            if (!numericalScores.isEmpty()) {
                totalScore += numericalScores.stream().mapToInt(Integer::intValue).sum();
                count++;
            }
        }
        averageScore = count > 0 ? totalScore / count : 0;
        dashboardData.setAverageScore(averageScore);

        // Trend for Total Reports
        long newToday = formSubmissions.stream()
                .filter(sub -> sub.getSubmittedOn().atZone(ZoneId.systemDefault()).toLocalDate().equals(LocalDate.now()))
                .count();
        String totalResponsesTrendText = newToday > 0 ? String.format("+%d nya idag", newToday) : "Inga nya idag";
        dashboardData.setTotalResponsesTrend(new TrendDTO(totalResponsesTrendText, newToday > 0 ? "increase" : "stable", (double) newToday));

        // Trend for Monthly Reports
        String monthlyResponsesTrendText;
        String monthlyResponsesTrendDirection;
        if (countLastMonth > 0) {
            if (monthlyPercentageIncrease > 0) {
                monthlyResponsesTrendText = String.format("▲ %.1f%% från förra månaden", monthlyPercentageIncrease);
                monthlyResponsesTrendDirection = "increase";
            } else if (monthlyPercentageIncrease < 0) {
                monthlyResponsesTrendText = String.format("▼ %.1f%% från förra månaden", Math.abs(monthlyPercentageIncrease));
                monthlyResponsesTrendDirection = "decrease";
            } else {
                monthlyResponsesTrendText = "Samma som förra månaden";
                monthlyResponsesTrendDirection = "stable";
            }
        } 
        
        else if (countCurrentMonth == 0) {
            monthlyResponsesTrendText = "Inga nya denna månaden";
            monthlyResponsesTrendDirection = "stable";
        }
        
        else {
            monthlyResponsesTrendText = String.format("%d nya denna månad", countCurrentMonth);
            monthlyResponsesTrendDirection = "increase";
        }
        dashboardData.setMonthlyResponsesTrend(new TrendDTO(monthlyResponsesTrendText, monthlyResponsesTrendDirection, (double) monthlyPercentageIncrease));

        // Trend for Average Score
        float currentMonthAverageScore = calculateAverageScore(currentMonthSubmissions);
        float lastMonthAverageScore = calculateAverageScore(lastMonthSubmissions);
        
        String averageScoreTrendText;
        String averageScoreTrendDirection;
        if (lastMonthAverageScore > 0) {
            double percentageChange = ((currentMonthAverageScore - lastMonthAverageScore) / lastMonthAverageScore) * 100;
            if (percentageChange > 0) {
                averageScoreTrendText = String.format("▲ %.1f%% från förra månaden", percentageChange);
                averageScoreTrendDirection = "increase";
            } else if (percentageChange < 0) {
                averageScoreTrendText = String.format("▼ %.1f%% från förra månaden", Math.abs(percentageChange));
                averageScoreTrendDirection = "decrease";
            } else {
                averageScoreTrendText = "Samma som förra månaden";
                averageScoreTrendDirection = "stable";
            }
             dashboardData.setAverageScoreTrend(new TrendDTO(averageScoreTrendText, averageScoreTrendDirection, percentageChange));
        } else {
            averageScoreTrendText = "Ingen data från förra månaden";
            averageScoreTrendDirection = "stable";
             dashboardData.setAverageScoreTrend(new TrendDTO(averageScoreTrendText, averageScoreTrendDirection, 0.0));
        }

        return dashboardData;
    }

    private float calculateAverageScore(List<FormSubmission> submissions) {
        if (submissions == null || submissions.isEmpty()) {
            return 0;
        }
        float totalScore = 0;
        int count = 0;
        for (FormSubmission submission : submissions) {
            List<Integer> numericalScores = submission.getAnswers().stream()
                    .map(Answer::getNumericalContent)
                    .filter(Objects::nonNull)
                    .collect(Collectors.toList());
            if (!numericalScores.isEmpty()) {
                totalScore += numericalScores.stream().mapToInt(Integer::intValue).average().orElse(0);
                count++;
            }
        }
        return count > 0 ? totalScore / count : 0;
    }

    public List<DashboardResponse> getFormSubmissionsByUserId(Long userId) {
        List<FormSubmission> submissions = formSubmissionRepository.findByConsultantIdOrderBySubmittedOnDesc(userId);
        List<DashboardResponse> dashboardResponses = new ArrayList<>();

        for (FormSubmission submission : submissions) {
            DashboardResponse dr = new DashboardResponse();
            dr.setSubmissionId(submission.getId());
            dr.setAnswers(submission.getAnswers());

            // Set consultant, client, and seller details with null checks
            Client client = submission.getClient();
            Users consultant = submission.getConsultant();
            Users seller = submission.getSeller();

            if (client != null) {
                dr.setClientName(client.getName());
                dr.setClientId(client.getId());
            } else {
                dr.setClientName("N/A");
                dr.setClientId(null);
            }

            if (consultant != null) {
                dr.setConsultantName(consultant.getFirstName() + " " + consultant.getLastName());
                dr.setConsultantId(consultant.getId());
            } else {
                dr.setConsultantName("N/A");
                dr.setConsultantId(null);
            }

            if (seller != null) {
                dr.setSellerName(seller.getFirstName() + " " + seller.getLastName());
                dr.setSellerId(seller.getId());
            } else {
                dr.setSellerName("N/A");
                dr.setSellerId(null);
            }

            dr.setSubmissionDate(submission.getSubmittedOn());
            dr.setStatus(submission.getSeen());

            // Calculate overall score
            // This logic is duplicated from getAllFormResponses, could be refactored
            List<Integer> numericalScores = submission.getAnswers().stream().map(Answer::getNumericalContent)
                    .filter(score -> score != null).collect(Collectors.toList());
            dr.setOverallScore(numericalScores.isEmpty() ? null
                    : Math.round((float) numericalScores.stream().mapToInt(Integer::intValue).sum()));
            dashboardResponses.add(dr);
        }
        return dashboardResponses;
    }
    private DashboardResponse dashboardResponseForSubmission(FormSubmission submission) {
        DashboardResponse dr = new DashboardResponse();
        dr.setSubmissionId(submission.getId());
        dr.setAnswers(submission.getAnswers());

        // Set consultant, client, and seller details with null checks
        Client client = submission.getClient();
        Users consultant = submission.getConsultant();
        Users seller = submission.getSeller();

        if(client != null) {
            dr.setClientName(client.getName());
            dr.setClientId(client.getId());
        } else {
            dr.setClientName("N/A");
            dr.setClientId(null);
        }

        if(consultant != null) {
            dr.setConsultantName(consultant.getFirstName() + " " + consultant.getLastName());
            dr.setConsultantId(consultant.getId());
        } else {
            dr.setConsultantName("N/A");
            dr.setConsultantId(null);
        }

        if(seller != null) {
            dr.setSellerName(seller.getFirstName() + " " + seller.getLastName());
            dr.setSellerId(seller.getId());
        } else {
            dr.setSellerName("N/A");
            dr.setSellerId(null);
        }
        
        dr.setSubmissionDate(submission.getSubmittedOn());

        // Calculate overall score (average of numerical answers)
        List<Integer> numericalScores = submission.getAnswers().stream()
            .map(Answer::getNumericalContent)
            .filter(score -> score != null)                
            .collect(Collectors.toList());
        if (!numericalScores.isEmpty()) {
            int sum = numericalScores.stream().mapToInt(Integer::intValue).sum();
            dr.setOverallScore(sum);
        } else {
            dr.setOverallScore(null); // No numerical scores available
        }
        
        dr.setStatus(submission.getSeen()); 
        
        return dr;
    }

    public DashboardResponse getFormResponseById(Long submissionId) {
        Optional<FormSubmission> submissionOpt = formSubmissionRepository.findById(submissionId);
        if (submissionOpt.isEmpty()) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Form submission not found");
        }

        FormSubmission submission = submissionOpt.get();
        DashboardResponse dr = dashboardResponseForSubmission(submission);    
        return dr;
    }

    public ClientReportScore getAverageClientScoresById(long clientId){
        ClientReportScore scores = new ClientReportScore();
        List<FormSubmission> submissions = formSubmissionRepository.findByClientId(clientId);

        if (submissions.isEmpty()) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "No reports for client found");
        } else {
            scores.setId(clientId);
            scores.setAverageScores(getAveragePerQuestion(submissions)); 

        }
        return scores;
            
    }

    private List<AverageScore> getAveragePerQuestion(List<FormSubmission> submissions){
        Map<Long, List<Integer>> questionScores = new HashMap();
        List<Long> mandatoryQuestionIds = MandatoryQuestions.getListOfIds(); // Ensures the enum is loaded

            //Get average score per numeric question and stores in hashmap
            for(FormSubmission submission : submissions){
                for(Answer answer : submission.getAnswers()) {
                    if(answer.getQuestion().getCategory() == QuestionCategory.NUMERIC){
                        Long questionId = answer.getQuestion().getId();
                        if(mandatoryQuestionIds.contains(questionId)){
                            // Only include mandatory questions
                            questionScores.computeIfAbsent(questionId, k -> new ArrayList<>()).add(answer.getNumericalContent());
                        }
                    }
                }

            }

        // Calculate average per question
        List<AverageScore> averageScores = new ArrayList<>(); 
        for (Map.Entry<Long, List<Integer>> entry : questionScores.entrySet()) {
            AverageScore avgScore = new AverageScore();
            List<Integer> values = entry.getValue();
            double avg = values.stream().mapToInt(Integer::intValue).average().orElse(0.0);
            avgScore.setQuestionId(entry.getKey());
            avgScore.setQuestionText(MandatoryQuestions.getTextFromId(entry.getKey())); // Get question text from enum
            avgScore.setScore(avg);
            averageScores.add(avgScore);
        }

        return averageScores;

    }


    

}
