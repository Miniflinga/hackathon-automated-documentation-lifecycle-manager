package se.hiq.consultquest.dto;

import java.util.List;

public record UserEditDto(
    Long id,
    String email,
    String firstName,
    String lastName,
    List<String> roles,  
    List<Long> teamIds   
) {}
