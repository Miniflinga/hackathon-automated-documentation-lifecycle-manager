package se.hiq.consultquest.dto;

import java.util.List;

public record ClientPageDTO(
    Long id,
    String name,
    double averageScore,
    List<FormSubmissionScoreDTO> submissions,
    List<RadarChartDataDTO> radarChartData,
    List<DailyAverageDto> dailyAverages
) {}
