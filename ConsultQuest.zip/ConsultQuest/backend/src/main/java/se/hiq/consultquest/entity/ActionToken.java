package se.hiq.consultquest.entity;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.OffsetDateTime;

@Entity
@Table(name = "action_tokens", indexes = {
        @Index(name = "idx_action_tokens_token_hash", columnList = "token_hash", unique = true),
        @Index(name = "idx_action_tokens_type", columnList = "type")
})
@Data
@NoArgsConstructor
public class ActionToken {

    public enum Type { INVITE, PASSWORD_RESET, RATE_USER }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // store only the HASH of the token we email (defense in depth)
    @Column(name = "token_hash", nullable = false, unique = true, length = 64)
    private String tokenHash;

    @Enumerated(EnumType.STRING)
    @Column(name = "type", nullable = false, length = 32)
    private Type type;

    @Column(name = "email")   // for invite/reset
    private String email;

    @Column(name = "user_id") // optional: for RATE_USER or linking to an existing user
    private Long userId;

    @Column(name = "client_id")
    private Long clientId;

    @Column(name = "payload", columnDefinition = "TEXT")
    private String payloadJson; // arbitrary JSON: roles/teamIds/first/last/etc

    @Column(name = "expires_at", nullable = false)
    private OffsetDateTime expiresAt;

    @Column(name = "consumed_at")
    private OffsetDateTime consumedAt;

    @Column(name = "created_at", nullable = false)
    private OffsetDateTime createdAt = OffsetDateTime.now();

    @Transient
    public boolean isActive() {
        return consumedAt == null && OffsetDateTime.now().isBefore(expiresAt);
    }
}
