package se.hiq.consultquest.dto;

import java.util.List;
import java.util.Optional;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import se.hiq.consultquest.dto.QuestionDto;
import se.hiq.consultquest.entity.Client;
import se.hiq.consultquest.entity.Users;

public record FormDto(
    @NotBlank 
    @Pattern(regexp = "^[a-zA-Z0-9_-]+$", message = "Form template name must contain only letters, numbers, underscores, or hyphens")
    String formTemplateName,
    @Valid List<QuestionDto> questions
    
    //Optional<Users> consultant,
    //Optional<Client> client,
    //Optional<Users> salesRep
) {
    
}
