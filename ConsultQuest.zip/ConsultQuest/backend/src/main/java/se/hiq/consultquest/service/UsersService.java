package se.hiq.consultquest.service;

import org.springframework.transaction.annotation.Transactional;

import se.hiq.consultquest.service.FormService;
/*
 * Usersservice class for operation connected to the users entity and DB table
 */
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import jakarta.validation.Valid;
import se.hiq.consultquest.entity.FormSubmission;
import se.hiq.consultquest.entity.Team;
import se.hiq.consultquest.entity.Users;
import se.hiq.consultquest.repository.FormSubmissionRepository;
import se.hiq.consultquest.repository.TeamRepository;
import se.hiq.consultquest.repository.UsersRepository;

import java.util.*;

import se.hiq.consultquest.entity.Users.Role;
import se.hiq.consultquest.dto.*;
import se.hiq.consultquest.repository.FormSubmissionRepository;
import se.hiq.consultquest.repository.UsersRepository;

@Service
@RequiredArgsConstructor
public class UsersService {

    private static final long GENERAL_USER_ID = 1L;

    private final UsersRepository usersRepository;
    private final FormSubmissionRepository formSubmissionRepository;
    private final TeamRepository teamRepository;
    private final FormService formService;

    @Transactional(readOnly = true)
    public UserEditDto getUserEditDto(Long id) {
        Users u = usersRepository.getReferenceById(id);
        List<String> roleStrings = Role.rolesFromInt(u.getRole()).stream().map(Role::name).toList();
        List<Long> teamIds = u.getTeams().stream().map(Team::getId).toList();
        return new se.hiq.consultquest.dto.UserEditDto(
            u.getId(),
            u.getEmail(),
            u.getFirstName(),
            u.getLastName(),
            roleStrings,
            teamIds
        );
    }

    @Transactional
    public void updateUser(Long id, @Valid InviteRequest req) {
        Users u = usersRepository.getReferenceById(id);

        // If email is changed, ensure no collision
        String newEmail = req.getEmail();
        if (!u.getEmail().equalsIgnoreCase(newEmail)) {
            usersRepository.findByEmail(newEmail).ifPresent(existing -> {
                if (!existing.getId().equals(id)) {
                    throw new IllegalStateException("User with this email already exists");
                }
            });
            u.setEmail(newEmail);
        }

        u.setFirstName(req.getFirstName());
        u.setLastName(req.getLastName());

        // roles -> int bitmask
        List<Role> roles = req.getRoles().stream().map(Role::valueOf).toList();
        u.setRole(Role.toInt(roles));

        // teams
        List<Long> teamIds = req.getTeamIds() == null ? List.of() : req.getTeamIds();
        var teams = new HashSet<>(teamRepository.findAllById(teamIds));
        u.setTeams(teams);
        usersRepository.save(u);
    }

    //when deleting a user that is connected to a formsubmission 
    //we need to replace with a general user then delete
    @Transactional
    public void deleteAndReassign(Long userId) {
        if (!usersRepository.existsById(userId)) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "User not found");
        }
        if (userId.equals(GENERAL_USER_ID)) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Cannot delete the general user (id=1)");
        }
        if (!usersRepository.existsById(GENERAL_USER_ID)) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "General user (id=1) does not exist");
        }

        // 1) Reassign all references in FormSubmission
        formSubmissionRepository.reassignConsultant(userId, GENERAL_USER_ID);
        formSubmissionRepository.reassignSeller(userId, GENERAL_USER_ID);

        // 2) Delete the user
        usersRepository.deleteById(userId);
    }


public UserProfileDto getUserProfileDto(Long id) {
        Users user = usersRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "User not found"));

        String companyName = user.getClient() != null ? user.getClient().getName() : null;
        String teamName = user.getTeams().stream().findFirst().map(Team::getName).orElse(null);
        List<String> roleNames = Users.Role.rolesFromInt(user.getRole()).stream().map(Enum::name).toList();
        List<DashboardResponse> reports = formService.getFormSubmissionsByUserId(id);
        List<FormSubmission> formSubmissions = formSubmissionRepository.findByConsultantIdOrderBySubmittedOnDesc(id);
        
        List<DailyAverageDto> averageScores = Collections.emptyList();
        if (!formSubmissions.isEmpty()) {
            averageScores = formService.getDailyAverages(formSubmissions);
        }

        return new UserProfileDto(
                user.getId(),
                user.getFirstName(),
                user.getLastName(),
                user.getEmail(),
                null, // profileIcon - can be implemented later
                companyName,
                teamName,
                roleNames,
                reports,
                averageScores);
    }

}
