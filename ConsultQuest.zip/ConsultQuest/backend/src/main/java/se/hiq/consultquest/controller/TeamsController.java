package se.hiq.consultquest.controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import lombok.RequiredArgsConstructor;
import se.hiq.consultquest.repository.TeamRepository;


import java.util.*;
import se.hiq.consultquest.entity.*;

@RestController
@RequestMapping("/api/teams")
@RequiredArgsConstructor
public class TeamsController {
    
    private final TeamRepository teamRepository;

    @GetMapping("/all")
    public List<Team> getAllTeams(){
        return teamRepository.findAll();
    }
}
