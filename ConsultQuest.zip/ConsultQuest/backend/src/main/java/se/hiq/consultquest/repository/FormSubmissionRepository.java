package se.hiq.consultquest.repository;
import se.hiq.consultquest.entity.FormSubmission;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface FormSubmissionRepository extends JpaRepository<FormSubmission, Long> {

    
     // Reassign consultant
     // used when deleting a user that is connected to formsubmission
    @Modifying(clearAutomatically = true, flushAutomatically = true)
    @Query(value = "UPDATE form_submission SET consultant_id = :newUserId WHERE consultant_id = :oldUserId", nativeQuery = true)
    int reassignConsultant(@Param("oldUserId") Long oldUserId, @Param("newUserId") Long newUserId);

    // Reassign seller 
    // used when deleting a user that is connected to formsubmission
    @Modifying(clearAutomatically = true, flushAutomatically = true)
    @Query(value = "UPDATE form_submission SET seller_id = :newUserId WHERE seller_id = :oldUserId", nativeQuery = true)
    int reassignSeller(@Param("oldUserId") Long oldUserId, @Param("newUserId") Long newUserId);

    List<FormSubmission> findAllByOrderBySubmittedOnDesc();

    List<FormSubmission> findByConsultantIdOrderBySubmittedOnDesc(Long consultantId);

    List<FormSubmission> findByClientId(long clientId);
}
