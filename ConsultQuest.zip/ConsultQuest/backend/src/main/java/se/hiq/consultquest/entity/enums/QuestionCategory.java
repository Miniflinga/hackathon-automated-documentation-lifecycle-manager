package se.hiq.consultquest.entity.enums;

public enum QuestionCategory {
    NUMERIC,
    TEXT
}
