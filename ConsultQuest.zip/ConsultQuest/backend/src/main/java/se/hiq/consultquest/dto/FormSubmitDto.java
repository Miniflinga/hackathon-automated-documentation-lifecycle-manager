package se.hiq.consultquest.dto;

import java.util.List;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Pattern;

public record FormSubmitDto(
    @NotBlank
    @Pattern(regexp = "^[\\p{L}0-9_ -]+$", message = "Form template name must contain only letters, numbers, underscores, or hyphens")
    String formTemplateName,

    @NotBlank
    String token,

    @NotEmpty
    @Valid
    List<AnswerDto> answers
) {}
