package se.hiq.consultquest.controller;

import jakarta.validation.Valid;
import lombok.Data;
import lombok.RequiredArgsConstructor;

import java.util.EnumSet;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import se.hiq.consultquest.dto.AcceptInviteRequest;
import se.hiq.consultquest.dto.FormInviteDto;
import se.hiq.consultquest.dto.InviteRequest;
import se.hiq.consultquest.util.*;
import se.hiq.consultquest.entity.*;

@RestController
@RequestMapping("/api/invites")
@RequiredArgsConstructor
public class InviteController {

    private final InviteService inviteService;
    private final ActionTokenService tokens;

    // Api for admin to create a new user and send the an invite via email
    @PostMapping()
    public ResponseEntity<Void> createInvite(@Valid @RequestBody InviteRequest req) {
        inviteService.sendInviteSignUp(req);
        return ResponseEntity.noContent().build();
    }

    // Public: used by frontend to check token before showing form
    @GetMapping("/validate")
    public TokenValidation validate(@RequestParam("token") String token) {
        boolean isValid = tokens.isValidAny(token, EnumSet.of(ActionToken.Type.INVITE, ActionToken.Type.PASSWORD_RESET));
        var tv = new TokenValidation();
        tv.valid = isValid;
        return tv;
    }


    // Public: set password and activate the new account
    @PostMapping("/accept")
    public ResponseEntity<Void> accept(@Valid @RequestBody AcceptInviteRequest req) {
        inviteService.acceptInvite(req.getToken(), req.getPassword());
        return ResponseEntity.noContent().build();
    }


    @GetMapping("/validate/form")
    public TokenValidationWithInfo validateFormToken(@RequestParam("token") String token) {
        var actionToken = tokens.getIfValid(token, ActionToken.Type.RATE_USER);
        var tvi = new TokenValidationWithInfo();
        tvi.setValid(actionToken != null);
        if (actionToken != null) {
           var payload = ActionTokenService.read(actionToken.getPayloadJson());
           tvi.setConsultantName((String) payload.get("consultantName"));
           tvi.setFormTemplateName((String) payload.get("formTemplateName"));
        }
        return tvi;
    }

    @PostMapping("/form")
    public ResponseEntity<Void> createInviteForm(@Valid @RequestBody FormInviteDto req) {
        inviteService.sendInviteForm(req);
        return ResponseEntity.noContent().build();
    }

    @PostMapping("/reset-password")
    public ResponseEntity<Void> resetPassword(@RequestBody String email) {
        inviteService.sendInviteResetPassword(email);
        return ResponseEntity.noContent().build();
    }

    @Data
    static class TokenValidation { boolean valid; }

    @Data
    static class TokenValidationWithInfo { boolean valid; String consultantName; String formTemplateName; }
}
