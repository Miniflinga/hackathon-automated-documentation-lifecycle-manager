package se.hiq.consultquest.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import se.hiq.consultquest.entity.Answer;

public interface AnswerRepository extends JpaRepository<Answer, Long> {
    
}
