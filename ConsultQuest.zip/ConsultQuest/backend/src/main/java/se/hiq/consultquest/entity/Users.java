package se.hiq.consultquest.entity;

import jakarta.persistence.*;
import lombok.Data;

import java.time.OffsetDateTime;
import java.util.*;

import org.hibernate.annotations.UpdateTimestamp;

@Entity
@Table(name = "users")
@Data
public class Users {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "password", nullable = false)
    private String password;

    @Column(name = "email", nullable = false, unique = true)
    private String email;

    @Column(name = "role", nullable = false)
    private int role;

    @Column(name = "first_name", nullable = false)
    private String firstName;

    @Column(name = "last_name", nullable = false)
    private String lastName;

    @UpdateTimestamp
    @Column(name="last_modified")
    private OffsetDateTime lastModified;

    @ManyToOne
    @JoinColumn(name = "client_id")
    private Client client;

    @ManyToMany
    @JoinTable(
        name = "user_team",
        joinColumns = @JoinColumn(name = "user_id"),
        inverseJoinColumns = @JoinColumn(name = "team_id")
    )

    private Set<Team> teams = new HashSet<>();
    
    //TODO fix better way to map client to user to allow this check again
   /*  @jakarta.validation.constraints.AssertTrue(message = "Exactly one of client or team must be set")
    private boolean isClientXorTeams() {
        boolean hasClient = client != null;
        boolean hasTeams = teams != null && !teams.isEmpty();
        return hasClient ^ hasTeams;
    }*/

    public enum Role {
        ADMIN, // index 0  1 << 0 = 1 00001
        SALES, // index 1  1 << 1 = 2 00010
        CLIENT, // index 2  1 << 2 = 4 00100
        MANAGER, // index 3  1 << 3 = 8 01000
        // NOTE: COUNSULTANT must be last in the list due to consultant query in UserRepository
        CONSULTANT; // index 4  1 << 4 = 16 10000 

        private int bit() {
            return 1 << this.ordinal();
        }

        public static List<Role> rolesFromInt(int rolesInt) {
            List<Role> roles = new ArrayList<>();
            for (Role role : Role.values()) {
                if ((rolesInt & role.bit()) != 0) {
                    roles.add(role);
                }
            }
            return roles;
        }

        public static int toInt(List<Role> roles) {
            int rolesInt = 0;
            for (Role role : roles) {
                rolesInt |= role.bit();
            }
            return rolesInt;
        }

    }

}