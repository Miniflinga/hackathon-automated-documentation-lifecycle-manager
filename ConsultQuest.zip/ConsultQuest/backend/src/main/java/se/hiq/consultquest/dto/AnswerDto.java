package se.hiq.consultquest.dto;

import jakarta.validation.constraints.NotNull;

public record AnswerDto(
    @NotNull Long questionId,
    @NotNull String value // want to allow empty string as valid answer
    
) {
    
}
