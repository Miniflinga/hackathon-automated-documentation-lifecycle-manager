package se.hiq.consultquest.dto;


import java.time.OffsetDateTime;
import java.util.List;


public record UsersDTO(
Long id,
String email,
List<String> roles,
String firstName,
String lastName,
List<String> teams, 
OffsetDateTime lastModified
) {}