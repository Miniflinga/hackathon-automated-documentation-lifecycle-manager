package se.hiq.consultquest.controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import se.hiq.consultquest.repository.ClientRepository;
import se.hiq.consultquest.repository.UsersRepository;
import se.hiq.consultquest.service.UsersService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.Authentication;
import java.util.*;
import se.hiq.consultquest.entity.*;
import se.hiq.consultquest.dto.*;
import se.hiq.consultquest.entity.Users.Role;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import se.hiq.consultquest.service.*;

@RestController
@RequestMapping("/api/users")
@RequiredArgsConstructor
public class UsersController {
    private static final Logger log = LoggerFactory.getLogger(UsersController.class);
    private final UsersRepository users;
    private final ClientRepository clients;
    private final UsersService usersService;


    @GetMapping("/all")
    public List<UsersDTO> getAllUsers(Authentication auth) {
        log.info("--- Protected endpoint /api/users/all reached");
        var allUsers = users.findAll(); 
        return allUsers.stream().map(this::toDTO).toList();
    }

    @GetMapping("/consultants") 
    public List<UsersDTO> getAllConsultants(Authentication auth) {
        log.info("--- Protected endpoint /api/users/consultants reached");
        // Custom query to find all users with the CONSULTANT role (role value 16 or higher)
        var allConsultants = users.findUsersWithRole16orHigher().orElse(Collections.emptyList());
        return allConsultants.stream().map(this::toDTO).toList();
    }

    @GetMapping("/clients")
    public List<Client> getAllClients(Authentication auth) {
        log.info("--- Protected endpoint /api/users/clients reached");
        // Fetch all users with the CLIENT role (role value 4)
        var allClients = clients.findAll();
        return allClients;
    }
    
    @GetMapping("/{id}")
    public UserEditDto getUserById(@PathVariable Long id) {
        return usersService.getUserEditDto(id);
    }

    @GetMapping("/profile/{id}")
    public UserProfileDto getUserProfileById(@PathVariable Long id) {
        return usersService.getUserProfileDto(id);
    }

    // Update a user using the same shape as InviteRequest
    @PutMapping("/edit/{id}")
    public void updateUser(@PathVariable Long id, @Valid @RequestBody InviteRequest req) {
        usersService.updateUser(id, req);
    }

    private UsersDTO toDTO(Users u) {
        List<Role> roles = Role.rolesFromInt(u.getRole());
        List<String> teamNames = u.getTeams().stream().map(Team::getName).toList();
        return new UsersDTO(
            u.getId(),
            u.getEmail(),
            roles.stream().map(Role::name).toList(),
            u.getFirstName(),
            u.getLastName(),
            teamNames,
            u.getLastModified()
        );
    }



    // Delete a user by ID
    @DeleteMapping("/delete/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public void deleteOne(@PathVariable Long id) {
        usersService.deleteAndReassign(id);
    }


}
