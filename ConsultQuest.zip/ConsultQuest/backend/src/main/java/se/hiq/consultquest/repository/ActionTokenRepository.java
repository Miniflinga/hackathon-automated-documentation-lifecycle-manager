package se.hiq.consultquest.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import se.hiq.consultquest.entity.*;

import java.time.OffsetDateTime;
import java.util.Collection;
import java.util.Optional;

public interface ActionTokenRepository extends JpaRepository<ActionToken, Long> {
    Optional<ActionToken> findByTokenHashAndTypeAndConsumedAtIsNullAndExpiresAtAfter(
            String tokenHash, ActionToken.Type type, OffsetDateTime now);

     //allow multiple types
    Optional<ActionToken> findByTokenHashAndTypeInAndConsumedAtIsNullAndExpiresAtAfter(
            String tokenHash, Collection<ActionToken.Type> types, OffsetDateTime now);
}