package se.hiq.consultquest.dto;

import java.util.List;

import lombok.Data;

@Data
public class UserProfileDto {
    private final Long id;
    private final String firstName;
    private final String lastName;
    private final String email;
    private final String profileIcon; // Can be a URL or initials
    private final String company;
    private final String team;
    private final List<String> roles;
    private final List<DashboardResponse> reports;
    private final List<DailyAverageDto> dailyAverages; 
}