package se.hiq.consultquest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConsultquestApplication {

	public static void main(String[] args) {
		SpringApplication.run(ConsultquestApplication.class, args);
	}

}
