package se.hiq.consultquest.entity.enums;

import java.util.List;

public enum MandatoryQuestions {
    RESULTAT(3, "Resultat"),
    ANSVAR(4, "Ansvar"),
    ENKELHET(2, "Enkelhet"),
    GLÄDJE(1, "Glädje");

    private final long id;
    private final String text;
    
    MandatoryQuestions(long i, String t) {
        this.id = i;
        this.text = t;
    }

    public long getId() {
        return id;
    }

    public String getText() {
        return text;
    }

    public static String getTextFromId(long id) {
        for (MandatoryQuestions mq : MandatoryQuestions.values()) {
            if (mq.getId() == id) {
                return mq.getText();
            }
        }
        return null; // or throw an exception if preferred
    }

    public static List<Long> getListOfIds() {
        return List.of(RESULTAT.getId(), ANSVAR.getId(), ENKELHET.getId(), GLÄDJE.getId());
    }
}
