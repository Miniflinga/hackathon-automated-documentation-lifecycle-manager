package se.hiq.consultquest.entity;

import jakarta.persistence.*;
import lombok.NoArgsConstructor;
import se.hiq.consultquest.entity.enums.QuestionCategory;


@Entity
@NoArgsConstructor
@Table(name = "question", uniqueConstraints = {
        @UniqueConstraint(columnNames = {"questionText", "category"})
})
public class Question {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String questionText;

    private String description;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private QuestionCategory category;

    // Getters & setters
    public Long getId(){
        return id;
    }

    public String getQuestionText(){
        return questionText;
    }

    public String getDescription(){
        return description;
    }

    public QuestionCategory getCategory(){
        return category;
    }

    public void setId(Long id){
        this.id = id;
    }

    public void setQuestionText(String text){
        this.questionText = text;
    }

    public void setDescription(String description){
        this.description = description;
    }

    public void setQuestionCategory(QuestionCategory category){
        this.category = category;
    }

}
