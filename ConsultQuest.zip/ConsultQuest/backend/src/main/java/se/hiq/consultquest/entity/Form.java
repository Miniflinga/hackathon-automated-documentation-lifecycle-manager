package se.hiq.consultquest.entity;

import java.time.Instant;
import java.util.List;

import org.hibernate.annotations.CreationTimestamp;

import jakarta.persistence.*;
import jakarta.validation.constraints.Pattern;
import lombok.NoArgsConstructor;

/**
 * Data entity representing a FormTemplate.
 */
@Entity
@Table(name = "form")
@NoArgsConstructor
public class Form {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique=true, nullable = false)
    @Pattern(regexp = "^[a-zA-Z0-9_-]+$", message = "Form template name must contain only letters, numbers, underscores, or hyphens")
    private String formTemplateName;

    @CreationTimestamp
    private Instant createdOn;

    @ManyToMany(cascade = {CascadeType.PERSIST, CascadeType.MERGE})
    @JoinTable(
            name = "form_question",
            joinColumns = @JoinColumn(name = "form_template_id"),
            inverseJoinColumns = @JoinColumn(name = "question_id"))
    @OrderColumn(name = "question_order")
    private List<Question> questions;

    // Getters & setters
    public Long getId(){
        return id;
    }

    public String getFormTemplateName(){
        return formTemplateName;
    }

    public Instant getCreatedOn(){
        return createdOn;
    }

    public List<Question> getQuestions(){
        return questions;
    }

    public void setId(Long id){
        this.id = id;
    }

    public void setFormTemplateName(String name){
        this.formTemplateName = name;
    }

    public void setCreatedOn(Instant timestamp){
        this.createdOn = timestamp;
    }

    public void setQuestions(List<Question> questions){
        this.questions = questions;
    }    
}
