package se.hiq.consultquest.entity;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.annotations.CreationTimestamp;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.*;
import lombok.NoArgsConstructor;

/**
 * Data entity representing a FormSubmission.
 */
@Entity
@NoArgsConstructor
public class FormSubmission {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @CreationTimestamp
    private Instant submittedOn;

    // Each submission is connected to one client.
    //TODO: add nullable = false when auth is implemented
    @ManyToOne
    @JoinColumn(name = "client_id", referencedColumnName = "id")
    @JsonBackReference
    private Client client;

    //TODO: add nullable = false when auth is implemented
    @ManyToOne
    @JoinColumn(name = "consultant_id", referencedColumnName = "id")
    private Users consultant;

    //TODO: add nullable = false when auth is implemented
    @ManyToOne
    @JoinColumn(name = "seller_id", referencedColumnName = "id")
    private Users seller;
    
    @OneToMany(mappedBy = "formSubmission", cascade = CascadeType.ALL)
    @JsonManagedReference
    private List<Answer> answers = new ArrayList<>();

    // If the submission has been handled or not
    private boolean seen = false;

    // Getters & setters
    public Long getId(){
        return id;
    }

    public Instant getSubmittedOn(){
        return submittedOn;
    }

    public Client getClient(){
        return client;
    }

    public Users getConsultant() {
        return consultant;
    }

    public Users getSeller() {
        return seller;
    }

    public List<Answer> getAnswers(){
        return answers;
    }

    public Boolean getSeen(){
        return seen;
    }

    public void setId(Long id){
        this.id = id;
    }

    public void setSubmittedOn(Instant timestamp){
        this.submittedOn = timestamp;
    }

    public void setClient(Client client){
        this.client = client;
    }

    public void setConsultant(Users consultant) {
        this.consultant = consultant;
    }

    public void setSeller(Users seller) {
        this.seller = seller;
    }

    public void setAnswers(List<Answer> answers) {
        this.answers = answers;
    }

    public void setSeen(Boolean seen){
        this.seen = seen;
    }

}
