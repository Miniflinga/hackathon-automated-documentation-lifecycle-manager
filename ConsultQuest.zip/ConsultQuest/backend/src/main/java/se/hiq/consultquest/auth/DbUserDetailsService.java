package se.hiq.consultquest.auth;

import se.hiq.consultquest.entity.*;
import se.hiq.consultquest.repository.*;

import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.core.userdetails.*;
import org.springframework.stereotype.Service;

// Service to load user details from the database for authentication
@Service
public class DbUserDetailsService implements UserDetailsService {

    private final UsersRepository repo;

    public DbUserDetailsService(UsersRepository repo) {
        this.repo = repo;
    }

    @Override
    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
        Users u = repo.findByEmail(email)
                      .orElseThrow(() -> new UsernameNotFoundException(email));

        var roles = Users.Role.rolesFromInt(u.getRole());

        var authorities = roles.stream().map(r -> "ROLE_" + r.name())
                        .toList();

        return new org.springframework.security.core.userdetails.User(
            u.getEmail(),
            u.getPassword(),     // plaintext for now
            AuthorityUtils.createAuthorityList(authorities)
        );
    }
}