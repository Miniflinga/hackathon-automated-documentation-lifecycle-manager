package se.hiq.consultquest.entity;

import com.fasterxml.jackson.annotation.JsonBackReference;

import jakarta.persistence.*;
import lombok.NoArgsConstructor;

/**
 * Data entity representing a Answer.
 */
@Entity
@NoArgsConstructor
@Table(name = "answer", uniqueConstraints = {
        @UniqueConstraint(columnNames = {"question_id", "form_submission_id"})
})
public class Answer {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // Associated question
    @ManyToOne
    @JoinColumn(name = "question_id", referencedColumnName = "id", nullable = false)
    private Question question;

    // Nullable, based on associated questions category/type.
    @Column(length = 500)
    private String textContent;

    // Nullable, based on associated questions category/type.
    private Integer numericalContent;

    // Associated form submission
    @ManyToOne
    @JoinColumn(name = "form_submission_id", referencedColumnName = "id", nullable = false)
    @JsonBackReference
    private FormSubmission formSubmission;


    @jakarta.validation.constraints.AssertTrue(message = "At least one of textContent or numericalContent must be set")
    private boolean isTextorNumerical() {
        boolean hasTextContent = textContent != null;
        boolean hasNumericalContent = numericalContent != null;
        return hasTextContent || hasNumericalContent;
    }

    // Getters + setters

    public Long getId() {
        return this.id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Question getQuestion() {
        return this.question;
    }

    public void setQuestion(Question question) {
        this.question = question;
    }

    public String getTextContent() {
        return this.textContent;
    }

    public void setTextContent(String textContent) {
        this.textContent = textContent;
    }

    public Integer getNumericalContent(){
        return this.numericalContent;
    }

    public void setNumericalContent(Integer numericalContent){
        this.numericalContent = numericalContent;
    }

    public FormSubmission getFormSubmission() {
        return formSubmission;
    }

    public void setFormSubmission(FormSubmission formSubmission) {
        this.formSubmission = formSubmission;
    }

}
