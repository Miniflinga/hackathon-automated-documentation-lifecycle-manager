
package se.hiq.consultquest.repository;
import se.hiq.consultquest.entity.*;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.*;

public interface UsersRepository extends JpaRepository<Users, Long> {
    Optional<Users> findByEmail(String email);

    boolean existsByEmail(String email);

    @Query("SELECT u FROM Users u WHERE u.role >= 16")
    Optional<List<Users>> findUsersWithRole16orHigher();
}
    