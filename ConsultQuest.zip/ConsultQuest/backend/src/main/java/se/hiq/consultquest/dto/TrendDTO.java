package se.hiq.consultquest.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class TrendDTO {
    private String text;
    private String direction;
    private Double changeValue;
}
