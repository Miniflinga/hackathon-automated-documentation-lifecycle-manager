package se.hiq.consultquest.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import se.hiq.consultquest.repository.UsersRepository;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.Authentication;
import java.util.*;
import se.hiq.consultquest.entity.Users.Role;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private static final Logger log = LoggerFactory.getLogger(AuthController.class);
     private final UsersRepository users;

    public AuthController(UsersRepository users) {
        this.users = users;
    }


    @GetMapping("/hello")
    public String sayHello() {
        return "Hello, you have accessed a protected endpoint!";
    }

    @GetMapping("/me")
    public Map<String,Object> whoAmI(Authentication auth) {
        log.info("--- Protected endpoint /api/test/me reached by user: '{}' ---", auth.getName());
        var u = users.findByEmail(auth.getName()).orElseThrow();
        Map<String, Object> userInfo = new HashMap<>();
        userInfo.put("id", u.getId());
        userInfo.put("roles", Role.rolesFromInt(u.getRole()));
        userInfo.put("firstName", u.getFirstName());
        userInfo.put("lastName", u.getLastName());
        userInfo.put("email", u.getEmail());
        return userInfo;
    }
}