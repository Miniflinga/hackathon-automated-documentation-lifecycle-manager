package se.hiq.consultquest.dto;

import java.time.Instant;
import java.util.List;

import lombok.Data;
import se.hiq.consultquest.entity.Answer;

@Data
public class DashboardResponse {
    private Long submissionId;
    private List<Answer> answers;
    private String consultantName;
    private Long consultantId;
    private String clientName;
    private Long clientId;
    private String sellerName;
    private Long sellerId;
    private Instant submissionDate;
    private Integer overallScore;
    private boolean status;
}
