package se.hiq.consultquest.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import se.hiq.consultquest.dto.ClientReportScore;
import se.hiq.consultquest.dto.DashboardData;
import se.hiq.consultquest.dto.DashboardResponse;
import se.hiq.consultquest.dto.DailyAverageDto;

import se.hiq.consultquest.dto.FormDto;
import se.hiq.consultquest.dto.FormSubmitDto;
import se.hiq.consultquest.repository.FormRepository;
import se.hiq.consultquest.repository.FormSubmissionRepository;
import se.hiq.consultquest.service.FormService;
import se.hiq.consultquest.service.FormService.InvalidAnswerException;
import se.hiq.consultquest.service.FormService.InvalidQuestionException;
import se.hiq.consultquest.entity.FormSubmission;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


@RestController
@RequiredArgsConstructor
@RequestMapping("/api/form")
public class FormController {

    private final FormSubmissionRepository formSubmissionRepository;

    private final FormService formService;
    private final FormRepository formRepository;

    private static final Logger log = LoggerFactory.getLogger(FormController.class);

    @PostMapping("/submit")
    public ResponseEntity<?> submitForm(@Valid @RequestBody FormSubmitDto dto) {
        try {
            formService.saveFormSubmission(dto);
            return ResponseEntity.status(HttpStatus.CREATED)
                     .body(Map.of("message", "Form submitted successfully"));
                     
        } catch (InvalidQuestionException | InvalidAnswerException e) {
            return ResponseEntity.badRequest().body(
        Map.of("error", "Invalid input in submission.","details", e.getMessage()));

        }
    }

    
    @GetMapping("/{formTemplateName}")
    public FormDto getForm(@PathVariable String formTemplateName) {
        log.info("Received form template name: {}", formTemplateName);
        // Allow Swedish characters (and other Unicode letters) and spaces in the template name
        if (!formTemplateName.matches("^[\\p{L}0-9_ -]+$")) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Invalid form template name");
        }
        FormDto formDto = formService.getForm(formTemplateName);
        log.info("Form questions received from DB: {}", formDto);
        return formDto;
    }

    @GetMapping("/formTemplateNames")
    public List<String> getAllFormTemplateNames() {
        return formRepository.getAllFormTemplateNames();
    }

    @GetMapping("/allResponses")
    public List<DashboardResponse> getAllFormResponses(Authentication auth) {
        List<DashboardResponse> dashboardData = formService.getAllFormResponses();
        log.info("--- Protected endpoint /api/form/allResponses reached");
        return dashboardData;
    }

    @GetMapping("/daily-averages")
    public List<DailyAverageDto> getDailyAverages() {
        List<FormSubmission> submissions = formSubmissionRepository.findAll();
        return formService.getDailyAverages(submissions);
    }

    @GetMapping("/dashboardData")
    public DashboardData getMethodName(Authentication auth) {
        DashboardData data = formService.getDashboardData();
        return data;
    }

    @GetMapping("/response/{submissionId}")
    public DashboardResponse getFormResponseById(@PathVariable Long submissionId, Authentication auth) {
        log.info("--- Protected endpoint /api/form/response/{} reached", submissionId);
        DashboardResponse response = formService.getFormResponseById(submissionId);
        return response;
    }

    @GetMapping("/averageClientScore/{clientId}")
    public ClientReportScore getAverageClientScores(@PathVariable Long clientId, Authentication auth) {
        ClientReportScore scores = formService.getAverageClientScoresById(clientId);
        return scores;
    }

    // Update seen status on formsumbission
    @PatchMapping("/setSeen/{id}")
    public ResponseEntity<Void> updateSeenStatus(@PathVariable Long id, @RequestBody Boolean seenStatus, Authentication auth) {
        FormSubmission submission = formSubmissionRepository.findById(id)
                        .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Submission not found"));
        
        submission.setSeen(seenStatus);
        formSubmissionRepository.save(submission);
        return ResponseEntity.noContent().build();
    }
    
}
