package se.hiq.consultquest.dto;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import se.hiq.consultquest.entity.enums.QuestionCategory;

public record QuestionDto(
        @NotNull Long id,
        @NotEmpty String questionText,
        String description,
        @NotNull QuestionCategory category
    ) {}