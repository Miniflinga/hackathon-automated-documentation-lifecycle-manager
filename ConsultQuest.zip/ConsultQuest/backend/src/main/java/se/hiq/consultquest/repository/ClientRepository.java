package se.hiq.consultquest.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import se.hiq.consultquest.entity.Client;

public interface ClientRepository extends JpaRepository<Client, Long> {
    @Query("""
        select c.id, c.name, fs
        from Client c
        left join FormSubmission fs on fs.client = c
        order by c.id asc, fs.submittedOn desc
    """)
    List<Object[]> fetchClientSubmissionRows();

    @Query("""
        select c.id, c.name, fs
        from Client c
        left join FormSubmission fs on fs.client = c
        where c.id = :id
        order by fs.submittedOn desc
    """)
    List<Object[]> fetchClientSubmissionRowsById(Long id);
}

