package se.hiq.consultquest.auth;


import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.HttpStatusEntryPoint;
import org.springframework.security.web.authentication.logout.HttpStatusReturningLogoutSuccessHandler;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

import se.hiq.consultquest.entity.Users.Role;

import org.springframework.security.crypto.password.NoOpPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

// Security configuration class to set up authentication and authorization for different endpoints

@Configuration
@EnableMethodSecurity
public class SecurityConfig {

@Autowired
Environment env; 

@Bean
    SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        boolean isDev = Arrays.asList(env.getActiveProfiles()).contains("dev");
   

        http
                // 1. Enable CORS using the bean defined below
                .cors(cors -> cors.configurationSource(corsConfigurationSource()))

                // 2. Disable CSRF for stateless APIs (common for SPAs)
                .csrf(csrf -> csrf.disable())

                // 3. Define endpoint authorization
                .authorizeHttpRequests(auth -> {
                        if(isDev){
                                auth.anyRequest().permitAll();
                                return;
                        }
                        
                        auth
                        
                        // Allow Admin access to invite user api and see all users
                        .requestMatchers("/api/invites" , "/api/users/all").hasRole(Role.ADMIN.toString()) 
                        // Allow Admin and Sales access to send form invite APIs
                        .requestMatchers("/api/form/formTemplateNames", "/api/users/clients", "/api/invites/form").hasAnyRole(Role.ADMIN.name(), Role.SALES.name())
                        // Allow Admin, Sales and Manager access for dashboard endpoints and consultants
                        .requestMatchers("/api/form/allResponses", "/api/form/dashboardData", "/api/users/consultants").hasAnyRole(Role.ADMIN.name(), Role.SALES.name(), Role.MANAGER.name())
                        // Allow auth users access to get their own account info
                        .requestMatchers("/api/auth/me").authenticated()
                        // Allow unauthenticated access to the login endpoint and form submission
                        .requestMatchers("/login", "/api/form/submit", "/api/form/{formTemplateName}", "/api/invites/validate", "/api/invites/accept", "/api/invites/validate/form").permitAll() 
                        // Secure all other endpoints
                        .anyRequest().authenticated();
                } 
                )
                
                // 4. Configure custom exception handling for unauthenticated users
                .exceptionHandling(customizer -> customizer
                        // When an unauthenticated user tries to access a protected resource,
                        // return 401 Unauthorized instead of redirecting to a login page.
                        .authenticationEntryPoint(new HttpStatusEntryPoint(HttpStatus.UNAUTHORIZED))
                )

                // 5. Configure the login process for an API
                .formLogin(form -> form
                        // Define the custom login URL, which we already permitted above
                        .loginProcessingUrl("/login")
                        .usernameParameter("email")
                        // On success, return an HTTP 200 OK status
                        .successHandler((request, response, authentication) -> response.setStatus(HttpStatus.OK.value()))
                        // On failure, return an HTTP 401 Unauthorized status
                        .failureHandler((request, response, exception) -> response.setStatus(HttpStatus.UNAUTHORIZED.value()))
                )

                // 6. Configure logout for an API
                .logout(logout -> logout
                        .logoutUrl("/logout")
                        // On success, return an HTTP 200 OK status
                        .logoutSuccessHandler(new HttpStatusReturningLogoutSuccessHandler(HttpStatus.OK))
                );

        return http.build();
    }

    @Bean
    CorsConfigurationSource corsConfigurationSource() {
        CorsConfiguration configuration = new CorsConfiguration();
        // Allow your Next.js frontend to connect
        configuration.setAllowedOrigins(List.of("http://localhost:3000")); 
        configuration.setAllowedMethods(List.of("GET", "POST", "PUT", "DELETE", "OPTIONS", "PATCH"));
        configuration.setAllowedHeaders(List.of("Authorization", "Content-Type"));
        // This is crucial for session cookies to be sent
        configuration.setAllowCredentials(true); 
        
        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**", configuration);
        return source;
    }

  @Bean
  PasswordEncoder passwordEncoder() {
    return NoOpPasswordEncoder.getInstance();
  }
}
