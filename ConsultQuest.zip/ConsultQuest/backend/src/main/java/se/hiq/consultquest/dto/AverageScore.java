package se.hiq.consultquest.dto;

import lombok.Data;

@Data
public class AverageScore {
    private long questionId;
    private double score;
    private String questionText;
}
