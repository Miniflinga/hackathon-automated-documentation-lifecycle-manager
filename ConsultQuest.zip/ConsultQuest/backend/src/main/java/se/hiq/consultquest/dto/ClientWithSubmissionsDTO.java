package se.hiq.consultquest.dto;
import java.util.List;
import se.hiq.consultquest.entity.FormSubmission;

public record ClientWithSubmissionsDTO(
        Long id,
        String name,
        List<FormSubmission> submissions
) {}
