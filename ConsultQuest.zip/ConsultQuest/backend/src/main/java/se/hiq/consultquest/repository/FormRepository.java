package se.hiq.consultquest.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import se.hiq.consultquest.entity.Form;

import java.util.List;
import java.util.Optional;


public interface FormRepository extends JpaRepository<Form, Long> {
    Optional<Form> findByFormTemplateName(String formTemplateName);
    
    @Query("SELECT f.formTemplateName FROM Form f")
    List<String> getAllFormTemplateNames();
}
