package se.hiq.consultquest.dto;

import lombok.Data;

@Data
public class DashboardData {
    private Integer totalResponses;
    private Integer monthlyResponses;
    private Integer lastMonthResponses; // if 0 monthlyPercentageIncrease also 0
    private float monthlyPercentageIncrease;
    private float averageScore;
    private TrendDTO totalResponsesTrend;
    private TrendDTO monthlyResponsesTrend;
    private TrendDTO averageScoreTrend;
}