package se.hiq.consultquest.util;

import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import se.hiq.consultquest.dto.FormInviteDto;
import se.hiq.consultquest.dto.InviteRequest;
import se.hiq.consultquest.entity.Users.Role;
import se.hiq.consultquest.repository.*;
import se.hiq.consultquest.entity.*;

import java.time.OffsetDateTime;

import java.util.*;

@Service
@RequiredArgsConstructor
public class InviteService {

    private final UsersRepository usersRepo;
    private final TeamRepository teamRepo;
    private final PasswordEncoder encoder;
    private final AppMailer mailer;
    private final ActionTokenService tokens;
    private final ClientRepository clientRepo;

    @Value("${app.frontend-url}")
    private String frontendUrl;

    @Value("${app.invites.ttl-days:7}")
    private int inviteTtlDays;

    // Send an invite email to a new user
    public void sendInviteSignUp(InviteRequest req) {
        // check if user already exists
        usersRepo.findByEmail(req.getEmail()).ifPresent(u -> {
            throw new IllegalStateException("User already exists");
        });

        // fills the payload from the admin form signup
        Map<String,Object> payload = new HashMap<>();
        payload.put("firstName", req.getFirstName());
        payload.put("lastName", req.getLastName());
        payload.put("roles", req.getRoles());
        payload.put("teamIds", req.getTeamIds());
        payload.put("userEmail", req.getEmail());

        // create token
        var raw = tokens.createToken(
                ActionToken.Type.INVITE,
                OffsetDateTime.now().plusDays(inviteTtlDays),
                req.getEmail(),
                null,
                null,
                payload
        );

        // if the user is only a consultant we create the user directly with a random password
        // the consultat is not meant to log in but is still needed to be registered in the system
        if (req.getRoles().contains(Role.CONSULTANT.name()) && req.getRoles().size() == 1) {
            //generate random password for consultant users
            String randomPassword = UUID.randomUUID().toString();
            createUserFromInvite(payload, randomPassword);
            return;
        }

        // create the email format for the invit and send it
        String link = frontendUrl + "/accept-invite?token=" + raw;
        String body = """
                Du har blivit inbjuden till ConsultQuest.
                
                Klicka på länken för att skapa ett lösenord och aktivera ditt konto:
                %s
                
                Denna länk upphör att gälla om %d dagar.
                """.formatted(link, inviteTtlDays);

        mailer.send(req.getEmail(), "Du har blivit inbjuden till ConsultQuest", body);
    }


    // Send an invite email client to rate user
    public void sendInviteForm(FormInviteDto req) {

        if (!clientRepo.existsById(req.getClientId())) {
            throw new IllegalArgumentException("Client not found: " + req.getClientId());
        }

        if (!usersRepo.existsById(req.getUserId())) {
            throw new IllegalArgumentException("User not found: " + req.getUserId());
        }

        Users consultant = usersRepo.findByEmail(req.getConsultantEmail()).orElseThrow(() -> 
        new IllegalStateException("Consultant user not found"));
        
        // fills the payload from the admin form signup
        Map<String,Object> payload = new HashMap<>();
        payload.put("consultantEmail", req.getConsultantEmail());
        payload.put("formTemplateName", req.getFormTemplateName());
        payload.put("clientId", req.getClientId());
        payload.put("userId", req.getUserId());
        payload.put("consultantUserId", consultant.getId());
        payload.put("consultantName", consultant.getFirstName() + " " + consultant.getLastName());

        // create token
        var raw = tokens.createToken(
                ActionToken.Type.RATE_USER,
                OffsetDateTime.now().plusDays(inviteTtlDays),
                req.getClientEmail(),
                req.getUserId(),
                req.getClientId(),
                payload
        );

        // create the email format for the invit and send it
        String link = frontendUrl + "/form?token=" + raw;
        String body = """
                Här kommer en länk för kvalitetsuppföljning för %s.
                
                Klicka på länken för att komma till formuläret:
                %s
                
                Denna länk kommer att utgå om %d dagar.
                """.formatted(req.getConsultantEmail() ,link, inviteTtlDays);

        mailer.send(req.getClientEmail(), "Du har blivit inbjuden till kvalitetsuppföljning", body);
    }


        // Send an invite email to user to reset passworrd
    public void sendInviteResetPassword(String email) {
        
        // fills the payload from the admin form signup
        Map<String,Object> payload = new HashMap<>();
        payload.put("resetEmail", email);

        // create token
        var raw = tokens.createToken(
                ActionToken.Type.PASSWORD_RESET,
                OffsetDateTime.now().plusDays(inviteTtlDays),
                email,
                null,
                null,
                payload
        );

        // create the email format for the invit and send it
        String link = frontendUrl + "/accept-invite?token=" + raw;
        String body = """
                Här kommer en länk för att återställa lösenordet för konto med email:  %s.
                
                Klicka på länken för att välja ett nytt lösenord:
                %s
                
                Denna länk kommer att utgå om %d dagar.
                """.formatted(email ,link, inviteTtlDays);

        mailer.send(email, "Du har blivit inbjuden till kvalitetsuppföljning", body);
    }


    // Accept an action token by setting a password.
    // INVITE: creates the user and sets the initial password
    // PASSWORD_RESET: updates the existing user's password
    @Transactional
    public void acceptInvite(String rawToken, String password) {
        var t = tokens.consumeAny(rawToken, EnumSet.of(
                ActionToken.Type.INVITE,
                ActionToken.Type.PASSWORD_RESET
        ));

        switch (t.getType()) {
            case INVITE -> createUserFromInvite(ActionTokenService.read(t.getPayloadJson()), password);
            case PASSWORD_RESET -> resetPasswordFromToken(t, password);
            default -> throw new IllegalStateException("Unsupported token type: " + t.getType());
        }
    }


    // Create a brand new user from the INVITE token payload and save it.
    private void createUserFromInvite(Map<String,Object> payload, String password) {
    

        Users u = new Users();
        u.setEmail(payload.get("userEmail").toString());
        u.setFirstName((String) payload.get("firstName"));
        u.setLastName((String) payload.get("lastName"));
        u.setPassword(encoder.encode(password));

        // roles -> bitmask
        var roleStrings = (List<String>) payload.get("roles");
        var roles = roleStrings.stream().map(Users.Role::valueOf).toList();
        u.setRole(Users.Role.toInt(roles));

        // teams
        var teamIds = (List<?>) payload.getOrDefault("teamIds", List.of());
        var teams = new HashSet<Team>(teamRepo.findAllById(
                teamIds.stream().map(id -> Long.valueOf(String.valueOf(id))).toList()
        ));
        u.setTeams(teams);

        usersRepo.save(u);
    }

    // update password for user when forgot password is used
    private void resetPasswordFromToken(ActionToken t, String newPassword) {
        String email = t.getEmail();
        Users user = usersRepo.findByEmail(email)
            .orElseThrow(() -> new IllegalStateException("User not found for email: " + email));

        user.setPassword(encoder.encode(newPassword));
        usersRepo.save(user);
    }
}
