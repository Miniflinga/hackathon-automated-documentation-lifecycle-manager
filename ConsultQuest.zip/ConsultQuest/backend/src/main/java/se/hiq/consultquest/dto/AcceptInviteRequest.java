package se.hiq.consultquest.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class AcceptInviteRequest {
    @NotBlank
    private String token;
    @NotBlank
    private String password;
}
