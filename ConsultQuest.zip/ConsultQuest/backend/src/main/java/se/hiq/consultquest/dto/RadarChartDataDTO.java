package se.hiq.consultquest.dto;

public record RadarChartDataDTO(
    String questionText,
    double averageScore
) {}
