package se.hiq.consultquest.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class FormInviteDto {

    @NotBlank
    private String formTemplateName;

    @NotBlank
    private String consultantEmail;

    private long consultantId;  

    private long clientId;

    private long userId;

    @NotBlank
    @Email
    private String clientEmail;
}