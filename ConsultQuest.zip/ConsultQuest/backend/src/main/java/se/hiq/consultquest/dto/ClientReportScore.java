package se.hiq.consultquest.dto;

import java.util.List;

import lombok.Data;

@Data
public class ClientReportScore {
    private long id;
    private List<AverageScore> averageScores;
}
