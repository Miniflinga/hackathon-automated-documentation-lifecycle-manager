package se.hiq.consultquest.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import lombok.RequiredArgsConstructor;
import se.hiq.consultquest.repository.ClientRepository;
import se.hiq.consultquest.service.FormService;

import java.util.*;
import java.util.stream.Collectors;

import se.hiq.consultquest.dto.ClientPageDTO;
import se.hiq.consultquest.dto.ClientWithSubmissionsDTO;
import se.hiq.consultquest.dto.DailyAverageDto;
import se.hiq.consultquest.dto.FormSubmissionScoreDTO;
import se.hiq.consultquest.dto.RadarChartDataDTO;
import se.hiq.consultquest.entity.*;
import se.hiq.consultquest.entity.enums.QuestionCategory;


@RestController
@RequestMapping("/api/client")
@RequiredArgsConstructor
public class ClientController {

    private final ClientRepository clientRepository;
    private final FormService formService;

    @PostMapping
    @PreAuthorize("hasAnyRole('ADMIN', 'SALES')")
    public Client createClient(@RequestBody Client client) {
        return clientRepository.save(client);
    }

    @GetMapping
    public List<Client> getClients() {
        return clientRepository.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<ClientPageDTO> getClientById(@PathVariable Long id) {
        List<Object[]> rows = clientRepository.fetchClientSubmissionRowsById(id);

        if (rows.isEmpty()) {
            return ResponseEntity.notFound().build();
        }

        Long clientId = (Long) rows.get(0)[0];
        String clientName = (String) rows.get(0)[1];

        List<FormSubmission> submissions = rows.stream()
                .map(row -> (FormSubmission) row[2])
                .filter(Objects::nonNull)
                .collect(Collectors.toList());

        List<FormSubmissionScoreDTO> submissionScores = submissions.stream()
                .map(sub -> {
                    double overallScore = sub.getAnswers().stream()
                            .filter(a -> a.getQuestion().getCategory() == QuestionCategory.NUMERIC && a.getNumericalContent() != null)
                            .mapToInt(Answer::getNumericalContent)
                            .sum();

                    String consultantName = Optional.ofNullable(sub.getConsultant())
                        .map(c -> c.getFirstName() + " " + c.getLastName())
                        .orElse("N/A");

                    return new FormSubmissionScoreDTO(sub.getId(), consultantName, sub.getSubmittedOn(), sub.getSeen(), overallScore);
                })
                .collect(Collectors.toList());

        double averageClientScore = submissionScores.stream()
                .mapToDouble(FormSubmissionScoreDTO::overallScore)
                .average()
                .orElse(0.0);

        Map<String, List<Integer>> scoresByQuestion = new HashMap<>();
        for (FormSubmission sub : submissions) {
            for (Answer ans : sub.getAnswers()) {
                if (ans.getQuestion().getCategory() == QuestionCategory.NUMERIC && ans.getNumericalContent() != null) {
                    scoresByQuestion.computeIfAbsent(ans.getQuestion().getQuestionText(), k -> new ArrayList<>()).add(ans.getNumericalContent());
                }
            }
        }

        List<RadarChartDataDTO> radarChartData = scoresByQuestion.entrySet().stream()
                .map(entry -> {
                    double avg = entry.getValue().stream().mapToInt(Integer::intValue).average().orElse(0.0);
                    return new RadarChartDataDTO(entry.getKey(), avg);
                })
                .collect(Collectors.toList());

        List<DailyAverageDto> dailyAverages = formService.getDailyAverages(submissions);

        ClientPageDTO clientPageData = new ClientPageDTO(clientId, clientName, averageClientScore, submissionScores, radarChartData, dailyAverages);

        return ResponseEntity.ok(clientPageData);
    }


    @GetMapping("/with-submissions")
    public List<ClientWithSubmissionsDTO> getClientWithSubmissions() {

        List<Object[]> rows = clientRepository.fetchClientSubmissionRows();

        Map<Long, String> clientNames = new LinkedHashMap<>();
        Map<Long, List<FormSubmission>> submissionsByClient = new LinkedHashMap<>();

        for (int i = 0; i < rows.size(); i++) {
            Object[] r = rows.get(i);

            Long clientId = (Long) r[0];
            String clientName = (String) r[1];
            FormSubmission fs = (FormSubmission) r[2];

            if (!clientNames.containsKey(clientId)) {
                clientNames.put(clientId, clientName);
            }

            if (!submissionsByClient.containsKey(clientId)) {
                submissionsByClient.put(clientId, new ArrayList<FormSubmission>());
            }

            if (fs != null) {
                submissionsByClient.get(clientId).add(fs);
            }
        }

        List<ClientWithSubmissionsDTO> result = new ArrayList<>();
        for (Long clientId : clientNames.keySet()) {
            String clientName = clientNames.get(clientId);
            List<FormSubmission> subs = submissionsByClient.getOrDefault(clientId, List.of());
            result.add(new ClientWithSubmissionsDTO(clientId, clientName, subs));
        }

        return result;

    }

}