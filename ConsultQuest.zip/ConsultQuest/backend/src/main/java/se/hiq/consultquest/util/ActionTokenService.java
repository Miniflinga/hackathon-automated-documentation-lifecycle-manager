package se.hiq.consultquest.util;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import se.hiq.consultquest.entity.*;
import se.hiq.consultquest.repository.ActionTokenRepository;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.OffsetDateTime;
import java.util.EnumSet;
import java.util.Map;
import java.util.Set;

@Service
@RequiredArgsConstructor
public class ActionTokenService {

    private final ActionTokenRepository repo;
    private static final ObjectMapper mapper = new ObjectMapper();

    @Value("${app.frontend-url}")
    private String frontendUrl;

    //generates a new raw token and the corresponding hash, saves the hash and data in DB
    //return the raw token to the caller to email in link
    public String createToken(ActionToken.Type type,
                              OffsetDateTime expiresAt,
                              String email,
                              Long userId,
                              Long clientId,
                              Map<String, Object> payload) {
        String raw = TokenUtil.generate();
        String hash = TokenUtil.sha256Hex(raw);

        ActionToken t = new ActionToken();
        t.setTokenHash(hash);
        t.setType(type);
        t.setExpiresAt(expiresAt);
        t.setEmail(email);
        t.setUserId(userId);
        t.setClientId(clientId);
        t.setPayloadJson(write(payload));
        repo.save(t);

        return raw; // return raw to email/embed in link
    }


    //hashes the provided token and looks up in DB to check if used or expired
    //if valid mark as consumed and return the ActionToken entity
    // this is used for a single type
    @Transactional
    public ActionToken consume(String raw, ActionToken.Type type) {
        return consumeAny(raw, EnumSet.of(type));
    }

     //hashes the provided token and looks up in DB to check if used or expired
    //if valid mark as consumed and return the ActionToken entity
    // this is handles multiple types of action token
    @Transactional
    public ActionToken consumeAny(String raw, Set<ActionToken.Type> allowedTypes) {
        String hash = TokenUtil.sha256Hex(raw);
        var now = OffsetDateTime.now();

        var t = repo.findByTokenHashAndTypeInAndConsumedAtIsNullAndExpiresAtAfter(
                hash, allowedTypes, now
        ).orElseThrow(() -> new IllegalArgumentException("Invalid or expired token"));
        // Sets consumedAt -> JPA dirty checking writes it on transaction commit.
        t.setConsumedAt(now); 
        return t;
    }

    //hashes the provided token and looks up in DB to check if used or expired
    public boolean isValid(String raw, ActionToken.Type type) {
        return repo.findByTokenHashAndTypeAndConsumedAtIsNullAndExpiresAtAfter(
                TokenUtil.sha256Hex(raw), type, OffsetDateTime.now()
        ).isPresent();
    }

    //validates any token type instead of specifc
    public boolean isValidAny(String raw, Set<ActionToken.Type> types) {
        return repo.findByTokenHashAndTypeInAndConsumedAtIsNullAndExpiresAtAfter(
            TokenUtil.sha256Hex(raw), types, OffsetDateTime.now()).isPresent();
    }

    // returns the ActionToken entity if valid, otherwise null
    public ActionToken getIfValid(String raw, ActionToken.Type type) {
    return repo.findByTokenHashAndTypeAndConsumedAtIsNullAndExpiresAtAfter(
            TokenUtil.sha256Hex(raw), type, OffsetDateTime.now()
    ).orElse(null);
    }

    //reads the JSON payload and returns as a Map
    public Map<String, Object> payload(ActionToken token) {
        return read(token.getPayloadJson());
    }

    //writes the Map as JSON string
    private String write(Map<String, Object> payload) {
        try { return mapper.writeValueAsString(payload); }
        catch (Exception e) { throw new RuntimeException(e); }
    }

    //reads the JSON string as a Map
    public static Map<String, Object> read(String json) {
        try { 
            return mapper.readValue(json, new TypeReference<>() {}); 
        }
        catch (Exception e) { 
            throw new RuntimeException(e); 
        }
    }
}
