package se.hiq.consultquest.dto;

import java.time.Instant;

public record FormSubmissionScoreDTO(
    Long id,
    String consultantName,
    Instant submittedOn,
    boolean seen,
    double overallScore
) {}
