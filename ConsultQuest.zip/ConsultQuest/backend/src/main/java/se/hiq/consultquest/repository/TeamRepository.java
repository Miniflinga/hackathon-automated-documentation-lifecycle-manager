
package se.hiq.consultquest.repository;
import se.hiq.consultquest.entity.*;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.*;

public interface TeamRepository extends JpaRepository<Team, Long> {
}
