package se.hiq.consultquest.util;

import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class AppMailer {

    private final JavaMailSender sender;

    @Value("${spring.mail.username}")
    private String from;

    public void send(String to, String subject, String text) {
        var m = new SimpleMailMessage();
        m.setFrom(from);
        m.setTo(to);
        m.setSubject(subject);
        m.setText(text);
        sender.send(m);
    }
}
