package se.hiq.consultquest.dto;

import java.time.LocalDate;
import java.util.List;

import lombok.Data;

@Data
public class DailyAverageDto {
    private LocalDate date;
    private List<AverageScore> averageScores;
    private Long submissions;
}
